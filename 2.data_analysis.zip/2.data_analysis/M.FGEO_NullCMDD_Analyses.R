############## NULL ANALYSES FOR MS ###############
################# CONHETMYC VERSION ###############

## This script takes null data and compares it to observed data
## First, compares med value of CMDD to null distribution: AM, then EM
## Then, compares distribution of AM CMDD to null distribution, then EM

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)
library(lsmeans)
library(ggeffects)
library(lme4)
library(lmerTest)
library(gridExtra)
library(spatstat)
library(mgcv)

###################################################
################### LOAD DATA #####################
###################################################

# read cdd data
dat <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>% 
mutate(resp = logit.change.CMH) 

###################################################
############### JOIN WITH METADATA ################
###################################################

# load additional data
spdat <- readRDS("data/splevel_meta.rds")
sitedat <- readRDS("data/sitelevel_meta.rds") %>% 
  mutate(CHELSA_BIO_Annual_Mean_Temperature = CHELSA_BIO_Annual_Mean_Temperature/100, 
         CHELSA_BIO_Annual_Precipitation = CHELSA_BIO_Annual_Precipitation/100)
spsitedat <- readRDS("data/spsitelevel_meta.rds")

# join data: species level
dat <- dat %>%
  left_join(spdat, by = c("latin")) %>%
  left_join(sitedat, by = c("site")) %>%
  left_join(spsitedat, by = c("latin","site")) 

# join data: site 
stdat <- dat %>% 
  group_by(site) %>%
  summarise(sitendd = weighted.median(resp, lgabund), sprich.val = length(latin))%>%
  left_join(sitedat, by = "site") %>%
  mutate(prop.spkept = sprich.val/sprich) 
lm.myc <- lmer(resp ~ myc + (1|site), dat = dat)
summary.obs <- summary(lm.myc)
anova(lm.myc, test = "LRT")

# generate CDD estimates
ref <- lsmeans(lm.myc, pairwise ~ myc, data = dat, pbkrtest.limit = 10000)
ref.table <- as.data.frame(ref$lsmeans) 
obs.ref.table <- ref.table

AM.est <- ref.table %>% filter(myc == "AM") %>% select(lsmean) # CDD 0.00122673
EM.est <- ref.table %>% filter(myc == "EM") %>% select(lsmean) # CDD 0.000880804
AM.se <- ref.table %>% filter(myc == "AM") %>% select(SE) # 0.001135114
EM.se <- ref.table %>% filter(myc == "EM") %>% select(SE) # 0.001257116

###################################################
################ NULL COMPARISON  #################
###################################################

###################################################
################### LOAD DATA #####################
###################################################

nulldat <- readRDS("data/null_conhetmyc/null_conhetmyc_CMH_spallfromglobal_GAMmodeloutput_allalive.rds") %>% 
  mutate(resp = logit.change.CMH) 

###################################################
############### JOIN WITH METADATA ################
###################################################

# join data: species level
nulldat <- nulldat %>%
  left_join(spdat, by= c("latin")) %>%
  left_join(sitedat, by= c("site")) %>%
  left_join(spsitedat, by = c("latin","site")) 

###################################################
############### RUN MODEL PER ITT #################
###################################################

itt <- unique(nulldat$itt)
outdat.itt <- data.frame()

for (i in itt){
  dat.itt <- nulldat %>% filter(itt == i)
  lm.myc <- lmer(resp ~ myc + (1|site), dat = dat.itt)
  summary <- summary(lm.myc)
  ref <- lsmeans(lm.myc, pairwise ~ myc, data = dat.itt, pbkrtest.limit = 10000)
  ref.table <- as.data.frame(ref$lsmeans) 
  AM.est <- ref.table %>% filter(myc == "AM") %>% select(lsmean)
  EM.est <- ref.table %>% filter(myc == "EM") %>% select(lsmean)
  AM.se <- ref.table %>% filter(myc == "AM") %>% select(SE) 
  EM.se <- ref.table %>% filter(myc == "EM") %>% select(SE) 
  vals <- cbind(i, AM.est[1,1], EM.est[1,1], AM.se[1,1], EM.se[1,1])
  outdat.itt <- rbind(outdat.itt, vals)
}

colnames(outdat.itt) <- c("itt", "AM.est", "EM.est", "AM.se", "EM.se") 
outdat.itt <- outdat.itt %>% mutate(AM.min = (AM.est - AM.se), AM.max = (AM.est + AM.se)) %>% 
  mutate(EM.min = (EM.est - EM.se), EM.max = (EM.est + EM.se))

# generate 100 points from myc.diff null itt distribution
outdat.itt.dist <- data.frame()
for(i in 1:100){
  set.seed(609)
  dist.AM <- outdat.itt %>% rowwise() %>% mutate(AM.dist = runif(1,min = AM.min, max = AM.max), draw = i, type = "itt")
  dist.EM <- outdat.itt %>% rowwise() %>% mutate(EM.dist = runif(1,min = EM.min, max = EM.max), draw = i, type = "itt") %>%
    select(EM.dist,itt,draw)
  dist.AM.EM <- dist.AM %>% left_join(dist.EM, by = c('itt','draw'))
  outdat.itt.dist <- rbind(dist.AM.EM, outdat.itt.dist)
}

# generate 100 points from myc observed distribution
obs.dat <- cbind("obs", AM.est[1,1], EM.est[1,1], AM.se[1,1], EM.se[1,1]) %>% as.data.frame() 
colnames(obs.dat) <- c("itt", "AM.est", "EM.est", "AM.se", "EM.se") 
obs.dat <- obs.dat %>% 
  mutate(AM.est = as.numeric(AM.est), EM.est = as.numeric(EM.est), AM.se = as.numeric(AM.se),EM.se = as.numeric(EM.se)) %>%
    mutate(AM.min = (AM.est - AM.se), AM.max = (AM.est + AM.se)) %>% 
    mutate(EM.min = (EM.est - EM.se), EM.max = (EM.est + EM.se))

# create output df
outdat.obs.dist <- data.frame()
for(i in 1:100){
  #set.seed(609)
  dist.AM <- obs.dat %>% rowwise() %>% mutate(AM.dist = runif(1,min = AM.min, max = AM.max), draw = i, type = "obs")
  dist.EM <- obs.dat %>% rowwise() %>% mutate(EM.dist = runif(1,min = EM.min, max = EM.max), draw = i, type = "obs") %>%
    select(EM.dist,itt,draw)
  dist.AM.EM <- dist.AM %>% left_join(dist.EM, by = c('itt','draw'))
  outdat.obs.dist <- rbind(dist.AM.EM, outdat.obs.dist)
 }

# join data
outdat.dist <- rbind(outdat.itt.dist, outdat.obs.dist)

###################################################
################## GET OBS V NULL #################
###################################################

# Generate obs diff
obs.AM <- AM.est[1,1]
obs.EM <- EM.est[1,1]
null <- outdat.itt
# Generate p values
p1.AM <- nrow(null %>% filter(AM.est > obs.AM)) / nrow(outdat.itt) # right side
p2.AM <- nrow(null %>% filter(AM.est < obs.AM)) / nrow(outdat.itt) # left side
p1.EM <- nrow(null %>% filter(EM.est > obs.EM)) / nrow(outdat.itt) # right side
p2.EM <- nrow(null %>% filter(EM.est < obs.EM)) / nrow(outdat.itt) # left side

###################################################
########## NULL DISTRIBUTION HISTOGRAM ############
###################################################

# create a custom color scale
colScale <- scale_colour_manual(values=c("darkgrey", "coral3"))
fillScale <- scale_fill_manual(values=c("darkgrey", "coral3"))

# plot mean v null distribution
hist.mean.AM <- 
  ggplot(outdat.itt, aes(x = AM.est)) + 
  xlab("")+ ylab("")+
  geom_histogram(binwidth = 0.00015,colour = "darkgrey", fill = "darkgrey")+
  geom_vline(aes(xintercept = obs.AM),
             color = "coral3", linetype = "dashed", size = 1)+
  xlim(-0.0035,0) +
  theme_classic(base_size = 15)
  
hist.mean.EM <- 
  ggplot(outdat.itt, aes(x = EM.est)) + 
    xlab("")+ ylab("")+
    geom_histogram(binwidth = 0.00015,colour = "darkgrey", fill = "darkgrey")+
    geom_vline(aes(xintercept = obs.EM),
               color = "cyan4", linetype = "dashed", size = 1)+
    #xlim(-0.7,0.2)+
    theme_classic(base_size = 15)
  
# plot mean dist v null distribution
outdat.dist <- outdat.dist %>% 
  rename(Model = type) %>%
  mutate(Model = case_when(Model=="itt" ~ "Null",  
                           Model=="obs" ~ "Global")) 

outdat.dist$Model <- ordered(outdat.dist$Model, levels =c ("Null","Global"))

hist.dist.AM <- 
  ggplot(outdat.dist, aes(x = AM.est, fill = Model), fill = Model) + 
  xlab("Change in AM per-capita sapling density \n (with increasing conmycorrhizal adult density)") + ylab("") +
  geom_histogram(binwidth = 0.00015) +
  theme_classic(base_size = 15) +
  colScale + fillScale +
  xlim(-0.0035,0) +
  theme(legend.position = c(0.9, 0.8))

hist.dist.EM <- 
  ggplot(outdat.dist, aes(x = EM.est, fill = Model), fill = Model) + 
  xlab("Change in EM per-capita sapling density \n (with increasing conmycorrhizal adult density)") + ylab("") +
  geom_histogram(binwidth = 0.0015) +
  theme_classic(base_size = 15) +
  colScale + fillScale +
  #xlim(-0.7,0.2)+
  theme(legend.position = c(0.9, 0.8))

# plot figures

png("figures/null_conhetmycAM_mean_hist.jpg", width = 10, height = 5, units ='in', res = 300)
hist.mean.AM
dev.off()

png("figures/null_conhetmycAM_obsdist_hist.jpg", width = 10, height = 5, units ='in', res = 300)
hist.dist.AM
dev.off()

png("figures/null_conhetmycEM_mean_hist.jpg", width = 10, height = 5, units ='in', res = 300)
hist.mean.EM
dev.off()

png("figures/null_conhetmycEM_obsdist_hist.jpg", width = 10, height = 5, units ='in', res = 300)
hist.dist.EM
dev.off()
