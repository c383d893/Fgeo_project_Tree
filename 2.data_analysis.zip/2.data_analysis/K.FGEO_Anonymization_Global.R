############ ANONYMZE DATA FOR REVISION ###############

## This script joins data and anonmyzises site and species names

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)

###################################################
############## PREP DATA FOR TESTS ################
###################################################
#!!!!CHOOSE ONE, THEN SAVE AS APPROPRIATE NAME AFTER EACH MODEL

###################################################
#################### GLOBAL #######################
###################################################

# CNDD (C-HS): 43 sites, 2097 sp, 2469 sp*site comb
dat <- readRDS("data/conhet_A_spallfromglobal_GAMmodeloutput_allalive.rds") %>% 
  mutate(resp = logit.change.A) 

# CMDD (CMH-HMH): 40 sites, 2065 sp, 2428 sp*site comb
dat <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.CMH) %>%
  drop_na(logit.change.CMH)

###################################################
############### JOIN WITH METADATA ################
###################################################

# load additional data
spdat <- readRDS("data/splevel_meta.rds")
sitedat <- readRDS("data/sitelevel_meta.rds") %>% 
  mutate(CHELSA_BIO_Annual_Mean_Temperature=CHELSA_BIO_Annual_Mean_Temperature/10)
spsitedat <- readRDS("data/spsitelevel_meta.rds")

# join data: species level
dat <- dat %>%
  left_join(spdat, by = c("latin")) %>%
  left_join(sitedat, by = c("site")) %>%
  left_join(spsitedat, by = c("latin","site")) 

# join data: site 
stdat <- dat %>%
  group_by(site) %>%
  summarise(sitendd = weighted.median(resp, lgabund), sprich.val = length(latin)) %>%
  left_join(sitedat, by = "site") %>%
  mutate(prop.spkept = sprich.val/sprich) 

# anonymize stdat:site
stdat.a <- stdat %>% mutate(site = fct_anon(as.factor(site), prefix = "site_")) %>% 
  mutate(site = as.character(site))

# anonymize stdat:site & species
dat.a <- dat %>% mutate(site = fct_anon(as.factor(site), prefix = "site_")) %>% 
  mutate(site = as.character(site)) %>%
  mutate(latin = fct_anon(as.factor(latin), prefix = "sp_")) %>% 
  mutate(latin = as.character(latin))
  
# save ; for CDD global
saveRDS(stdat.a, "data/CDDglobal_sitedata.rds")
saveRDS(dat.a, "data/CDDglobal_data.rds")

# save as .csv; for CMDD global
saveRDS(stdat.a, "data/CMDDglobal_sitedata.rds")
saveRDS(dat.a, "data/CMDDglobal_data.rds")
