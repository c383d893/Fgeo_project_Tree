############## MAIN ANALYSES FOR MS ###############

## This script carries out analyses for CDD and CMDD
## Examines correlations: across different ranges for CDD; across sp*site and global models
## Plots global relationships
## Tests site level predictions
## Tests species level predictions
## Generates plots

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)
library(lsmeans)
library(ggeffects)
library(lme4)
library(lmerTest)
library(gridExtra)
library(spatstat)
library(mgcv)
library(ape)
library(MuMIn)

#create a custom color scale
colScale <- scale_colour_manual(values = c("darkorchid3", "mediumseagreen"))
fillScale <- scale_fill_manual(values = c("darkorchid3", "mediumseagreen"))

###################################################
############## PREP DATA FOR TESTS ################
###################################################
#!!!!CHOOSE ONE , THEN SAVE AS APPROPRIATE NAME AFTER EACH MODEL

###################################################
#################### GLOBAL #######################
###################################################

# CNDD (C-HS): 43 sites, 2097 sp, 2469 sp*site comb
dat <- readRDS("data/CDDglobal_data.rds") 
stdat <-readRDS("data/CDDglobal_sitedata.rds")

# CMDD (CMH-HMH): 40 sites, 2065 sp, 2428 sp*site comb
dat <- readRDS("data/CMDDglobal_data.rds") 
stdat <-readRDS("data/CMDDglobal_sitedata.rds")

###################################################
###################################################
############# MODELS AND PLOTS CDD ################
###################################################
###################################################

# Choose one
DDtype <- "Change in per-capita sapling density \n (with increasing conspecific adult density)"
DDtype <- "Change in per-capita sapling density \n (with increasing conmycorrhizal adult density)"

###################################################
############### GLM SITE ANALYSIS #################
###################################################

###################################################
#################### RICHNESS #####################
###################################################

lm.rich <- glm(sitendd ~ sprich, dat = stdat)       
summary(lm.rich)

new.dat <- with(stdat, expand.grid(sprich = seq(min(sprich), max(sprich), length = 100))) 
pred.rich <- predict(lm.rich,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(sprich = new.dat$sprich)

St.Rich <-
  ggplot(data = pred.rich, mapping = aes(x = sprich, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = sprich, y = sitendd), alpha = 0.5) +
  xlab("Species richness") + ylab(DDtype) +
  theme_classic(base_size = 15) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale +
  ylim(-2,1) 

St.Rich_CS_2cat <- St.Rich
St.Rich_CM_3cat <- St.Rich

###################################################
################ PHYLO RICHNESS ###################
###################################################

lm.phyrich <- glm(sitendd ~ faith, dat = stdat)       
summary(lm.phyrich)

new.dat <- with(stdat, expand.grid(faith = seq(min(na.omit(faith)), max(na.omit(faith)), length = 100))) 
pred <- predict(lm.phyrich,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(faith=new.dat$faith)

St.PhyRich  <-
  ggplot(data = pred, mapping = aes(x = faith, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha = 0.1) +
  geom_point(data = stdat, mapping = aes(x = faith, y = sitendd), alpha = 0.5) +
  xlab("Phylogenetic species richness") + ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale +
  ylim(-2,1)

St.PhyRich_CS_2cat <- St.PhyRich
St.PhyRich_CM_3cat <- St.PhyRich

###################################################
#################### LATITUDE #####################
###################################################
  
lm.lat <- glm(sitendd ~ abslat, dat = stdat)  
summary(lm.lat)

new.dat <- with(stdat, expand.grid(abslat = seq(min(abslat), max(abslat), length = 100))) 
pred.sp <- predict(lm.lat,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslat=new.dat$abslat)

St.Lat <-
  ggplot(data = pred.sp, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = lat, y = sitendd), alpha = 0.5) +
  xlab("Absolute latitude") + ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale+
  ylim(-2,1)

St.Lat_CS_2cat <- St.Lat
St.Lat_CM_3cat <- St.Lat

###################################################
#################### PROP EM ######################
###################################################

lm.pmyc <- glm(sitendd ~ poly(propEM, 2, raw = TRUE), dat = stdat)        
summary(lm.pmyc)

new.dat <- with(stdat, expand.grid(propEM = seq(min(na.omit(propEM)), max(na.omit(propEM)), length = 100))) 
pred.pEM <- predict(lm.pmyc,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(propEM=new.dat$propEM)

St.EMp <-
  ggplot(data = pred.pEM, mapping = aes(x = propEM, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = propEM, y = sitendd), alpha = 0.5) +
  xlab(DDtype) +ylab("Proportion EM plant species") + 
  #geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  colScale+fillScale

St.EMp_CS_2cat <- St.EMp
St.EMp_CM_3cat <- St.EMp

###################################################
#################### TEMPERATURE ##################
###################################################

lm.temp <- glm(sitendd ~ CHELSA_BIO_Annual_Mean_Temperature, dat = stdat)               
summary(lm.temp)

new.dat <- with(stdat, expand.grid(CHELSA_BIO_Annual_Mean_Temperature = seq(min(CHELSA_BIO_Annual_Mean_Temperature), max(CHELSA_BIO_Annual_Mean_Temperature), length = 100))) 
pred <- predict(lm.temp,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(CHELSA_BIO_Annual_Mean_Temperature=new.dat$CHELSA_BIO_Annual_Mean_Temperature)

St.Temp <-
  ggplot(data = pred, mapping = aes(x = CHELSA_BIO_Annual_Mean_Temperature, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = CHELSA_BIO_Annual_Mean_Temperature, y = sitendd), alpha = 0.5) +
  xlab("Mean annual temperature (\u00B0C)") + ylab("") +
  ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  ylim(-2,1)

St.Temp_CS_2cat <- St.Temp
St.Temp_CM_3cat <- St.Temp

###################################################
################# PRECIPITATION ###################
###################################################

lm.prec <- glm(sitendd ~ CHELSA_BIO_Annual_Precipitation, dat = stdat)               
summary(lm.prec)

new.dat <- with(stdat, expand.grid(CHELSA_BIO_Annual_Precipitation = seq(min(CHELSA_BIO_Annual_Precipitation), max(CHELSA_BIO_Annual_Precipitation), length = 100))) 
pred <- predict(lm.prec,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(CHELSA_BIO_Annual_Precipitation=new.dat$CHELSA_BIO_Annual_Precipitation)

St.Prec <-
  ggplot(data = pred, mapping = aes(x = CHELSA_BIO_Annual_Precipitation, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = CHELSA_BIO_Annual_Precipitation, y = sitendd), alpha = 0.5) +
  xlab("Mean annual precipitation (mm)") + ylab("") +
  ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  ylim(-2,1)

St.Prec_CS_2cat <- St.Prec
St.Prec_CM_3cat <- St.Prec

###################################################
############### LATITUDE V RICHNESS ###############
###################################################

lm.lat.sp <- glm(sprich ~ poly(abslat, 2, raw = TRUE), dat = stdat)  
summary(lm.lat.sp)

new.dat <- with(stdat, expand.grid(abslat = seq(min(abslat), max(abslat), length = 100))) 
pred.latsp <- predict(lm.lat.sp,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslat=new.dat$abslat)

St.Lat.sp <-
  ggplot(data = pred.latsp, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich), alpha = 0.5) +
  xlab("Absolute latitude") + ylab("Species richness") +
  theme_classic(base_size = 25) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale 

St.Lat.sp_CS_2cat <- St.Lat.sp
St.Lat.sp_CM_3cat <- St.Lat.sp

###################################################
############## LATITUDE V PROP EM #################
###################################################

lm.pmyc.lat <- glm(propEM~poly(abslat,2, raw=TRUE), dat = stdat)               
summary(lm.pmyc.lat)

new.dat <- with(stdat, expand.grid(abslat = seq(min(abslat), max(abslat), length = 100))) 
pred.latEM <- predict(lm.pmyc.lat,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslat=new.dat$abslat)

St.LatEMp <-
  ggplot(data = pred.latEM, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = propEM), alpha = 0.5) +
  xlab("Absolute latitude") +
  ylab("Proportion EM plant species") +
  theme_classic(base_size = 15) +
  colScale+ fillScale

St.LatEMp_CS_2cat <- St.LatEMp
St.LatEMp_CM_3cat <- St.LatEMp

###################################################
############ JOIN LATITUDE BY PROP EM #############
################### AND RICHNESS ##################
###################################################

ggplot(data = pred.latEM, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = propEM), alpha = 0.5) 

ggplot(data = pred.latsp, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich), alpha = 0.5) 

scale <- max(stdat$sprich)
ggplot(data = pred.latsp, mapping = aes(x = abslat, y = fit/scale)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit/scale-se.fit/scale, ymax = fit/scale+se.fit/scale), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich/scale), alpha = 0.5) 

LatvSprcih.propEM <- ggplot(data = pred.latEM, mapping = aes(x = abslat, y = fit)) +
  geom_line(color = "mediumseagreen") +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1,color = "mediumseagreen", fill = "mediumseagreen") +
  geom_point(data = stdat, mapping = aes(x = abslat, y = propEM), alpha = 0.5,color = "mediumseagreen", fill = "mediumseagreen",size= 3) +
  geom_line(data = pred.latsp, mapping = aes(x = abslat, y = fit/scale), color = "darkgrey") +
  geom_ribbon(data = pred.latsp, aes(ymin = fit/scale-se.fit/scale, ymax = fit/scale+se.fit/scale), alpha =  0.1, color = "darkgrey", fill = "darkgrey") +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich/scale), alpha = 0.5,color = "darkgrey", fill = "darkgrey", size =3) +
  xlab("Absolute latitude") +
  scale_y_continuous(
  name = "Proportion species richness",
  sec.axis = sec_axis( trans=~.*1, name="Proportion EM tree species")) +
  theme_classic(base_size = 20) +
  theme(axis.title.y = element_text(color = "darkgrey"),
  axis.title.y.right = element_text(color = "mediumseagreen"))

LatvSprcih.propEM_CS_2cat <- LatvSprcih.propEM

###################################################
############## GLM SPECIES ANALYSIS ###############
###################################################

###################################################
################### MYC TYPE ######################
###################################################
#dat <- dat.temp

lm.myc <- lmer(resp ~ myc + (1|site), dat = dat)
summary(lm.myc)
r.squaredGLMM(lm.myc)

# Test CMH different from zero
datAM <- dat %>% filter(myc == "AM")
hist(datAM$logit.change.CMH) #normal
t.test(datAM$logit.change.CMH, alternative = "greater", mu = 0) #sp p-value = 0.0001444; gb p-value = 9.413e-11

datEM <- dat %>% filter(myc == "EM")
hist(datEM$logit.change.CMH)
t.test(datEM$logit.change.CMH, alternative = "greater", mu = 0) #sp p-value = 0.9993; gb p-value = 0.3429

ref <- lsmeans(lm.myc, pairwise ~ myc, data = dat,pbkrtest.limit = 10000)
ref.table <- as.data.frame(ref$lsmeans) 

resid.resp <- residuals(lm.myc, type = "response")
pred.for.resid <- predict(lm.myc,type = "response")

resid <- dat %>%
  mutate(resid = resid.resp, pred = pred.for.resid) %>%
  mutate(resid.f = resid + pred) 

Sp.Myc <-
  ggplot(ref.table, aes(x = myc, lsmean, color = myc)) + 
  geom_point(position = position_dodge(1), size = 4) + 
  geom_errorbar(aes(ymin = lsmean - SE, ymax = lsmean + SE), width = 0.5, size = 1, position = position_dodge(1)) + 
  geom_point(data = dat,aes(x = myc, y = resp, color = myc),position=position_jitter(width = 0.25), alpha = 0.15) +
  xlab("Mycorrhizal type") + ylab(DDtype) +
  #ylim(-.015,.015) + #CMDD GB
  ylim(-8,2) + # CNDD
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  colScale+fillScale+
  theme(legend.title = element_blank(),legend.position = c(.98, .98),legend.justification = c("right", "top")) 

Sp.Myc_CS_2cat <- Sp.Myc
Sp.Myc_CM_3cat <- Sp.Myc

###################################################
############### MYC TYPE BY SITE ##################
###################################################

lm.myc.s <- glm(resp ~ myc*site, dat = dat)      
summary(lm.myc.s)
r.squaredGLMM(lm.myc.s)

ref <- lsmeans(lm.myc.s, pairwise ~ myc*site, data = dat)
ref.table <- as.data.frame(ref$lsmeans) 

Sp.Myc.St <-
  ggplot(ref.table, aes(x = site, lsmean, color = myc,fill = myc)) + 
  geom_point(stat = "identity",position = position_dodge(1), alpha = 0.7, size = 3) +
  geom_errorbar(aes(ymin = lsmean - SE, ymax = lsmean + SE), width = 0.5,size = 1, position = position_dodge(1)) + 
  xlab(" ") + ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  colScale+fillScale+
  coord_flip() +
  theme(legend.position = "none")+
  facet_grid(~myc)

Sp.Myc.St_CS_2cat <- Sp.Myc.St
Sp.Myc.St_CM_3cat <- Sp.Myc.St

###################################################
################## ABUNDANCE ######################
###################################################

lm.abund <- gam(resp~s(lgabund),  dat = dat)
summary(lm.abund)

datplot <- ggpredict(lm.abund, terms = c("lgabund [all]"))

Sp.Abund <-
  ggplot(data = datplot,aes(x = x, y = predicted)) +
  geom_point(data = dat, mapping = aes(x = lgabund, y = resp, color = myc), alpha = 0.4) +
  xlab("log (Abundance)") + ylab(DDtype) +
  theme_classic(base_size = 15) +
  colScale+fillScale+
  geom_line(alpha = 0.8, size = 1.5) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.3) +
  #ylim(-3,3) +
  #xlim(4,10) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme(legend.position = "none")

Sp.Abund_CS_2cat <- Sp.Abund
Sp.Abund_CM_3cat <- Sp.Abund

###################################################
################### PLOT FIGS #####################
###################################################

##############################
####### SP*SITE MODELS #######
######### CDD 2 CAT ##########
##############################

# CDD and lat:
#png("figures/SS_Lat_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
#St.Lat_CS_2cat
#dev.off()

# CDD myc type: 
#png("figures/SS_Sp.Myc_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
#Sp.Myc_CS_2cat
#dev.off()

# CDD myc type by site: 
#png("figures/SS_Sp.Myc.St_CS_2cat.jpg", width = 8, height = 15, units = 'in', res = 300)
#Sp.Myc.St_CS_2cat
#dev.off()

# Lat sp richness and prop EM:
#png("figures/SS_LatvSprcih.propEM.jpg", width = 6, height = 5, units = 'in', res = 300)
#LatvSprcih.propEM_CS_2cat
#dev.off()

##############################
####### SP*SITE MODELS #######
######### CMDD 3 CAT #########
##############################

# CMDD myc type:
#png("figures/SS_Sp.Myc_CM_3cat.jpg", width = 5, height = 5, units = 'in', res = 300)
#Sp.Myc_CM_3cat 
#dev.off()

# CMDD myc type by site:
#png("figures/GB_Sp.Myc.St_CM_3cat.jpg", width = 8, height = 15, units = 'in', res = 300)
#Sp.Myc.St_CM_3cat
#dev.off()

##############################
####### GLOBAL MODELS ########
######### CDD 2 CAT ##########
##############################

# CDD and lat:
png("figures/GB_Lat_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.Lat_CS_2cat
dev.off()

# CDD and lat:
png("figures/GB_LatEMp_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.LatEMp_CS_2cat
dev.off()

# CDD myc type: 
png("figures/GB_Sp.Myc_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
Sp.Myc_CS_2cat
dev.off()

# CDD myc type by site: 
png("figures/GB_Sp.Myc.St_CS_2cat.jpg", width = 10, height = 10, units = 'in', res = 300)
Sp.Myc.St_CS_2cat
dev.off()

# CDD and temp
png("figures/GB_Temp_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.Temp_CS_2cat
dev.off()

# CDD and precip
png("figures/GB_Prec_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.Prec_CS_2cat
dev.off()

# CDD and abund
png("figures/GB_Abund_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
Sp.Abund_CS_2cat
dev.off()

# Lat sp richness and prop EM:
png("figures/GB_LatvSprich.propEM.jpg", width = 6.25, height = 5, units = 'in', res = 300)
LatvSprcih.propEM_CS_2cat
dev.off()

##############################
####### GLOBAL MODELS ########
######### CMDD 3 CAT #########
##############################

# CMDD myc type:
png("figures/GB_Sp.Myc_CM_3cat.jpg", width = 5, height = 5, units = 'in', res = 300)
Sp.Myc_CM_3cat 
dev.off()

# CMDD myc type by site:
png("figures/GB_Sp.Myc.St_CM_3cat.jpg", width = 10, height = 10, units = 'in', res = 300)
Sp.Myc.St_CM_3cat
dev.off()