############## MAIN ANALYSES FOR MS ###############

## This script carries out analyses for CDD and CMDD
## Examines correlations: across different ranges for CDD; across sp*site and global models
## Plots global relationships
## Tests site level predictions
## Tests species level predictions
## Generates plots

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)
library(lsmeans)
library(ggeffects)
library(lme4)
library(lmerTest)
library(gridExtra)
library(spatstat)
library(mgcv)
library(ape)
library(MuMIn)

#create a custom color scale
colScale <- scale_colour_manual(values = c("darkorchid3", "mediumseagreen"))
fillScale <- scale_fill_manual(values = c("darkorchid3", "mediumseagreen"))

###################################################
############ EXAMINE CNDD CORRELATIONS ############
################ SP * SITE MODELS #################
###################################################

# CNDD cutoff 0.5
dat5 <- readRDS("data/conhet_0.5_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.A) %>%
  select(c('site', 'latin', 'logit.change.A')) %>%
  rename(logit.change.5 = logit.change.A)

# CNDD cutoff 0.75
dat75 <- readRDS("data/conhet_0.75_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.A) %>%
  select(c('site', 'latin', 'logit.change.A')) %>%
  rename(logit.change.75 = logit.change.A)

# CNDD cutoff 1.0
dat1 <- readRDS("data/conhet_1_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.A)%>%
  select(c('site', 'latin', 'logit.change.A')) %>%
  rename(logit.change.1 = logit.change.A)

pair.dat <- dat5 %>%
  full_join(dat75,by = c('site', 'latin')) %>%
  full_join(dat1,by = c('site', 'latin')) %>%
  select(-c('site', 'latin'))

png("figures/pair.ranges_A_sp*site.jpg", width = 10, height = 10, units = 'in', res = 300)
pairs(pair.dat)
dev.off()

mean(cor(na.omit(pair.dat)))

###################################################
############ EXAMINE CNDD CORRELATIONS ############
############ SP * SITE V GLOBAL MODELS ############
###################################################

# CNDD: SP *SITE
dat <- readRDS("data/conhet_1_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.A) %>%
  select(c('site','latin','logit.change.A')) %>%
  rename(logit.change.A = logit.change.A)

# CNDD: GLOBAL
dat.G <- readRDS("data/conhet_A_spallfromglobal_GAMmodeloutput_allalive.rds") %>% 
  mutate(resp = logit.change.A) %>%
  select(c('site', 'latin', 'logit.change.A')) %>%
  rename(logit.change.AG = logit.change.A)

pair.dat2 <- dat %>%
  full_join(dat.G,by =c('site','latin')) %>%
  select(-c('site','latin'))

png("figures/pair.ranges_A_GLBsp*site.jpg", width = 10, height = 10, units ='in', res = 300)
lm.test <- lm(logit.change.AG~logit.change.A, data = pair.dat2)
ggplot(dat = pair.dat2,aes(x = logit.change.A, y = logit.change.AG)) +
  geom_point() +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", size = 1, color = "red") +
  theme_classic()
dev.off()

###################################################
############ EXAMINE CMDD CORRELATIONS ############
############ SP * SITE V GLOBAL MODELS ############
###################################################

# CMDD: SP *SITE
dat <- readRDS("data/conhetmyc_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.CMH) %>%
  select(c('site', 'latin', 'logit.change.CMH')) %>%
  rename(logit.change.CMH = logit.change.CMH)

# CMDD: GLOBAL
dat.G <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.CMH) %>%
  select(c('site', 'latin', 'logit.change.CMH')) %>%
  rename(logit.change.CMHG = logit.change.CMH)

pair.dat2 <- dat %>%
  full_join(dat.G,by = c('site', 'latin')) %>%
  select(-c('site' ,'latin'))

png("figures/pair.ranges_CMH_GLBsp*site.jpg", width = 10, height = 10, units = 'in', res = 300)
ggplot(dat = pair.dat2,aes(x = logit.change.CMH, y = logit.change.CMHG)) +
  geom_point() +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", size = 1, color = "red") +
  theme_classic()
dev.off()

###################################################
############### FULL GLOBAL MODELS ################
######## RANDOM SLOPE & INTERCEPT SP*SITE #########
#################### CONHETMYC ####################
###################################################

###################################################
################### READ DATA ##################### 
###################################################

mod <- readRDS('data/conhetmyc_spintslope_globalGAMmodeloutput_allalive.rds')

spdat <- readRDS("data/splevel_meta.rds") %>% rename(species = latin) %>% select(c('species', 'myc'))
loc.dat <- readRDS('data/conhetmyc_spsite_localdat_allalive.rds') %>% mutate(site_sp = paste(site, species, sep = "_")) %>%
  left_join(spdat, by = "species")  
  
loc.scales <- loc.dat %>% group_by(site, species) %>% # normalize to max of specific curve.
    summarize(scaleA = max(fit.A), scaleCMH = max(fit.CMH)) 

loc.dat <- loc.dat %>%
  left_join(loc.scales, by = c("site", "species")) %>%
  mutate(fit.norm.A = fit.A/scaleA) %>%
  mutate(fit.norm.CMH = fit.CMH/scaleCMH)

loc.dat.AM <- loc.dat %>% filter(myc == "AM")
loc.dat.EM <- loc.dat %>% filter(myc == "EM")

#Summary 

#Parametric coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept) -138.048      3.198 -43.166  < 2e-16 ***
#  mycEM         72.059     10.228   7.045 1.86e-12 ***

#Approximate significance of smooth terms:
#  edf   Ref.df         F p-value    
#s(A):mycAM             1.978    1.999 9.690e+02  <2e-16 ***
#  s(A):mycEM             1.008    1.017 4.684e+01  <2e-16 ***
#  s(CMHa):mycAM          1.969    1.988 7.123e+01  <2e-16 ***
#  s(CMHa):mycEM          1.001    1.002 3.235e+00  0.0722 .  
#s(HMHa)                1.974    1.999 1.498e+02  <2e-16 ***
#  s(sitespecies)      2149.110 2426.000 2.961e+06  <2e-16 ***
#  s(A,sitespecies)    2288.508 2426.000 1.013e+04  <2e-16 ***
#  s(CMHa,sitespecies) 1769.764 2426.000 6.550e+05  <2e-16 ***

#R-sq.(adj) =  0.352   Deviance explained = 38.2%
#fREML = 2.8844e+06  Scale est. = 1         n = 2546424

###################################################
################### PREDICT #######################
###################################################

new.dat.AM.A <- with(mod$model, expand.grid(A = seq(min(A), max(A), length = 1000))) %>% 
  mutate(CMHa = mean(mod$model$CMHa),HMHa = mean(mod$model$HMHa), myc = "AM")
pred.AM.A <- predict.gam(mod,newdata = new.dat.AM.A, type = "response", se = TRUE, newdata.guaranteed = TRUE, 
                         exclude = c("s(sitespecies)", "s(A,sitespecies)", "s(CMHa,sitespecies)")) %>%
  as.data.frame() %>% 
  mutate(A = new.dat.AM.A$A) 
scale = max(pred.AM.A$fit) +max(pred.AM.A$se.fit)
pred.AM.A <- pred.AM.A %>%
  mutate(fit.norm = fit/max(scale), se.fit.norm = se.fit/max(scale))
  
new.dat.EM.A <- with(mod$model, expand.grid(A = seq(min(A), max(A), length = 1000))) %>% 
  mutate(CMHa = mean(mod$model$CMHa),HMHa = mean(mod$model$HMHa),  myc = "EM")
pred.EM.A <- predict.gam(mod,newdata = new.dat.EM.A, type = "response", se = TRUE, newdata.guaranteed = TRUE, 
                         exclude = c("s(sitespecies)", "s(A,sitespecies)", "s(CMHa,sitespecies)")) %>%
  as.data.frame() %>% 
  mutate(A = new.dat.EM.A$A)
scale = max(pred.EM.A$fit) + max(pred.EM.A$se.fit)
pred.EM.A <- pred.EM.A %>%
  mutate(fit.norm = fit/max(scale),se.fit.norm = se.fit/max(scale))

new.dat.AM.CMH <- with(mod$model, expand.grid(CMHa = seq(min(CMHa), max(CMHa), length = 1000))) %>% 
  mutate(A=mean(mod$model$A),HMHa=mean(mod$model$HMHa), myc="AM")
pred.AM.CMH <- predict.gam(mod,newdata = new.dat.AM.CMH, type = "response", se = TRUE, newdata.guaranteed = TRUE, 
                         exclude = c("s(sitespecies)", "s(A,sitespecies)", "s(CMHa,sitespecies)")) %>%
  as.data.frame() %>% 
  mutate(CMH = new.dat.AM.CMH$CMH)
scale = max(pred.AM.CMH$fit) + max(pred.AM.CMH$se.fit)
pred.AM.CMH <- pred.AM.CMH %>%
  mutate(fit.norm = fit/max(scale), se.fit.norm = se.fit/max(scale))

new.dat.EM.CMH <- with(mod$model, expand.grid(CMHa = seq(min(CMHa), max(CMHa), length = 1000))) %>% 
  mutate(A=mean(mod$model$A),HMHa=mean(mod$model$HMHa),  myc="EM")
pred.EM.CMH <- predict.gam(mod,newdata = new.dat.EM.CMH, type = "response", se = TRUE, newdata.guaranteed = TRUE, 
                         exclude = c("s(sitespecies)", "s(A,sitespecies)", "s(CMHa,sitespecies)")) %>%
  as.data.frame() %>% 
  mutate(CMH = new.dat.EM.CMH$CMH)
scale = max(pred.EM.CMH$fit) +max(pred.EM.CMH$se.fit)
pred.EM.CMH <- pred.EM.CMH %>%
  mutate(fit.norm = fit/max(scale), se.fit.norm = se.fit/max(scale))

###################################################
##################### PLOT ########################
###################################################

conhetmyc_global.AMEM.A <- 
  ggplot() +
  geom_line(data = pred.AM.A, mapping = aes(x = A, y = fit), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.A, aes(x = A, ymin = fit - se.fit, ymax = fit + se.fit), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.A, mapping = aes(x = A, y = fit), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.A, aes(x = A, ymin = fit - se.fit, ymax = fit + se.fit), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Per-capita sapling density") +
  xlab("Conspecific adult stem density") +
  ylim(0,2.75) + xlim(0,5)

conhetmyc_global.AMEM.A.norm <- 
  ggplot() +
  geom_line(data = pred.AM.A, mapping = aes(x = A, y = fit.norm), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.A, aes(x= A, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.A, mapping = aes(x = A, y = fit.norm), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.A, aes(x= A, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Proportion maximum per-capita sapling density") +
  xlab("Conspecific adult stem density") +
  ylim(0,1) + xlim(0,5)

conhetmyc_global.AMEM.CMH <- 
  ggplot() +
  geom_line(data = pred.AM.CMH, mapping = aes(x = CMH, y = fit), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.CMH, aes(x= CMH, ymin = fit - se.fit, ymax = fit + se.fit), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.CMH, mapping = aes(x = CMH, y = fit), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.CMH, aes(x= CMH, ymin = fit - se.fit, ymax = fit + se.fit), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Per-capita sapling density") +
  xlab("Conmycorrhizal adult stem density") +
  ylim(0,7.5) + xlim(0,400)

conhetmyc_global.AMEM.CMH.norm <- 
  ggplot() +
  geom_line(data = pred.AM.CMH, mapping = aes(x = CMH, y = fit.norm), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.CMH, aes(x= CMH, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.CMH, mapping = aes(x = CMH, y = fit.norm), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.CMH, aes(x= CMH, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Proportion maximum per-capita sapling density") +
  xlab("Conmycorrhizal adult stem density") +
  ylim(0,1) + xlim(0,400)

conhetmyc_globallocal.AMEM.A <-
  ggplot() +
  geom_line(data = loc.dat.AM, mapping = aes(x = A, y = fit.A, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = loc.dat.EM, mapping = aes(x = A, y = fit.A, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = pred.AM.A, mapping = aes(x = A, y = fit), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.A, aes(x= A, ymin = fit - se.fit, ymax = fit + se.fit), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.A, mapping = aes(x = A, y = fit), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.A, aes(x= A, ymin = fit - se.fit, ymax = fit + se.fit), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Per-capita sapling density") +
  xlab("Conspecific adult stem density") +
  ylim(0,3) + xlim(0,5)

conhetmyc_globallocal.AMEM.A.norm <-
  ggplot() +
  geom_line(data = loc.dat.AM, mapping = aes(x = A, y = fit.norm.A, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = loc.dat.EM, mapping = aes(x = A, y = fit.norm.A, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = pred.AM.A, mapping = aes(x = A, y = fit.norm), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.A, aes(x= A, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.A, mapping = aes(x = A, y = fit.norm), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.A, aes(x= A, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Proportion maximum per-capita sapling density") +
  xlab("Conspecific adult stem density") +
  ylim(0,1) + xlim(0,5)

conhetmyc_globallocal.AMEM.CMH <-
  ggplot() +
  geom_line(data = loc.dat.AM, mapping = aes(x = CMHa, y = fit.CMH, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = loc.dat.EM, mapping = aes(x = CMHa, y = fit.CMH, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = pred.AM.CMH, mapping = aes(x = CMH, y = fit), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.CMH, aes(x= CMH, ymin = fit - se.fit, ymax = fit + se.fit), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.CMH, mapping = aes(x = CMH, y = fit), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.CMH, aes(x= CMH, ymin = fit - se.fit, ymax = fit + se.fit), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Per-capita sapling density") +
  xlab("Conmycorrhizal adult stem density") +
  ylim(0,7.5) + xlim(0,400)

conhetmyc_globallocal.AMEM.CMH.norm <-
  ggplot() +
  geom_line(data = loc.dat.AM, mapping = aes(x = CMHa, y = fit.norm.CMH, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = loc.dat.EM, mapping = aes(x = CMHa, y = fit.norm.CMH, group=site_sp), alpha=0.02,color = "darkgrey") +
  geom_line(data = pred.AM.CMH, mapping = aes(x = CMH, y = fit.norm), color = "darkorchid3") +
  geom_ribbon(data = pred.AM.CMH, aes(x= CMH, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "darkorchid3", alpha = 0.3) +
  geom_line(data = pred.EM.CMH, mapping = aes(x = CMH, y = fit.norm), color = "mediumseagreen") +
  geom_ribbon(data = pred.EM.CMH, aes(x= CMH, ymin=fit.norm-se.fit.norm, ymax=fit.norm+se.fit.norm), fill = "mediumseagreen", alpha = 0.3) +
  theme_classic(base_size = 15) +
  ylab("Proportion maximum per-capita sapling density") +
  xlab("Conmycorrhizal adult stem density") +
  ylim(0,1) + xlim(0,400)

png("figures/conhetmyc_global_percap_AMEM_A.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_global.AMEM.A)
dev.off()

png("figures/conhetmyc_global_proppercap_AMEM_A.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_global.AMEM.A.norm)
dev.off()

png("figures/conhetmyc_globallocal_percap_AMEM_A.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_globallocal.AMEM.A)
dev.off()

png("figures/conhetmyc_globallocal_proppercap_AMEM_A.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_globallocal.AMEM.A.norm)
dev.off()

png("figures/conhetmyc_global_percap_AMEM_CMH.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_global.AMEM.CMH)
dev.off()

png("figures/conhetmyc_global_proppercap_AMEM_CMH.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_global.AMEM.CMH.norm)
dev.off()

png("figures/conhetmyc_globallocal_percap_AMEM_CMH.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_globallocal.AMEM.CMH)
dev.off()

png("figures/conhetmyc_globallocal_proppercap_AMEM_CMH.jpg", width = 5, height = 5, units ='in', res = 300)
grid.arrange(conhetmyc_globallocal.AMEM.CMH.norm)
dev.off()

###################################################
##################### HIST CM #####################
###################################################

# read dat
all.dat <- readRDS("data/conhet_allcensusdata_withmyc_allquad_allalive.rds")

# ba prop myc stems: AM
bapropmyc.AM <- all.dat %>% 
  mutate(ba = 3.141593*(dbh/2)^2) %>%
  group_by(site,quadrat,myc) %>%   
  summarise(totba = sum(ba)) %>%
  mutate(prop = totba / sum(totba)) %>%
  filter(myc =="AM") %>%
  mutate(prop = replace_na(prop, 0)) %>%
  rename(propAM = prop) %>%
  select(-totba,-myc) %>%
  ungroup()

# ba prop myc stems: EM
bapropmyc.EM <- all.dat %>% 
  mutate(ba = 3.141593*(dbh/2)^2) %>%
  group_by(site,quadrat,myc) %>%   
  summarise(totba = sum(ba)) %>%
  mutate(prop = totba / sum(totba)) %>%
  filter(myc=="EM") %>%
  mutate(prop = replace_na(prop, 0)) %>%
  rename(propEM = prop) %>%
  select(-totba,-myc) %>%
  ungroup()

# join AM and EM together and replace NA with zero
bapropmyc <- bapropmyc.AM %>% full_join(bapropmyc.EM, by = c("site", "quadrat")) %>%
  mutate(propAM = replace_na(propAM, 0)) %>%
  mutate(propEM = replace_na(propEM, 0)) 

# extact AM ba
bapropmyc.AM <- bapropmyc %>% select(site,quadrat,propAM) %>% rename(prop=propAM) %>% mutate(myc="AM")
# extract EM ba
bapropmyc.EM <- bapropmyc %>% select(site,quadrat,propEM) %>% rename(prop=propEM) %>% mutate(myc="EM")
# join together
bapropmyc <- rbind(bapropmyc.AM, bapropmyc.EM)

# plot AM propba histogram
mycpropba_hist <- 
  ggplot(bapropmyc.AM, aes(x = prop, color =  "darkorchid3", fill = "darkorchid3"), fill = "darkorchid3", color = "darkorchid3") +
  geom_histogram(color = "black", binwidth = 0.04, alpha = 0.5) +
  theme_classic(base_size = 20) +
  xlab("Proportion AM per basal area") +
  ylab("Quadrat density") +
  fillScale+colScale +
  theme(legend.position = "none",
       axis.text.y = element_text(angle = 45))

png("figures/mycpropba_hist.jpg", width = 5.5, height = 5, units = 'in', res = 600)
mycpropba_hist
dev.off()

###################################################
############## PREP DATA FOR TESTS ################
###################################################
#!!!!CHOOSE ONE, THEN SAVE AS APPROPRIATE NAME AFTER EACH MODEL

###################################################
################## PER SPECIES ####################
###################################################

# CNDD (C-HS): 29 sites, 1647 sp, 1889 sp*site comb
dat <- readRDS("data/conhet_1_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.A) 

# CNDD (A-HMH): 25 sites
#dat <- readRDS("data/conhetmyc_GAM.output_allalive.rds") %>% 
#  mutate(resp = logit.change.A) %>%
#  drop_na(logit.change.A)

# CMDD (CMH-HMH): 18 sites, 1318 sp, 1388 sp*site comb
dat <- readRDS("data/conhetmyc_GAM.output_allalive.rds") %>% 
 mutate(resp = logit.change.CMH) %>%
 drop_na(logit.change.CMH) 

###################################################
#################### GLOBAL #######################
###################################################

# CNDD (C-HS): 43 sites, 2097 sp, 2469 sp*site comb
dat <- readRDS("data/conhet_A_spallfromglobal_GAMmodeloutput_allalive.rds") %>% 
  mutate(resp = logit.change.A) 

# CNDD (A-HMH): 40 sites
# dat <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>% 
#  mutate(resp = logit.change.A) %>%
#  drop_na(logit.change.A) 

# CMDD (CMH-HMH): 40 sites, 2065 sp, 2428 sp*site comb
dat <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>% 
  mutate(resp = logit.change.CMH) %>%
  drop_na(logit.change.CMH)

###################################################
############### JOIN WITH METADATA ################
###################################################

# load additional data
spdat <- readRDS("data/splevel_meta.rds")
sitedat <- readRDS("data/sitelevel_meta.rds") %>% 
  mutate(CHELSA_BIO_Annual_Mean_Temperature=CHELSA_BIO_Annual_Mean_Temperature/10)
spsitedat <- readRDS("data/spsitelevel_meta.rds")

# join data: species level
dat <- dat %>%
  left_join(spdat, by = c("latin")) %>%
  left_join(sitedat, by = c("site")) %>%
  left_join(spsitedat, by = c("latin","site")) 

# join data: site 
stdat <- dat %>%
  group_by(site) %>%
  summarise(sitendd = weighted.median(resp, lgabund), sprich.val = length(latin)) %>%
  left_join(sitedat, by = "site") %>%
  mutate(prop.spkept = sprich.val/sprich) 

# save as .csv; for CDD global
write.csv(stdat, "data/CDDglobal_sitedata.csv")

###################################################
###################################################
############# MODELS AND PLOTS CDD ################
###################################################
###################################################

# Choose one
DDtype <- "Change in per-capita sapling density \n (with increasing conspecific adult density)"
DDtype <- "Change in per-capita sapling density \n (with increasing conmycorrhizal adult density)"

###################################################
################# DENSITY PLOTS ###################
###################################################

den.plot <-
  ggplot(data = dat, mapping = aes(x = resp, color = myc, fill = myc)) +
  geom_density(alpha = 0.3) +
  xlab(DDtype) + ylab(" ") +
  coord_flip() +
  xlim(-5,2) +
  geom_vline(xintercept = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  theme(legend.position = "none") +
  colScale+ fillScale

den.plot_CS_2cat <- den.plot
den.plot_CS_3cat <- den.plot
den.plot_CM_3cat <- den.plot

###################################################
############### GLM SITE ANALYSIS #################
###################################################

###################################################
#################### RICHNESS #####################
###################################################

lm.rich <- glm(sitendd ~ sprich, dat = stdat)       
summary(lm.rich)

new.dat <- with(stdat, expand.grid(sprich = seq(min(sprich), max(sprich), length = 100))) 
pred.rich <- predict(lm.rich,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(sprich = new.dat$sprich)

St.Rich <-
  ggplot(data = pred.rich, mapping = aes(x = sprich, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = sprich, y = sitendd), alpha = 0.5) +
  xlab("Species richness") + ylab(DDtype) +
  theme_classic(base_size = 15) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale +
  ylim(-2,1) 

St.Rich_CS_2cat <- St.Rich
St.Rich_CS_3cat <- St.Rich
St.Rich_CM_3cat <- St.Rich

###################################################
################ PHYLO RICHNESS ###################
###################################################

lm.phyrich <- glm(sitendd ~ faith, dat = stdat)       
summary(lm.phyrich)

new.dat <- with(stdat, expand.grid(faith = seq(min(na.omit(faith)), max(na.omit(faith)), length = 100))) 
pred <- predict(lm.phyrich,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(faith=new.dat$faith)

St.PhyRich  <-
  ggplot(data = pred, mapping = aes(x = faith, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha = 0.1) +
  geom_point(data = stdat, mapping = aes(x = faith, y = sitendd), alpha = 0.5) +
  xlab("Phylogenetic species richness") + ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale +
  ylim(-2,1)

St.PhyRich_CS_2cat <- St.PhyRich
St.PhyRich_CS_3cat <- St.PhyRich
St.PhyRich_CM_3cat <- St.PhyRich

###################################################
#################### LATITUDE #####################
###################################################
  
lm.lat <- glm(sitendd ~ abslat, dat = stdat)  
summary(lm.lat)

new.dat <- with(stdat, expand.grid(abslat = seq(min(abslat), max(abslat), length = 100))) 
pred.sp <- predict(lm.lat,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslat=new.dat$abslat)

St.Lat <-
  ggplot(data = pred.sp, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = lat, y = sitendd), alpha = 0.5) +
  xlab("Absolute latitude") + ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale+
  ylim(-2,1)

St.Lat_CS_2cat <- St.Lat
St.Lat_CS_3cat <- St.Lat
St.Lat_CM_3cat <- St.Lat

###################################################
#################### PROP EM ######################
###################################################

lm.pmyc <- glm(sitendd ~ poly(propEM, 2, raw = TRUE), dat = stdat)        
#lm.pmyc<-glm(sitendd~propEM, dat = stdat)        
summary(lm.pmyc)

new.dat <- with(stdat, expand.grid(propEM = seq(min(na.omit(propEM)), max(na.omit(propEM)), length = 100))) 
pred.pEM <- predict(lm.pmyc,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(propEM=new.dat$propEM)

St.EMp <-
  ggplot(data = pred.pEM, mapping = aes(x = propEM, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = propEM, y = sitendd), alpha = 0.5) +
  xlab(DDtype) +ylab("Proportion EM plant species") + 
  #geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  colScale+fillScale

St.EMp_CS_2cat <- St.EMp
St.EMp_CS_3cat <- St.EMp
St.EMp_CM_3cat <- St.EMp

###################################################
#################### TEMPERATURE ##################
###################################################

lm.temp <- glm(sitendd ~ CHELSA_BIO_Annual_Mean_Temperature, dat = stdat)               
summary(lm.temp)

new.dat <- with(stdat, expand.grid(CHELSA_BIO_Annual_Mean_Temperature = seq(min(CHELSA_BIO_Annual_Mean_Temperature), max(CHELSA_BIO_Annual_Mean_Temperature), length = 100))) 
pred <- predict(lm.temp,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(CHELSA_BIO_Annual_Mean_Temperature=new.dat$CHELSA_BIO_Annual_Mean_Temperature)

St.Temp <-
  ggplot(data = pred, mapping = aes(x = CHELSA_BIO_Annual_Mean_Temperature, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = CHELSA_BIO_Annual_Mean_Temperature, y = sitendd), alpha = 0.5) +
  xlab("Mean annual temperature (\u00B0C)") + ylab("") +
  ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  ylim(-2,1)

St.Temp_CS_2cat <- St.Temp
St.Temp_CS_3cat <- St.Temp
St.Temp_CM_3cat <- St.Temp

###################################################
################# PRECIPITATION ###################
###################################################

lm.prec <- glm(sitendd ~ CHELSA_BIO_Annual_Precipitation, dat = stdat)               
summary(lm.prec)

new.dat <- with(stdat, expand.grid(CHELSA_BIO_Annual_Precipitation = seq(min(CHELSA_BIO_Annual_Precipitation), max(CHELSA_BIO_Annual_Precipitation), length = 100))) 
pred <- predict(lm.prec,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(CHELSA_BIO_Annual_Precipitation=new.dat$CHELSA_BIO_Annual_Precipitation)

St.Prec <-
  ggplot(data = pred, mapping = aes(x = CHELSA_BIO_Annual_Precipitation, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = CHELSA_BIO_Annual_Precipitation, y = sitendd), alpha = 0.5) +
  xlab("Mean annual precipitation (mm)") + ylab("") +
  ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  ylim(-2,1)

St.Prec_CS_2cat <- St.Prec
St.Prec_CS_3cat <- St.Prec
St.Prec_CM_3cat <- St.Prec

###################################################
############### LATITUDE V RICHNESS ###############
###################################################

lm.lat.sp <- glm(sprich ~ poly(abslat, 2, raw = TRUE), dat = stdat)  
summary(lm.lat.sp)

new.dat <- with(stdat, expand.grid(abslat = seq(min(abslat), max(abslat), length = 100))) 
pred.latsp <- predict(lm.lat.sp,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslat=new.dat$abslat)

St.Lat.sp <-
  ggplot(data = pred.latsp, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich), alpha = 0.5) +
  xlab("Absolute latitude") + ylab("Species richness") +
  theme_classic(base_size = 25) +
  scale_x_continuous(minor_breaks = 6) +
  colScale + fillScale 

St.Lat.sp_CS_2cat <- St.Lat.sp
St.Lat.sp_CS_3cat <- St.Lat.sp
St.Lat.sp_CM_3cat <- St.Lat.sp

###################################################
############## LATITUDE V PROP EM #################
###################################################

lm.pmyc.lat <- glm(propEM~poly(abslat,2, raw=TRUE), dat = stdat)               
summary(lm.pmyc.lat)

new.dat <- with(stdat, expand.grid(abslat = seq(min(abslat), max(abslat), length = 100))) 
pred.latEM <- predict(lm.pmyc.lat,newdata = new.dat,type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslat=new.dat$abslat)

St.LatEMp <-
  ggplot(data = pred.latEM, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = propEM), alpha = 0.5) +
  xlab("Absolute latitude") +
  ylab("Proportion EM plant species") +
  theme_classic(base_size = 15) +
  colScale+ fillScale

St.LatEMp_CS_2cat <- St.LatEMp
St.LatEMp_CS_3cat <- St.LatEMp
St.LatEMp_CM_3cat <- St.LatEMp

###################################################
############ JOIN LATITUDE BY PROP EM #############
################### AND RICHNESS ##################
###################################################

ggplot(data = pred.latEM, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = propEM), alpha = 0.5) 

ggplot(data = pred.latsp, mapping = aes(x = abslat, y = fit)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich), alpha = 0.5) 

scale <- max(stdat$sprich)
ggplot(data = pred.latsp, mapping = aes(x = abslat, y = fit/scale)) +
  geom_line() +
  geom_ribbon(aes(ymin = fit/scale-se.fit/scale, ymax = fit/scale+se.fit/scale), alpha =  0.1) +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich/scale), alpha = 0.5) 

LatvSprcih.propEM <- ggplot(data = pred.latEM, mapping = aes(x = abslat, y = fit)) +
  geom_line(color = "mediumseagreen") +
  geom_ribbon(aes(ymin = fit - se.fit, ymax = fit + se.fit), alpha =  0.1,color = "mediumseagreen", fill = "mediumseagreen") +
  geom_point(data = stdat, mapping = aes(x = abslat, y = propEM), alpha = 0.5,color = "mediumseagreen", fill = "mediumseagreen",size= 3) +
  geom_line(data = pred.latsp, mapping = aes(x = abslat, y = fit/scale), color = "darkgrey") +
  geom_ribbon(data = pred.latsp, aes(ymin = fit/scale-se.fit/scale, ymax = fit/scale+se.fit/scale), alpha =  0.1, color = "darkgrey", fill = "darkgrey") +
  geom_point(data = stdat, mapping = aes(x = abslat, y = sprich/scale), alpha = 0.5,color = "darkgrey", fill = "darkgrey", size =3) +
  xlab("Absolute latitude") +
  scale_y_continuous(
  name = "Proportion species richness",
  sec.axis = sec_axis( trans=~.*1, name="Proportion EM tree species")) +
  theme_classic(base_size = 20) +
  theme(axis.title.y = element_text(color = "darkgrey"),
  axis.title.y.right = element_text(color = "mediumseagreen"))

LatvSprcih.propEM_CS_2cat <- LatvSprcih.propEM
LatvSprcih.propEM_CS_3cat <- LatvSprcih.propEM

###################################################
############## GLM SPECIES ANALYSIS ###############
###################################################

###################################################
################### MYC TYPE ######################
###################################################
#dat <- dat.temp

lm.myc <- lmer(resp ~ myc + (1|site), dat = dat)
summary(lm.myc)
r.squaredGLMM(lm.myc)

# Test CMH different from zero
datAM <- dat %>% filter(myc == "AM")
hist(datAM$logit.change.CMH) #normal
t.test(datAM$logit.change.CMH, alternative = "greater", mu = 0) #sp p-value = 0.0001444; gb p-value = 9.413e-11

datEM <- dat %>% filter(myc == "EM")
hist(datEM$logit.change.CMH)
t.test(datEM$logit.change.CMH, alternative = "greater", mu = 0) #sp p-value = 0.9993; gb p-value = 0.3429

ref <- lsmeans(lm.myc, pairwise ~ myc, data = dat,pbkrtest.limit = 10000)
ref.table <- as.data.frame(ref$lsmeans) 

resid.resp <- residuals(lm.myc, type = "response")
pred.for.resid <- predict(lm.myc,type = "response")

resid <- dat %>%
  mutate(resid = resid.resp, pred = pred.for.resid) %>%
  mutate(resid.f = resid + pred) 

Sp.Myc <-
  ggplot(ref.table, aes(x = myc, lsmean, color = myc)) + 
  geom_point(position = position_dodge(1), size = 4) + 
  geom_errorbar(aes(ymin = lsmean - SE, ymax = lsmean + SE), width = 0.5, size = 1, position = position_dodge(1)) + 
  geom_point(data = dat,aes(x = myc, y = resp, color = myc),position=position_jitter(width = 0.25), alpha = 0.15) +
  xlab("Mycorrhizal type") + ylab(DDtype) +
  #ylim(-.015,.015) + #CMDD GB
  ylim(-8,2) + # CNDD
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  colScale+fillScale+
  theme(legend.title = element_blank(),legend.position = c(.98, .98),legend.justification = c("right", "top")) 

Sp.Myc_CS_2cat <- Sp.Myc
Sp.Myc_CS_3cat <- Sp.Myc
Sp.Myc_CM_3cat <- Sp.Myc

###################################################
############### MYC TYPE BY SITE ##################
###################################################

lm.myc.s <- glm(resp ~ myc*site, dat = dat)      
summary(lm.myc.s)
r.squaredGLMM(lm.myc.s)

ref <- lsmeans(lm.myc.s, pairwise ~ myc*site, data = dat)
ref.table <- as.data.frame(ref$lsmeans) %>%
  left_join(sitedat, by = "site") %>%
  arrange(abslat)

ref.table <- ref.table %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "-", " "))
ref.table <- ref.table %>% 
  mutate(site = case_when(site == "BCI" ~ "Barro Colorado Island",
                          site == "Temple" ~ "Temple University",
                          site == "University of Maryland" ~ "University of Maryland Baltimore County",
                          site == "SCBI" ~ "Smithsonian Conservation Biology Institute",
                          site == "SERC" ~ "Smithsonian Environmental Research Center",
                          site == "FOREG 22" ~ "Low Elevation Andrews Satellite Plot",
                          site == "FOREG 02" ~ "High Elevation Andrews Satellite Plot",
                          site == "FOREG 31" ~ "Andrews",
                          site == "Little Dickie Woods" ~ "Lilly Dickey Woods",
                          TRUE ~ as.character(site)))
Sp.Myc.St <-
  ggplot(ref.table, aes(x = reorder(site, abslat), lsmean, color = myc,fill = myc)) + 
  geom_point(stat = "identity",position = position_dodge(1), alpha = 0.7, size = 3) +
  geom_errorbar(aes(ymin = lsmean - SE, ymax = lsmean + SE), width = 0.5,size = 1, position = position_dodge(1)) + 
  xlab(" ") + ylab(DDtype) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme_classic(base_size = 15) +
  colScale+fillScale+
  coord_flip() +
  theme(legend.position = "none")+
  facet_grid(~myc)

Sp.Myc.St_CS_2cat <- Sp.Myc.St
Sp.Myc.St_CS_3cat <- Sp.Myc.St
Sp.Myc.St_CM_3cat <- Sp.Myc.St

###################################################
################## ABUNDANCE ######################
###################################################

lm.abund <- gam(resp~s(lgabund),  dat = dat)
summary(lm.abund)

datplot <- ggpredict(lm.abund, terms = c("lgabund [all]"))

Sp.Abund <-
  ggplot(data = datplot,aes(x = x, y = predicted)) +
  geom_point(data = dat, mapping = aes(x = lgabund, y = resp, color = myc), alpha = 0.4) +
  xlab("log (Abundance)") + ylab(DDtype) +
  theme_classic(base_size = 15) +
  colScale+fillScale+
  geom_line(alpha = 0.8, size = 1.5) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.3) +
  #ylim(-3,3) +
  #xlim(4,10) +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  theme(legend.position = "none")

Sp.Abund_CS_2cat <- Sp.Abund
Sp.Abund_CS_3cat <- Sp.Abund
Sp.Abund_CM_3cat <- Sp.Abund

###################################################
################### PLOT FIGS #####################
###################################################

##############################
####### SP*SITE MODELS #######
######### CDD 2 CAT ##########
##############################

# CDD and lat:
#png("figures/SS_Lat_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
#St.Lat_CS_2cat
#dev.off()

# CDD myc type: 
#png("figures/SS_Sp.Myc_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
#Sp.Myc_CS_2cat
#dev.off()

# CDD myc type by site: 
#png("figures/SS_Sp.Myc.St_CS_2cat.jpg", width = 8, height = 15, units = 'in', res = 300)
#Sp.Myc.St_CS_2cat
#dev.off()

# Lat sp richness and prop EM:
#png("figures/SS_LatvSprcih.propEM.jpg", width = 6, height = 5, units = 'in', res = 300)
#LatvSprcih.propEM_CS_2cat
#dev.off()

##############################
####### SP*SITE MODELS #######
######### CMDD 3 CAT #########
##############################

# CMDD myc type:
#png("figures/SS_Sp.Myc_CM_3cat.jpg", width = 5, height = 5, units = 'in', res = 300)
#Sp.Myc_CM_3cat 
#dev.off()

# CMDD myc type by site:
#png("figures/GB_Sp.Myc.St_CM_3cat.jpg", width = 8, height = 15, units = 'in', res = 300)
#Sp.Myc.St_CM_3cat
#dev.off()

##############################
####### GLOBAL MODELS ########
######### CDD 2 CAT ##########
##############################

# CDD and lat:
png("figures/GB_Lat_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.Lat_CS_2cat
dev.off()

# CDD and lat:
png("figures/GB_LatEMp_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.LatEMp_CS_2cat
dev.off()

# CDD myc type: 
png("figures/GB_Sp.Myc_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
Sp.Myc_CS_2cat
dev.off()

# CDD myc type by site: 
png("figures/GB_Sp.Myc.St_CS_2cat.jpg", width = 10, height = 10, units = 'in', res = 300)
Sp.Myc.St_CS_2cat
dev.off()

# CDD and temp
png("figures/GB_Temp_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.Temp_CS_2cat
dev.off()

# CDD and precip
png("figures/GB_Prec_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
St.Prec_CS_2cat
dev.off()

# CDD and abund
png("figures/GB_Abund_CS_2cat.jpg", width = 5, height = 5, units = 'in', res = 300)
Sp.Abund_CS_2cat
dev.off()

# Lat sp richness and prop EM:
png("figures/GB_LatvSprich.propEM.jpg", width = 6.25, height = 5, units = 'in', res = 300)
LatvSprcih.propEM_CS_2cat
dev.off()

##############################
####### GLOBAL MODELS ########
######### CMDD 3 CAT #########
##############################

# CMDD myc type:
png("figures/GB_Sp.Myc_CM_3cat.jpg", width = 5, height = 5, units = 'in', res = 300)
Sp.Myc_CM_3cat 
dev.off()

# CMDD myc type by site:
png("figures/GB_Sp.Myc.St_CM_3cat.jpg", width = 10, height = 10, units = 'in', res = 300)
Sp.Myc.St_CM_3cat
dev.off()