#### CHECK FOR PHYLOGENETIC SIGNAL IN CDD/CMDD ####

## This script calculates pagel's lambda for CDD and CMDD

###################################################
################# SET UP PACKAGES #################
###################################################

library(phytools)
library(pez)
library(picante)
library(data.table)
library(ggplot2)
library(tidyverse)

#############################
#### CDD PAGELS LAMBDA ######
#############################

# read data, keep unique species
dat <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>%
  distinct(latin, .keep_all = TRUE) %>%
  mutate(latin = as.character(latin))

# get meancdd & join with dat
meancndd <- dat %>%
  group_by(latin) %>%
  summarise(logit.change.A = mean(logit.change.A))

# join meancdd to dat  
dat <- dat %>%
  select(-logit.change.A)%>%
  left_join(meancndd, by = "latin")

# name rows
rownames(dat) <- dat$latin

# load master tree
load("data/GBOTB.extended.rda")
phy <- GBOTB.extended
# merge congenerics
phy.ex <- congeneric.merge(phy, dat$latin, split = "_", cite = FALSE)

# convert phy to dataframe
alltreesp <- c(phy.ex$tip.label) %>% as.data.frame()          
# rename column
colnames(alltreesp) <- "latin"
# extract species in dataset
nodrop <- dat %>% select(latin)           
# extract non overlapping species to drop
todrop <- setdiff(alltreesp, nodrop) %>% as.vector()                 
# set to vector
todrop <- c(t(todrop))                      
# drop tips/prune
p.tree <- drop.tip(phy.ex, unlist(todrop))


# subset dat to include only latin in tips of tree:
dat <- dat %>% filter(latin %in% p.tree$tip.label)

# match row order tree and dat
dat <- dat[match(p.tree$tip.label,rownames(dat)),]

# calculate pagels lambda
dat2 <- dat[, c("logit.change.A", "logit.change.CMH")]
phylosig(p.tree, as.matrix(dat2)[,c("logit.change.A")]) 
# Phylogenetic signal K: 0.0131664

##############################
#### CMDD PAGELS LAMBDA ######
##############################

# read data, keep unique species
dat <- readRDS("data/conhetmyc_Global_GAM.output_allalive.rds") %>%
  distinct(latin, .keep_all=TRUE) %>%
  mutate(latin = as.character(latin))

# get meancdd & join with dat
meancmdd <- dat %>%
  group_by(latin) %>%
  summarise(logit.change.CMH = mean(logit.change.CMH))

# join meancdd to dat  
dat <- dat %>%
  select(-logit.change.CMH) %>%
  left_join(meancmdd, by="latin")

# name rows
rownames(dat) <- dat$latin

# load master tree
load("data/GBOTB.extended.rda")
phy <- GBOTB.extended

#merge congenerics
phy.ex <- congeneric.merge(phy, dat$latin, split = "_", cite = FALSE)

# convert phy to dataframe
alltreesp <- c(phy.ex$tip.label) %>% as.data.frame()          
# rename column
colnames(alltreesp) <- "latin"
# extract species in dataset
nodrop <- dat %>% select(latin)           
# extract non overlapping species to drop
todrop <- setdiff(alltreesp, nodrop) %>% as.vector()                 
# set to vector
todrop <- c(t(todrop))                      
# drop tips/prune
p.tree <- drop.tip(phy.ex, unlist(todrop))

# subset dat to include only latin in tips of tree:
dat <- dat %>% filter(latin %in% p.tree$tip.label)

# match row order tree and dat
dat <- dat[match(p.tree$tip.label,rownames(dat)),]

# calculate pagels lambda
dat2 <- dat[, c("logit.change.A", "logit.change.CMH")]
phylosig(p.tree, as.matrix(dat2)[,c("logit.change.CMH")]) 
# Phylogenetic signal K: 