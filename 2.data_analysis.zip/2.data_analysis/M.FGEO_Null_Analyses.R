############## NULL ANALYSES FOR MS ###############
################# CONHET VERSION ##################

## This script takes null data and compares it to observed data
## First, compares med value of AM v EM CDD (diff) to null distribution
## Then, compares distribution of AM v EM CDD (diff) to null distribution

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)
library(lsmeans)
library(ggeffects)
library(lme4)
library(lmerTest)
library(gridExtra)
library(spatstat)
library(mgcv)

###################################################
################### LOAD DATA #####################
###################################################

# read cdd data
dat <- readRDS("data/conhet_A_spallfromglobal_GAMmodeloutput_allalive.rds") %>% 
  mutate(resp = logit.change.A) 

###################################################
############### JOIN WITH METADATA ################
###################################################

# load additional data
spdat <- readRDS("data/splevel_meta.rds")
sitedat <- readRDS("data/sitelevel_meta.rds") %>% 
  mutate(CHELSA_BIO_Annual_Mean_Temperature = CHELSA_BIO_Annual_Mean_Temperature/100, 
         CHELSA_BIO_Annual_Precipitation = CHELSA_BIO_Annual_Precipitation/100)
spsitedat <- readRDS("data/spsitelevel_meta.rds")

# join data: species level
dat <- dat %>%
  left_join(spdat, by = c("latin")) %>%
  left_join(sitedat, by = c("site")) %>%
  left_join(spsitedat, by = c("latin","site")) 

# join data: site 
stdat <- dat %>% 
  group_by(site) %>%
  summarise(sitendd = weighted.median(resp, lgabund), sprich.val = length(latin))%>%
  left_join(sitedat, by = "site") %>%
  mutate(prop.spkept = sprich.val/sprich) 
lm.myc <- lmer(resp ~ myc + (1|site), dat = dat)
summary.obs <- summary(lm.myc)
anova(lm.myc, test = "LRT")

# generate CDD estimates
ref <- lsmeans(lm.myc, pairwise ~ myc, data = dat, pbkrtest.limit = 10000)
ref.table <- as.data.frame(ref$lsmeans) 
obs.ref.table <- ref.table

AM.est <- ref.table %>% filter(myc == "AM") %>% select(lsmean) # CDD -1.302053
EM.est <- ref.table %>% filter(myc == "EM") %>% select(lsmean) # CDD -0.7536914

###################################################
############ NULL COMPARISON AMEM CDD #############
###################################################

###################################################
################### LOAD DATA #####################
###################################################

nulldat <- readRDS("data/null_conhet/null_conhet_A_spallfromglobal_GAMmodeloutput_allalive.rds") %>% 
  mutate(resp = logit.change.A) 

###################################################
############### JOIN WITH METADATA ################
###################################################

# join data: species level
nulldat <- nulldat %>%
  left_join(spdat, by= c("latin")) %>%
  left_join(sitedat, by= c("site")) %>%
  left_join(spsitedat, by = c("latin","site")) 

###################################################
############### RUN MODEL PER ITT #################
###################################################

itt <- unique(nulldat$itt)
outdat.itt <- data.frame()

for (i in itt){
  dat.itt <- nulldat %>% filter(itt == i)
  lm.myc <- lmer(resp ~ myc + (1|site), dat = dat.itt)
  summary <- summary(lm.myc)
  p.val <- summary$coefficient[2,5]
  se <- summary$coefficient[2,2]
  ref <- lsmeans(lm.myc, pairwise ~ myc, data = dat.itt, pbkrtest.limit = 10000)
  ref.table <- as.data.frame(ref$lsmeans) 
  AM.est <- ref.table %>% filter(myc == "AM") %>% select(lsmean)
  EM.est <- ref.table %>% filter(myc == "EM") %>% select(lsmean)
  vals <- cbind(i, p.val, se, AM.est[1,1], EM.est[1,1])
  outdat.itt <- rbind(outdat.itt, vals)
}

colnames(outdat.itt) <- c("itt", "p.val", "myc.se", "AM.est", "EM.est") 
outdat.itt <- outdat.itt %>%  mutate(myc.diff = AM.est - EM.est) %>% mutate(min = (myc.diff - myc.se), max = (myc.diff + myc.se))

# generate 100 points from myc.diff null itt distribution
outdat.itt.dist<- data.frame()
for(i in 1:100){
  set.seed(609)
  dist <- outdat.itt %>% rowwise() %>% mutate(myc.diff.dist = runif(1,min = min, max = max), draw = i, type = "itt")
  outdat.itt.dist <- rbind(dist, outdat.itt.dist)
}

# generate 100 points from myc.diff observed distribution
p.val <- summary.obs$coefficient[2,5]
se <- summary.obs$coefficient[2,2]
AM.est <- obs.ref.table %>% filter(myc=="AM") %>% select(lsmean)
EM.est <- obs.ref.table %>% filter(myc=="EM") %>% select(lsmean)
obs.dat <- cbind("obs", p.val, se, AM.est[1,1], EM.est[1,1]) %>% as.data.frame() 
colnames(obs.dat) <- c("itt", "p.val", "myc.se", "AM.est", "EM.est") 
obs.dat <- obs.dat %>%  
  mutate(p.val = as.numeric(p.val), myc.se = as.numeric(myc.se), AM.est = as.numeric(AM.est), EM.est = as.numeric(EM.est)) %>%
  mutate(myc.diff = AM.est-EM.est) %>% mutate(min = (myc.diff - myc.se), max = (myc.diff + myc.se))

# create output df
outdat.obs.dist <- data.frame()
for(i in 1:100){
  #set.seed(609)
  dist <- obs.dat %>% rowwise() %>% mutate(myc.diff.dist = runif(1,min = min, max = max), draw = i, type = "obs")
  outdat.obs.dist <- rbind(dist, outdat.obs.dist)
}

# join data
outdat.dist <- rbind(outdat.itt.dist, outdat.obs.dist)

###################################################
############ GET AMEM DIFF OBS V NULL #############
###################################################

# Generate obs diff
obs.diff <- AM.est[1,1] - EM.est[1,1]
null.diff <- outdat.itt
# Generate p values
p1 <- nrow(null.diff %>% filter(myc.diff > obs.diff)) / nrow(outdat.itt) # right side
p2 <- nrow(null.diff %>% filter(myc.diff < obs.diff)) / nrow(outdat.itt) # left side

###################################################
########## NULL DISTRIBUTION HISTOGRAM ############
###################################################

# create a custom color scale
colScale <- scale_colour_manual(values=c("darkgrey", "coral3"))
fillScale <- scale_fill_manual(values=c("darkgrey", "coral3"))

# plot mean v null distribution
hist.mean <- 
  ggplot(outdat.itt, aes(x = myc.diff)) + 
  xlab("")+ ylab("")+
  geom_histogram(binwidth = 0.015,colour = "darkgrey", fill = "darkgrey")+
  geom_vline(aes(xintercept = obs.diff),
             color = "coral3", linetype = "dashed", size = 1)+
  xlim(-0.7,0.2)+
  theme_classic(base_size = 15)

# plot mean dist v null distribution
outdat.dist <- outdat.dist %>% 
  rename(Model = type) %>%
  mutate(Model = case_when(Model=="itt" ~ "Null",  
                           Model=="obs" ~ "Global")) 

outdat.dist$Model <- ordered(outdat.dist$Model, levels =c ("Null","Global"))

hist.dist <- 
  ggplot(outdat.dist, aes(x = myc.diff.dist, fill = Model), fill = Model) + 
  xlab("Change in per-capita sapling density \n (with increasing conspecific adult density)") + ylab("") +
  geom_histogram(binwidth = 0.015) +
  theme_classic(base_size = 15) +
  colScale + fillScale +
  xlim(-0.7,0.2)+
  theme(legend.position = c(0.9, 0.8))

# plot figures

png("figures/null_conhet_mean_hist.jpg", width = 10, height = 5, units ='in', res = 300)
hist.mean
dev.off()

png("figures/null_conhet_obsdist_hist.jpg", width = 10, height = 5, units ='in', res = 300)
hist.dist
dev.off()
