########## RUN SPECIES BY SITE GAM MODELS #########
######## EXTRACT PREDICTIONS FOR ANALYSIS #########
################# CONHET VERSION ##################

## This script runs species by site nb GAM recruitment models
## Creates global data across all site data; makes local model predictions along full range for each species
## Determines optimal conspecific adult ('A') range, min and max to maintain maximum # of species
## Runs predictions on this range for each species
## Predictions test the change in recruitment in a stand at med total density (medT:69.27627) from max to min conspecifics (1 range used for analyses)

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)  
library(mgcv)  

###################################################
############### SET UP FUNCTIONS ##################
###################################################

source("functions/dispersal1.R")
source("functions/dispersal2.R")
source("functions/dispersal3.R")
source("functions/DistWeighted.R")

###################################################
################## SET UP PARS ####################
###################################################

abundance = 'stem'			            

###################################################
################## BRING IN DAT ###################
###################################################

# read in dist weighted list
dist.weighted.list <- readRDS('data/conhet_density_dependence.input.data_allalive.rds')
# unique sites in list
site <- unique(names(dist.weighted.list)) 

###################################################
################# RUN GAM MODELS ##################
###################################################

# set.seed
set.seed(609)
# create list for output
mod.list <- list() 
for (k in site) { 
  # create list for site
  site.list <- list()
  # print site
  print(k)
  # create list for site
  lp.dat = dist.weighted.list[[k]]
  # unique species in plot
  species = unique(lp.dat$species)	
  # number of species in plot
  SP = length(species)	
  # run model for each species
  for(i in 1:SP) {
    if(lp.dat$N[i] > tr & lp.dat$adultquads[i] > 9 & lp.dat$sapquads[i] > 9) {
      tbl = data.frame(A = lp.dat$adultDistWeightedAbund[,i], ln_A = log(lp.dat$adultDistWeightedAbund[,i]),Ha = lp.dat$HadultDistWeightedAbund[,i], Hs = lp.dat$HsapDistWeightedAbund[,i],
                       CMa = lp.dat$CMadultDistWeightedAbund[,i], CMs = lp.dat$CMsapDistWeightedAbund[,i], CMHa = lp.dat$CMHadultDistWeightedAbund[,i],
                       CMHs = lp.dat$CMHsapDistWeightedAbund[,i], HMHa = lp.dat$HMHadultDistWeightedAbund[,i], HMHs = lp.dat$HMHsapDistWeightedAbund[,i], S = lp.dat$saplings[,i]) 
      mod2 <- gam(S ~ s(A,k=3) + s(Ha,k=3), offset = (ln_A), family = nb(link = "log"), data = tbl) 
      #save output under species
      site.list[[as.character(species[i])]] <- list(mod2) 
      # name model
      names(site.list[[as.character(species[i])]]) <- c("mod2") 
    }
    # save site under model.list
    mod.list[[k]] <- site.list 
  }
}

# save df as .rds object
saveRDS(mod.list, 'data/conhet_GAMmodeloutputs_allalive.rds')

###################################################
##### DETERMINE RANGES AND MED TOTAL DENSITY ######
###################################################

# read list
mod.list <- readRDS('data/conhet_GAMmodeloutputs_allalive.rds')
# remove null
mod.list <- compact(mod.list) 

# A range
# create dataframe
tree.range.dat.A <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # print site
  print(i)
  # save site.dat
  site.dat <- mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get A.range and save values
    A.range <- species.dat[["mod2"]]$model$A
    min.A <- min(A.range)
    max.A <- max(A.range)
    med.A <- median(A.range)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], min.A, max.A, med.A)
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("min.A", "max.A", "med.A"), as.character) %>% mutate_at(c("min.A", "max.A", "med.A"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  tree.range.dat.A <- rbind(output.site, tree.range.dat.A)
} 

# add column names
colnames(tree.range.dat.A) <- c("site", "species", "min.A", "max.A", "med.A")

# H range 
# create dataframe
tree.range.dat.H <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # print site
  print(i)
  # save site.dat
  site.dat <- mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get H.range and save values
    H.range <- species.dat[["mod2"]]$model$Ha
    min.H <- min(H.range)
    max.H <- max(H.range)
    med.H <- median(H.range)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], min.H, max.H, med.H)
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("min.H", "max.H", "med.H"), as.character) %>% mutate_at(c("min.H", "max.H", "med.H"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  tree.range.dat.H <- rbind(output.site, tree.range.dat.H)
} 

# add column names
colnames(tree.range.dat.H) <- c("site", "species", "min.H", "max.H", "med.H")

# join A and H tree range
tree.range.dat <- tree.range.dat.A %>%
  left_join(tree.range.dat.H, by = c("site","species")) %>% 
  mutate_if(is.numeric, round,digits = 3) 

# calculate total density for each observation
# create dataframe
total.density.plots.sp <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat <- mod.list[[i]]
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get ranges and save values
    A.range <- species.dat[["mod2"]]$model$A
    H.range <- species.dat[["mod2"]]$model$Ha
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], A.range,H.range) 
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("A.range", "H.range"), as.character) %>% mutate_at(c("A.range", "H.range"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  total.density.plots.sp <- rbind(output.site, total.density.plots.sp)
} 

# add column names
colnames(total.density.plots.sp) <- c("site", "species", "A.range", "H.range")

# mean total density across dataset
total.density.plots <- total.density.plots.sp %>% 
  mutate(T = A.range + H.range)
medT <- median(total.density.plots$T)
median(total.density.plots$A.range)

###################################################
############## GLOBAL DATA & MOD ##################
######### 'GLOBAL' FOR THIS *MOD DATA* ############
###################################################

# read list
mod.list <- readRDS('data/conhet_GAMmodeloutputs_allalive.rds')
# remove null
mod.list <- compact(mod.list)

# create dataframe
glob.dat <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get data and save: model: model frame containing all variables needed in original model fit.
    dat <- species.dat[["mod2"]]$model
    # join all info at species level and join to site
    out.dat<- cbind(names(mod.list)[i], names(site.dat)[s], dat) 
    output.species <- rbind(output.species, out.dat)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  glob.dat <- rbind(output.site, glob.dat)
} 

# add column names
colnames(glob.dat) <- c("site", "species", "S", "A", "Ha", "offset") 
glob.dat <- glob.dat %>% mutate(ln_A = log(A))

# save df as .rds object
saveRDS(glob.dat, 'data/conhet_spsite_globaldat_allalive.rds')
# read df
glob.dat <- readRDS('data/conhet_spsite_globaldat_allalive.rds')

###################################################
###################################################
########### LOCAL MODELS PREDICTIONS ##############
###################################################
###################################################

# create dataframe
loc.dat.A <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # create new dat and predict
    new.dat <- with(species.dat[['mod2']]$model, expand.grid(A = seq(min(A), max(A), length = 10))) %>% 
      mutate(Ha=mean(species.dat[['mod2']]$model$Ha))
    pred<-predict.gam(species.dat[['mod2']], newdata = new.dat, type = "response", se = TRUE) %>%
      as.data.frame() %>% 
      mutate(A = new.dat$A)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], pred) 
    output.species <- rbind(output.species, out.dat)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  loc.dat.A <- rbind(output.site, loc.dat.A)
} 

# add column names
colnames(loc.dat.A) <- c("site", "species", "fit", "se.fit", "A") 
loc.dat <- loc.dat.A %>% mutate(site_sp = paste(site, species, sep = "_"))

# save df as .rds object
saveRDS(loc.dat.A, 'data/conhet_spsite_localdat_allalive.rds')

###################################################
###################################################
############### DETERMINE OPTIMAL A ###############
###################################################
###################################################

# determine a values that are possible across entire dataset
values.a <- with(glob.dat, expand.grid(A = seq(min(A), max(A), length = 10000))) %>%
  rename(maxV = A) %>%      
  # set [- val] to range across which to test
  # mutate(minV = maxV - 0.5) %>%
  # mutate(minV = maxV - 0.75) %>%
   mutate(minV = maxV - 1.0) %>% 
  # make sure all ranges are greater than 0
  filter(minV >= 0)

# determine subset and count for each possible range
out.dat <- data.frame()
for(i in 1:nrow(values.a)) {
  row <- values.a[i,]
  # filter A and H values
  tree.range.dat.filt.A <- tree.range.dat %>% filter(min.A <= row$minV & max.A >= row$maxV)
  tree.range.dat.filt.A.H <- tree.range.dat.filt.A %>% filter(min.H < medT-max.A & max.H > medT-min.A)
  # sprich
  sprich <- nrow(tree.range.dat.filt.A.H)
  # propsp
  propsp <- sprich/nrow(tree.range.dat)
  sp.out.dat <- cbind(sprich, propsp) 
  # join to other sp outputs
  out.dat <- rbind(out.dat, sp.out.dat)
}

out.dat.full <- cbind(out.dat,values.a)
out.dat.full.maxsp <- out.dat.full %>% arrange(desc(sprich)) %>% slice(1)
out.dat.full.maxsp

#  sprich    propsp    maxV       minV
#0.5: 1889 0.7650871 0.7558998 0.2558998
#0.75: 1845 0.7472661 0.8448292 0.09482922
#1.0: 1676 0.6788173 1.067153 0.06715268

# get filtered species and sites: A, then H
# filt.dat_0.5 <- tree.range.dat %>% filter(min.A <= out.dat.full.maxsp$minV & max.A >=out.dat.full.maxsp$maxV)
# filt.dat_0.5H <- filt.dat_0.5 %>% filter(min.H < medT-max.A & max.H > medT-min.A)

# get filtered species and sites: A, then H
# filt.dat_0.75 <- tree.range.dat %>% filter(min.A <= out.dat.full.maxsp$minV & max.A >=out.dat.full.maxsp$maxV)
# filt.dat_0.75H <- filt.dat_0.75 %>% filter(min.H < medT-max.A & max.H > medT-min.A)

# get filtered species and sites: A, then H
filt.dat_1 <- tree.range.dat %>% filter(min.A <= out.dat.full.maxsp$minV & max.A >=out.dat.full.maxsp$maxV)
filt.dat_1H <- filt.dat_1 %>% filter(min.H < medT-max.A & max.H > medT-min.A)

###################################################
#################### PREDICT CDD ##################
###################################################

# read list
mod.list <- readRDS('data/conhet_GAMmodeloutputs_allalive.rds')
# remove null
mod.list <- compact(mod.list)

# choose one range value
#RangeValue <- 0.5
#RangeValue <- 0.75
RangeValue <- 1

# create dataframe
output.study <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    species.dat<-species.dat[c("mod2")] 
    # create output.species
    output.species <- data.frame() 
    # for each model in species.dat
    for(m in 1:length(species.dat)) {
      # Generate ranges and set plot level values
      #Amin <- 0.2558998 # 0.5 range min
      #Amin <- 0.09482922 # 0.75 range min
      Amin <- 0.06715268 # 1 range min
      Amax <- Amin + RangeValue
      Hmin <- medT - Amax
      Hmax <- medT - Amin
      Asim <- c(Amax, Amin)		
      Hsim <- c(Hmin, Hmax)	
      pred.dat <- data.frame(A = Asim, Ha = Hsim)
      # predict and backcalculate per capita recruitment
      pred <- predict.gam(species.dat[[m]],newdata = pred.dat,type = "link", se=TRUE)
      prop.change <- (exp(pred[[1]][1])/ exp(pred[[1]][2])) - 1
      logit.change <- log(exp(pred[[1]][1]) / exp(pred[[1]][2]))
      r2 <- summary(species.dat[[m]])$dev.expl
      # join all info at species level and join to site
      out.dat<- cbind(names(mod.list)[i], names(site.dat)[s], names(species.dat)[m], prop.change, logit.change, r2) 
      output.species <- rbind(output.species, out.dat)
    }
    output.species <- output.species %>% mutate_at(c("prop.change", "logit.change", "r2"), as.character) %>%
      mutate_at(c("prop.change", "logit.change", "r2"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  output.study <- rbind(output.site, output.study)
}  

# add column names
colnames(output.study) <- c("site", "species", "model", "prop.change.A", "logit.change.A", "r2")

# only keep output that is in real range of data from filt df
# output.study_0.5 <- filt.dat_0.5H %>%
#  left_join(output.study, by = c("site", "species")) %>% 
#  rename(latin = species) %>%
#  drop_na() %>%
#  select(c(site, latin, prop.change.A, logit.change.A,r2))

# output.study_0.75 <- filt.dat_0.75H %>%
#  left_join(output.study, by = c("site", "species")) %>% 
#  rename(latin = species) %>%
#  drop_na() %>%
#  select(c(site, latin, prop.change.A, logit.change.A,r2))

output.study_1 <- filt.dat_1H %>%
  left_join(output.study, by = c("site", "species")) %>% 
  rename(latin = species) %>%
  drop_na() %>%
  select(c(site, latin, prop.change.A, logit.change.A,r2))

# save df as .rds object
# saveRDS(output.study_0.5,"data/conhet_0.5_GAM.output_allalive.rds")
# saveRDS(output.study_0.75,"data/conhet_0.75_GAM.output_allalive.rds")
saveRDS(output.study_1,"data/conhet_1_GAM.output_allalive.rds")
