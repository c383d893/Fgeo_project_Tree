############# RUN GLOBAL BAM MODELS ###############
################# CONHET VERSION ##################
################# RUN ON CLUSTER ##################

## This script generates a global model with species*site intercept/slope to predict species*site estimates
## Then predicts conspecific density dependence for each species*site
## CDD: A from 0 to 1
## Can change with RangeValue the shift between predictions/situations

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)  
library(mgcv)     

###################################################
################## BRING IN DAT ###################
###################################################

# get myc status
spdat <- readRDS("data/splevel_meta.rds") %>% rename(species = latin) %>% select(c('species', 'myc'))
# read globaldat from dist weighted and join with spdat; generate sitespecies
glob.dat <- readRDS('data/conhet_distweight_globaldat_allalive.rds') %>%
  left_join(spdat, by = "species") %>%
  mutate(myc = as.factor(myc), species = as.factor(species), sitespecies = as.factor(paste(site, species, sep = "_")))

###################################################
################# RUN BAM MODEL ###################
###################################################

# run BAM model
factor_interact.ranint.slope <- bam(S ~ myc + s(A,k = 3, by = myc)+ s(Ha, k = 3)+ 
                                s(sitespecies, bs = "re") + s(A, sitespecies, bs = "re"), 
                                offset = (ln_A), family = nb(link = "log"), nthreads = 40, discrete = TRUE, data = glob.dat)

# save model as .rds object
saveRDS(factor_interact.ranint.slope, 'data/conhet_spintslope_globalGAMmodeloutput_allalive.rds')

###################################################
################ DETERMINE VALUES #################
###################################################

# determine medT and medA
glob.dat2 <- glob.dat %>% mutate(T = A + CMHa + HMHa)
medT <- median(glob.dat2$T)
medA <- median(glob.dat$A)

# set range value
RangeValue <- 1

###################################################
############# PREDICT DD GLOBAL ###################
###################################################

# create df for output
glob.mod.sp <- data.frame()
# for each site in mod.list
for(i in unique(glob.dat$site)){
  # subset glob.dat to site
  glob.dat.site <- glob.dat %>% filter(site == i)
  # create df for site output
  output.site <- data.frame()
  # for each species in site.dat
  for(s in unique(glob.dat.site$species)) {
    # save species.dat, set myc cat
    species.dat = glob.dat.site %>% filter(species == s)
    myc_cat = unique(species.dat$myc)
    # create df for species output
    output.species <- data.frame() 
    # create new dat and predict
    Amin <- 0  
    Amax <- RangeValue
    Hmin <- medT - Amax
    Hmax <- medT - Amin
    Asim <- c(Amax, Amin)		
    Hsim <- c(Hmin, Hmax)	
    pred.dat <- data.frame(A = Asim, Ha = Hsim, myc = myc_cat, sitespecies = paste(i, s, sep = "_"))
    # predict and backcalculate per capita recruitment
    pred <- predict.gam(factor_interact.ranint.slope, newdata = pred.dat,type = "link", se = TRUE)
    prop.change <- (exp(pred[[1]][1])/ exp(pred[[1]][2])) - 1
    logit.change <- log(exp(pred[[1]][1]) / exp(pred[[1]][2]))
    # join all info at species level and join to site
    output.species <- cbind(i, s, prop.change, logit.change) %>% as.data.frame() # add site, species, and pred
    output.species <- output.species %>% mutate_at(c("prop.change", "logit.change"), as.character) %>%
      mutate_at(c("prop.change", "logit.change"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  glob.mod.sp<- rbind(glob.mod.sp, output.site)
}

# add column names
colnames(glob.mod.sp) <- c("site", "species", "prop.change", "logit.change")

# rename and simplify data
glob.mod.sp.A <- glob.mod.sp %>%
  rename(latin = species,prop.change.A = prop.change, logit.change.A = logit.change)%>%
  drop_na() %>%
  select(c(site, latin, prop.change.A, logit.change.A))

# save df as .rds object
saveRDS(glob.mod.sp.A, 'data/conhet_A_spallfromglobal_GAMmodeloutput_allalive.rds')
print('Predictions complete')