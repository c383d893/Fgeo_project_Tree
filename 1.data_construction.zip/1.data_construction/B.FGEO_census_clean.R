#### CONVERT CENSUS DATA TO UNIVERSAL FORMAT AND JOIN ####

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)

# set global column order
col_order <- c("sp", "genus", "species", "gx", "gy", "treeID", "dbh", "status", "quadrat", "census", "site")

##########################
#### MULTIPLE CENSUS  ####
##########################

######################
#### Danum Valley ####
######################

# status = alive, broken_below, missing
DV.1 <- read.table("data/multiple_census_data/Danum_Valley/Danum_Valley_Census_1_Accessed_02-17-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1,  site = "Danum_Valley") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, missing, dead
DV.2 <- read.table("data/multiple_census_data/Danum_Valley/Danum_Valley_Census_2_Accessed_02-17-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus,species,sep = "_")) %>%
  mutate(census = 2,  site = "Danum_Valley") %>%
  mutate(dbh = dbh*.10) %>%    
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
#### Luquillo ####
##################

# status = alive, broken_below, stem_dead, dead
LQ.4 <- read.table("data/multiple_census_data/Luquillo/Luquillo_Census_4_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 4, site = "Luquillo") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, stem_dead, dead
LQ.5 <- read.table("data/multiple_census_data/Luquillo/Luquillo_Census_5_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 5, site = "Luquillo") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, stem_dead, dead
LQ.6 <- read.table("data/multiple_census_data/Luquillo/Luquillo_Census_6_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE)  %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 6, site = "Luquillo") %>%
  mutate(dbh = dbh*.10) %>%     
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

##################
###### SERC ######
##################

# status = alive, broken_below, stem_dead, dead
SERC.1 <- read.table("data/multiple_census_data/SERC/SERC_Census_1_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "SERC") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, stem_dead, dead
SERC.2 <- read.table("data/multiple_census_data/SERC/SERC_Census_2_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "SERC") %>%
  mutate(dbh = dbh) %>%    
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
###### SCBI ######
##################

# status = alive, broken_below, stem_dead, dead, missing, NA
SCBI.1 <- read.table("data/multiple_census_data/SCBI/SCBI_Census_1_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1,  site = "SCBI") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, stem_dead,  missing, NA
SCBI.2 <- read.table("data/multiple_census_data/SCBI/SCBI_Census_2_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2,  site = "SCBI") %>%
  mutate(dbh = dbh*.10) %>%    # No need to convert DBH, in cm
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, stem_dead, dead, NA
SCBI.3 <- read.table("data/multiple_census_data/SCBI/SCBI_Census_3_Accessed_02-16-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3,  site = "SCBI") %>%
  mutate(dbh = dbh*.10) %>%    # No need to convert DBH, in cm
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
###### BCI #######
##################

# status = alive, missing
BCI.1 <- read.table("data/multiple_census_data/BCI/BCI_Census_1_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1,  site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, missing, broken_below, dead, stem_dead
BCI.2 <- read.table("data/multiple_census_data/BCI/BCI_Census_2_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2,  site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, missing, broken_below, dead, stem_dead
BCI.3 <- read.table("data/multiple_census_data/BCI/BCI_Census_3_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3,  site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%    
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, missing, broken_below, dead, stem_dead
BCI.4 <- read.table("data/multiple_census_data/BCI/BCI_Census_4_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 4,  site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, missing, broken_below, dead
BCI.5 <- read.table("data/multiple_census_data/BCI/BCI_Census_5_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 5,  site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, missing, broken_below, dead, stem_dead
BCI.6 <- read.table("data/multiple_census_data/BCI/BCI_Census_6_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 6,  site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, dead, stem_dead
BCI.7 <- read.table("data/multiple_census_data/BCI/BCI_Census_7_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 7, site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, dead, stem_dead
BCI.8 <- read.table("data/multiple_census_data/BCI/BCI_Census_8_accessed20210216_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 8, site = "BCI") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
##### Cocoli #####
##################

# status key Cocoli, San Lorenzo: https://datadryad.org/stash/dataset/doi:10.15146/5xcp-0d46
# A = alive
# D = dead
# P = prior (prior to appearance in next census)
# M = missing
# AD = dead and alive
# AR = broken to unbroken
# G = gone
# V = vanished

load("data/multiple_census_data/Cocoli/marena3cns.stem1.rdata") # includes multiple sites
load("data/multiple_census_data/Cocoli/marena3cns.stem2.rdata") # includes multiple sites
load("data/multiple_census_data/Cocoli/marena3cns.stem3.rdata") # includes multiple sites
plot.1 <- marena3cns.stem1
plot.2 <- marena3cns.stem2
plot.3 <- marena3cns.stem3

load("data/multiple_census_data/Cocoli/bci.spptable.rdata")
Cocoli.sp <- bci.spptable %>%
  mutate(latin = paste(Genus, Species, sep = "_")) %>%
  rename(spcode = sp) %>%
  select(c("latin", "spcode"))

Cocoli.plot <- rbind(plot.1,plot.2,plot.3) %>%
  filter(plot == "cocoli") %>% 
  rename(spcode = sp) %>%
  left_join(Cocoli.sp, by = "spcode")

# status = P, A, M
Cocoli.1 <- Cocoli.plot %>%
  filter(census == 1) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species,sep = "_")   ) %>%
  mutate(census = 1,  site = "Cocoli") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"|status =="AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = P, A, M, AM, D, V, G, AR
Cocoli.2 <- Cocoli.plot %>%
  filter(census == 2) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2,  site = "Cocoli") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "A"|status == "AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

# status = A, M, V, D, G
Cocoli.3 <- Cocoli.plot %>%
  filter(census == 3) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3,  site = "Cocoli") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "A"|status == "AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

##################
### San_Lorenzo ##
##################

load("data/multiple_census_data/San_Lorenzo__Sherman/marena4cns.stem1.rdata") # includes multiple sites
load("data/multiple_census_data/San_Lorenzo__Sherman/marena4cns.stem2.rdata") # includes multiple sites
load("data/multiple_census_data/San_Lorenzo__Sherman/marena4cns.stem3.rdata") # includes multiple sites
load("data/multiple_census_data/San_Lorenzo__Sherman/marena4cns.stem4.rdata") # includes multiple sites
plot.1 <- marena4cns.stem1
plot.2 <- marena4cns.stem2
plot.3 <- marena4cns.stem3
plot.4 <- marena4cns.stem4

load("data/multiple_census_data/San_Lorenzo__Sherman/bci.spptable.rdata")
SanLo.sp <- bci.spptable %>%
  mutate(latin = paste(Genus, Species, sep = "_")) %>%
  rename(spcode = sp) %>%
  select(c("latin","spcode"))

SanLo.plot <- rbind(plot.1, plot.2, plot.3, plot.4) %>%
  filter(plot == "sherman") %>% 
  rename(spcode = sp) %>%
  left_join(Cocoli.sp, by = "spcode")

# status = P, A
SanLo.1 <- SanLo.plot %>%
  filter(census == 1) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1,  site = "San_Lorenzo") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"|status =="AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

# status = A, P, V, D, AM, M, G, AR, AD
SanLo.2 <- SanLo.plot %>%
  filter(census == 2) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "San_Lorenzo") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"|status =="AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

# status = A, V, AD, D, AM, M, G, P, AR
SanLo.3 <- SanLo.plot %>%
  filter(census == 3) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3, site = "San_Lorenzo") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"|status =="AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

# status = D, A, V, G, M
SanLo.4 <- SanLo.plot %>%
  filter(census == 4) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 4, site = "San_Lorenzo") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"|status =="AR", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

##################
#### Sinharaja ###
##################

# status = alive, broken_below, dead
SH.1 <- read.table("data/multiple_census_data/Sinharaja/Sinharaja_Census_1_Accessed_03-09-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Sinharaja") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, dead, stem_dead, missing
SH.2 <- read.table("data/multiple_census_data/Sinharaja/Sinharaja_Census_2_Accessed_03-09-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Sinharaja") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = alive, broken_below, dead, stem_dead, missing
SH.3 <- read.table("data/multiple_census_data/Sinharaja/Sinharaja_Census_3_Accessed_03-09-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin, quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3, site = "Sinharaja") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
## Michigan BW ###
##################

# status key:
# M = alive
# D = dead
# AL = alive but leaning
# B = broken
# S = dead but standing
# R = stem lost

MBW.sp <- read.table("data/multiple_census_data/Michigan_Big_Woods/species_CSD_07.31.21.txt", header = TRUE) %>%
  mutate(latin=paste(genus,species, sep = "_")) %>%
  select(c("latin","spcode"))

MBW.1 <- read.table("data/multiple_census_data/Michigan_Big_Woods/2003census_cortag_gxy_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(MBW.sp, by = "spcode") %>%
  select(-spcode) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeid, dbh = dbh, status = codes) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Michigan_Big_Woods") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status =="M"|status =="AL"|status =="B", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

MBW.2 <- read.table("data/multiple_census_data/Michigan_Big_Woods/2008census_cortag_gxy_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(MBW.sp, by = "spcode") %>%
  select(-spcode) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeid, dbh = dbh, status = codes) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Michigan_Big_Woods") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status =="M"|status =="AL"|status =="B", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

MBW.3 <- read.table("data/multiple_census_data/Michigan_Big_Woods/2014census_cortag_gxy_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(MBW.sp, by = "spcode") %>%
  select(-spcode) %>%
  rename(sp = latin, quadrat = quadrat, gx = gx, gy = gy, treeID = treeid, dbh = dbh, status = codes) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3, site = "Michigan_Big_Woods") %>%
  mutate(dbh = dbh) %>% 
  mutate(status = ifelse(status =="M"|status =="AL"|status =="B", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
### Wind River ###
##################

WR.sp <- read.table("data/multiple_census_data/Wind_River/WFDP_species_CSD_07.31.21.txt", header = TRUE) 

# status = A, D
WR.1 <- read.table("data/multiple_census_data/Wind_River/WFDP_Tree_Census1_CSD_07.31.21.csv", header = TRUE, sep = ",") %>%
  left_join(WR.sp, by = "SPECIES") %>%
  select(-SPECIES) %>%
  mutate(GX = UTM_X - min(UTM_X)) %>%
  mutate(GY = UTM_Y - min(UTM_Y)) %>%
  rename(sp = Latin, quadrat = QUADRAT, gx = GX, gy = GY, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Wind_River") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   
  
# status = A, D
WR.2 <- read.table("data/multiple_census_data/Wind_River/WFDP_Tree_Census2_CSD_07.31.21.csv", header = TRUE, sep = ",") %>%
    left_join(WR.sp, by = "SPECIES") %>%
    select(-SPECIES) %>%
    mutate(GX = UTM_X - min(UTM_X)) %>%
    mutate(GY = UTM_Y - min(UTM_Y)) %>%
    rename(sp = Latin, quadrat = QUADRAT, gx = GX, gy = GY, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
    select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
    separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
    mutate(sp = paste(genus, species, sep = "_")) %>%
    mutate(census = 2, site = "Wind_River") %>%
    mutate(dbh = dbh) %>%  
    mutate(status = ifelse(status == "A", "alive", "dead")) %>%
    filter(dbh > 0) %>%
    drop_na() %>%
    relocate(all_of(col_order)) %>%
    as.data.frame()   

##################
#### Yosemite ####
##################
# plot burned September 1, 2013

Yos.sp <- read.table("data/multiple_census_data/Yosemite/YFDP_species_CSD_07.31.21.txt", header = TRUE)

# status = A
Yos.1 <- read.table("data/multiple_census_data/Yosemite/YFDP_Tree_Census1_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(Yos.sp, by = "SPECIES") %>%
  select(-SPECIES) %>%
  rename(sp = Latin, quadrat = QUADRAT, gx = PLOT_X, gy = PLOT_Y, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Yosemite") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   
  
# status = A, D
Yos.2 <- read.table("data/multiple_census_data/Yosemite/YFDP_Tree_Census2_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(Yos.sp, by = "SPECIES") %>%
  select(-SPECIES) %>%
  rename(sp = Latin, quadrat = QUADRAT, gx = PLOT_X, gy = PLOT_Y, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Yosemite") %>%
  mutate(dbh = dbh) %>%    
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   
  
# status = A, D
Yos.3 <- read.table("data/multiple_census_data/Yosemite/YFDP_Tree_Census2_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(Yos.sp, by = "SPECIES") %>%
  select(-SPECIES) %>%
  rename(sp = Latin, quadrat = QUADRAT, gx = PLOT_X, gy = PLOT_Y, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 3, site = "Yosemite") %>%
  mutate(dbh = dbh) %>%    
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   
  
##################
###### Utah ######
##################
# tag taken as treeID

Utah.sp <- read.table("data/multiple_census_data/Utah/UFDP_species_CSD_07.31.21.txt", header = TRUE) 

# status = A, D
Utah.1 <- read.table("data/multiple_census_data/Utah/UFDP_Tree_Census1_CSD_07.31.21.csv", header = TRUE, sep = ",") %>%
  left_join(Utah.sp, by = "SPECIES") %>%
  select(-SPECIES) %>%
  mutate(GX = UTM_X - min(UTM_X)) %>%
  mutate(GY = UTM_Y - min(UTM_Y)) %>%
  rename(sp = Latin, quadrat = QUADRAT, gx = GX, gy = GY, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Utah") %>%
  mutate(dbh = as.numeric(as.character(dbh)), gx = as.numeric(as.character(gx)), gy = as.numeric(as.character(gy))) %>% 
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

# status = A, D
Utah.2 <- read.table("data/multiple_census_data/Utah/UFDP_Tree_Census2_CSD_07.31.21.csv", header = TRUE, sep = ",") %>%
  left_join(Utah.sp, by = "SPECIES") %>%
  select(-SPECIES) %>%
  mutate(GX = UTM_X - min(UTM_X)) %>%
  mutate(GY = UTM_Y - min(UTM_Y)) %>%
  rename(sp = Latin, quadrat = QUADRAT, gx = GX, gy = GY, treeID = TREE_TAG, dbh = DBH, status = DA) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Utah") %>%
  mutate(dbh = as.numeric(as.character(dbh)), gx = as.numeric(as.character(gx)), gy = as.numeric(as.character(gy))) %>% 
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

##################
#### Wabikon #####
##################
# tag taken as treeID

Wab.sp <- read.table("data/multiple_census_data/Wabikon/WabikonTreeSpeciesList_v20180801_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp=SpCode)

# status = alive, prior, missing, dead
Wab.123 <- read.table("data/multiple_census_data/Wabikon/Wabikon123_CTFS.format_20210201_CSD_07.31.21.txt", header = TRUE) %>%
  left_join(Wab.sp, by = "sp") %>%
  select(-sp) %>%
  rename(sp = Latin, quadrat = quadrat, gx = gx, gy = gy, treeID = tag, dbh = dbh, status = DFstatus) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat","CensusID")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(site = "Wabikon") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() 
  
Wab.1 <- Wab.123 %>%
  filter(CensusID == "WAB1") %>%
  select(-CensusID) %>%
  mutate(census = "1") %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

Wab.2 <- Wab.123 %>%
  filter(CensusID == "WAB2") %>%
  select(-CensusID) %>%
  mutate(census = "2") %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

Wab.3 <- Wab.123 %>%
  filter(CensusID == "WAB3") %>%
  select(-CensusID) %>%
  mutate(census ="3") %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
###### HSD #######
##################
# tag taken as treeID

# status = Alive, NA, Lean, Snag
HSD.1 <- read.table("data/multiple_census_data/Heishiding/HSD_CSD_7.31.21.txt", header = TRUE) %>%
  rename(sp = latin,  gx = gx, gy = gy, treeID = tag, dbh = dbh1, status = status1) %>%
  select(c("sp","gx","gy","treeID","dbh","status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Heishiding") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "alive" | status =="Lean", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>%# add empty quadrat col
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = Alive, NA, Lean, Snag, Dead, P, Log, Missing
HSD.2 <- read.table("data/multiple_census_data/Heishiding/HSD_CSD_7.31.21.txt", header = TRUE) %>%
  rename(sp = latin,  gx = gx, gy = gy, treeID = tag, dbh = dbh2, status = status2) %>%
  select(c("sp","gx","gy","treeID","dbh","status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Heishiding") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "alive" | status =="Lean", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>%# add empty quadrat col
  relocate(all_of(col_order)) %>%
  as.data.frame()  

##################
## Scotty Creek ##
##################

# status key:
# 1 = alive
# 0 = dead

# status = 1, NA
SC.1 <- read.table("data/multiple_census_data/Scotty_Creek/scottycreek_data_3sep2020_CSD_7.31.21.txt", header = TRUE) %>%
  rename(sp=species,  gx = gx, gy = gy, treeID = tag, dbh = DBH1, status = status1) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Scotty_Creek") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status =="1", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>%# add empty quadrat col
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = 1, 0
SC.2 <- read.table("data/multiple_census_data/Scotty_Creek/scottycreek_data_3sep2020_CSD_7.31.21.txt", header = TRUE) %>%
  rename(sp=species,  gx = gx, gy = gy, treeID = tag, dbh = DBH2, status = status2) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Scotty_Creek") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status =="1", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>% # add empty quadrat col
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
##### Zofin ######
##################

# status = dead, alive
Zof.4 <- read.table("data/multiple_census_data/Zofin/Zofin_Census_4_Accessed_03-03-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin,  quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 4, site = "Zofin") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

# status = dead, alive, stem_dead
Zof.5 <- read.table("data/multiple_census_data/Zofin/Zofin_Census_5_Accessed_03-03-2021_CSD_07.31.21.txt", header = TRUE) %>%
  rename(sp = Latin,  quadrat = Quadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 5, site = "Zofin") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

##################
##### Korup ######
##################

load("data/multiple_census_data/Korup/korup.full1.rdata")
Kor.plot1<-korup.full1

load("data/multiple_census_data/Korup/korup.full2.rdata")
Kor.plot2<-korup.full2

Kor.sp<-read.table("data/multiple_census_data/Korup/KFDP_spptable_JAL_Updated_CDedit_10.06.2021.csv", header = TRUE, sep = ",")

# status = A, P
Kor.1 <-  Kor.plot1 %>%
  rename(Sp.code=sp) %>%
  left_join(Kor.sp, by="Sp.code") %>%
  rename(sp = Latin,  quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Korup") %>%
  mutate(dbh = dbh*0.10) %>%  
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

# status = A, M, D
Kor.2 <-  Kor.plot2 %>%
  rename(Sp.code=sp) %>%
  left_join(Kor.sp, by="Sp.code") %>%
  rename(sp = Latin,  quadrat = quadrat, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "Korup") %>%
  mutate(dbh = dbh) %>%  
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()   

######################
##### La Planada #####
######################

# status key:
# B = special cases of alive (e.g. main stem dead)
# AP = alive, no measure
# P = prior/ future recruits
# D = dead
# AD = principal stem dead, individual still alive

LaPl.sp <- read.table("data/multiple_census_data/La_Planada/codes_spp_CSD_8.2.21.txt", header = TRUE)

# status = A, B, AP, P
LaPl.1 <- read.table("data/multiple_census_data/La_Planada/Censo_1_La Planada_CSD_8.2.21.txt", header = TRUE) %>%
  left_join(LaPl.sp, by = "sp") %>%
  select(-sp) %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = tag, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "La_Planada") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"| status =="B"|status =="AD", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>% # add empty quadrat col
  relocate(all_of(col_order)) %>%
  as.data.frame()    

# status = A, B, AB, AD, D, E, AP
LaPl.2 <- read.table("data/multiple_census_data/La_Planada/Censo_2_La Planada_CSD_8.2.21.txt", header = TRUE) %>%
  left_join(LaPl.sp, by = "sp") %>%
  select(-sp) %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = tag, dbh = dbh, status = status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "La_Planada") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status =="A"| status == "B"|status == "AD", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>% # add empty quadrat col
  relocate(all_of(col_order)) %>%
  as.data.frame()   

#####################
##### Mo Singto #####
#####################

# status = alive, dead, not_found
MoSing.plot <- read.table("data/multiple_census_data/Mo_Singto/2021Mar09-AllTreeCensus_CDedit04.18.22.txt", header = TRUE)

MoSing.1 <- MoSing.plot %>%          
  rename(sp = GenusSpecies, gx = PX, gy = PY, treeID = Tag, dbh = DBH, status = Status, quadrat = Quadrat, census = Census) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat","census")) %>%
  drop_na() %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  filter(census == 1) %>%
  mutate(site = "Mo_Singto") %>%
  mutate(dbh = dbh) %>%   
  mutate(dbh = ifelse(dbh == "NULL", "0", dbh)) %>%
  filter(!dbh == "0") %>%
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

MoSing.2 <- MoSing.plot %>%          
  rename(sp = GenusSpecies, gx = PX, gy = PY, treeID = Tag, dbh = DBH, status = Status, quadrat = Quadrat, census = Census) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat","census")) %>%
  drop_na() %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  filter(census == 2) %>%
  mutate(site = "Mo_Singto") %>%
  mutate(dbh = dbh) %>% 
  mutate(dbh = ifelse(dbh == "NULL", "0", dbh)) %>%
  filter(!dbh == "0") %>%
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

MoSing.3 <- MoSing.plot %>%          
  rename(sp = GenusSpecies, gx = PX, gy = PY, treeID = Tag, dbh = DBH, status = Status, quadrat = Quadrat, census = Census) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat","census")) %>%
  drop_na() %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  filter(census == 3) %>%
  mutate(site = "Mo_Singto") %>%
  mutate(dbh = dbh) %>%   
  mutate(dbh = ifelse(dbh == "NULL", "0", dbh )) %>%
  filter(!dbh == "0") %>%
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

MoSing.4 <- MoSing.plot %>%          
  rename(sp = GenusSpecies, gx = PX, gy = PY, treeID = Tag, dbh = DBH, status = Status, quadrat = Quadrat, census = Census) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat","census")) %>%
  drop_na() %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  filter(census == 4) %>%
  mutate(site = "Mo_Singto") %>%
  mutate(dbh = dbh) %>%   
  mutate(dbh = ifelse(dbh == "NULL", "0", dbh)) %>%
  filter(!dbh == "0") %>%
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

###########################
##### Un of Maryland ######
###########################

#A	DBH recorded at alternate point of measurment, refer to column 'hom' for height of measurement
#B	X stem is lost, stem was previously >= 1 cm DBH, but has broken and is still alive but < 1cm DBH
#D	X stem is dead
#F	X tree has fallen on the ground since original recordation, tag recovered
#R	Stem is irregular where DBH is measured, for example due to vines
#L	tree is leaning, with a lean greater than its own diameter at DBH height
#M	multiple stems below DBH, the stem with this tag is the main stem of many, usually the largest by DBH
#S	Xstreet tree / ornamental planted tree. Stem location may be by GPS or photo-interpretation and will typically not have 'lx' and 'ly' quadrat coordinates

UMary.sp.1 <- read.table("data/multiple_census_data/UMary/UMBC_CTFS_Species1_CDedits.csv", header = TRUE, sep = ",")
UMary.sp.2 <- read.table("data/multiple_census_data/UMary/UMBC_CTFS_Species2_CDedits.csv", header = TRUE, sep = ",")

UMary.plot.1 <- read.table("data/multiple_census_data/UMary/UMBC_CTFS_Census1_CDedits.csv", header = TRUE, sep=",") 
UMary.plot.2 <- read.table("data/multiple_census_data/UMary/UMBC_CTFS_Census2_CDedits.csv", header = TRUE, sep=",") 

# status = NA, D;L, D, M, L, D;M, D;F, L;M, R, A, F, D;L;M, I;M, S, D;R, M;S
UMary.1 <- UMary.plot.1 %>%         
  left_join(UMary.sp.1, by = "spcode") %>%
  mutate(Latin=paste(genus,species,sep = "_")) %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = tag, dbh = dbh, status =codes, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  mutate(gx = gx-min(gx), gy = gy-min(gy)) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "University_of_Maryland") %>%
  mutate(dbh = dbh) %>% 
  mutate(status = ifelse(is.na(status), "unknown",status)) %>%
  mutate(status = ifelse(status =="_" | status == "unknown" | status =="A"| status == "R" | status == "L" | status == "M", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  filter(!species %in% c("N/A")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

# status = MS, S, DFS, BS, M, L, NOFND, NOFNDS, D, ML, DF, DM, LM,DB, B,DL, BL, DLM, LD, LMD, ,DS
UMary.2 <- UMary.plot.2 %>%        
  left_join(UMary.sp.2, by = "spcode") %>%
  mutate(Latin=paste(genus,species,sep = "_")) %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = tag, dbh = dbh, status =codes, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  drop_na() %>%
  mutate(gx = gx-min(gx), gy = gy-min(gy)) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 2, site = "University_of_Maryland") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(is.na(status), "unknown",status)) %>%
  mutate(status = ifelse(status =="_" | status == "unknown" | status =="A"| status == "R" | status == "L" | status == "M", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  filter(!species %in% c("N/A")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
######## Kenting ##########
###########################

load("data/multiple_census_data/Kenting/kenting.full2.rdata")
Kent.plot.2 <- kenting.full2

load("data/multiple_census_data/Kenting/kenting.full3.rdata")
Kent.plot.3 <- kenting.full3

load("data/multiple_census_data/Kenting/kenting.spptable.rdata")
Kent.sp <- kenting.spptable %>%
  select(c("sp", "Family", "Genus", "SpeciesName")) 

Kent.2 <-  Kent.plot.2 %>%
  left_join(Kent.sp, by = "sp") %>%
  select(-sp) %>%
  mutate(Latin=paste(Genus,SpeciesName,sep = "_")) %>%
  rename(sp = Latin, genus = Genus, species = SpeciesName, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp","genus","species","gx","gy","treeID","dbh","status","quadrat")) %>%
  mutate(census = 2, site = "Kenting") %>%
  mutate(dbh = dbh) %>%  
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()    

Kent.3 <-  Kent.plot.3 %>%
  left_join(Kent.sp, by = "sp") %>%
  select(-sp) %>%
  mutate(Latin=paste(Genus,SpeciesName,sep = "_")) %>%
  rename(sp = Latin, genus = Genus, species = SpeciesName, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp","genus","species","gx","gy","treeID","dbh","status","quadrat")) %>%
  mutate(census = 3, site = "Kenting") %>%
  mutate(dbh = dbh) %>%  
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#########################
##### SINGLE CENSUS #####
#########################

##################
###### TRC #######
##################

# status = alive, stem_dead, dead, broken_below
TRC.1 <- read.table("data/single_census_data/Tyson_Research_Center/trc_PlotDataReport01-13-2021_CSD.txt", header = TRUE) %>%          
  rename(sp = Latin, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status, quadrat = Quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Tyson_Research_Center") %>%
  mutate(dbh = dbh)  %>%   
  mutate(status = ifelse(status == "alive" | status == "broken_below", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

#######################
#### Harvard Forest ###
#######################

# status = A, D
load("data/single_census_data/Harvard_Forest/harvardforest.full1.rdata")
hf.plot <- harvardforest.full1
hf.tax <- read.table("data/single_census_data/Harvard_Forest/hf253-02-species-codes_nospace.csv", header = TRUE, sep = ",")  # Read tax dat
HF.1 <- hf.plot %>%          
  left_join(hf.tax, by= "sp") %>%                                             
  select(-sp) %>%
  rename(sp = latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Harvard_Forest") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

######################
####### LDW ##########
######################

# status = A, D
load("data/single_census_data/Little_Dickie_Woods/ldw.stem1.rdata")
ldw.plot <- ldw.stem1
load("data/single_census_data/Little_Dickie_Woods/ldw.spptable.rdata")
ldw.tax <- ldw.spptable %>% mutate(sp = as.character(sp))
LDW.1 <- ldw.plot %>%          
  left_join(ldw.tax, by = "sp") %>%  
  select(-sp) %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  mutate_if(is.character, str_replace_all, pattern = " ", replacement = "_")  %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus,species,sep = "_")) %>%
  mutate(census = 1, site = "Little_Dickie_Woods") %>%
  mutate(dbh = dbh*.10) %>%  
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

######################
#### Indian Cave #####
######################

IC_sp <- read.table("data/single_census_data/Indian_Cave/20210318_ICSPWoodySpecies_CSD_8.2.21.txt", header = TRUE)

# status = LI (alive)
IC.1 <- read.table("data/single_census_data/Indian_Cave/20221003_ICSP_allData-CD_CSD_10.24.22.txt", header = TRUE) %>%
  left_join(IC_sp, by = "Species_Code") %>%
  select(-Species_Code) %>%
  filter(Stem_Tag=='1') %>%
  select(-Stem_Tag) %>%
  rename(sp = Latin_binomial, gx = x, gy = y,quadrat = Quadrat, treeID = PtID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Indian_Cave") %>%
  mutate(dbh = dbh) %>%    
  filter(dbh > 0) %>%
  mutate(status = ifelse(status == "LI", "alive", "dead")) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

######################
###### Niobrara ######
######################

Nio_sp <- read.table("data/single_census_data/Niobrara/20200325_NVPWoodySpecies_CSD_8.2.21.txt", header = TRUE)

# status = LI (alive)
Nio.1 <- read.table("data/single_census_data/Niobrara/20210223-NVP_main-stem-data_CSD_8.2.21.txt", header = TRUE) %>%
  left_join(Nio_sp, by = "Species_Code") %>%
  select(-Species_Code) %>%
  rename(sp = Latin_binomial, gx = x, gy = y,quadrat = Quadrat, treeID = PtID, dbh = DBH, status = Status) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Niobrara") %>%
  mutate(dbh = dbh) %>%    
  mutate(status = ifelse(status =="LI", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%    
  relocate(all_of(col_order)) %>%
  as.data.frame()  

#####################
###### Fushan #######
#####################

Fushan_sp <-read.table("data/single_census_data/Fushan/fushan_sp_list_CDedit.csv", header = TRUE, sep=",") %>%
  select(c("spcode","Latin"))

#status = A, D
load("data/single_census_data/Fushan/fushan.full2.rdata")
Fushan.1 <- fushan.full2 %>%        
  rename(spcode = sp) %>%
  left_join(Fushan_sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Fushan") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

#####################
#### Laupahoehoe ####
#####################

load("data/single_census_data/Laupahoehoe/Laupahoehoe.spptable.rdata")
Laup.sp <- Laupahoehoe.spptable %>%
  rename(spcode = sp) %>%
  select(c("spcode", "Latin"))

load("data/single_census_data/Laupahoehoe/Laupahoehoe.full5.rdata")
Laup.plot <- Laupahoehoe.full5

# A, D, G, M
Laup.1 <- Laup.plot %>%         
  rename(spcode = sp) %>%
  left_join(Laup.sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Laupahoehoe") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#####################
#### Lienhuachih ####
#####################

LHC.sp <- read.table("data/single_census_data/LHC/lhc_sp_list_CDedit.csv", header = TRUE, sep = ",")

load("data/single_census_data/LHC/lhc_census.rdata")
LHC.plot <- census1

# status = A 
LHC.1<- LHC.plot %>%       
  rename(spcode = sp) %>%
  left_join(LHC.sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Lienhuachih") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#####################
##### Palamanui #####
#####################

load("data/single_census_data/Palamanui/Palamanui.spptable.rdata")
Palam.sp <- Palamanui.spptable %>%
  rename(spcode = sp)

load("data/single_census_data/Palamanui/Palamanui.full5.rdata")
Palam.plot <- Palamanui.full5

# A, D, G, M
Palam.1 <- Palam.plot %>%          
  rename(spcode = sp) %>%
  left_join(Palam.sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Palamanui") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#####################
###### Palan ########
#####################

load("data/single_census_data/Palanan/palanan.spptable.rdata")
Palan.sp <- palanan.spptable %>%
  rename(spcode = sp)

load("data/single_census_data/Palanan/palanan.full4.rdata")
Palan.plot <- palanan.full4

#status = A, D
Palan.1 <- Palan.plot %>%          
  rename(spcode = sp) %>%
  left_join(Palan.sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  rename(genus=Genus, species=Species) %>%
  select(c("genus","species","gx","gy","treeID","dbh","status","quadrat")) %>%
  mutate(sp = paste(genus,species,sep = "_")) %>%
  mutate(census = 1, site = "Palanan") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#####################
####### Rabi ########
#####################

load("data/single_census_data/Rabi/rabisp.rdata")
Rabi.sp <- rabisp %>%
  rename(spcode = sp)

load("data/single_census_data/Rabi/rabifull.rdata")
Rabi.plot <- rabifull

# status = A, M
Rabi.1 <- Rabi.plot %>%          
  rename(spcode = sp) %>%
  left_join(Rabi.sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Rabi") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#####################
### Speulderbos #####
#####################

load("data/single_census_data/Speulderbos/speulderbos.spptable.rdata")
Speul.sp <- speulderbos.spptable %>%
  rename(spcode = sp)

load("data/single_census_data/Speulderbos/speulderbos.full1.rdata")
Speul.plot <- speulderbos.full1

# status = A
Speul.1 <- Speul.plot %>%          
  rename(spcode = sp) %>%
  left_join(Speul.sp, by = "spcode") %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Speulderbos") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  filter(!species=="x") %>%
  filter(!species=="sp.") %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

#####################
###### Wanang #######
#####################

load("data/single_census_data/Wanang/wanang.spptable.rdata")
Wan.sp <- wanang.spptable %>%
  rename(spcode = sp)

load("data/single_census_data/Wanang/wanang.full1.rdata")
Wan.plot <- wanang.full1

# status = alive, missing
Wan.1 <- Wan.plot %>%          
  rename(spcode = sp) %>%
  left_join(Wan.sp, by = "spcode")  %>%
  select(-status) %>%
  rename(sp = Latin, gx = gx, gy = gy, treeID = treeID, dbh = dbh, status =DFstatus, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Wanang") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  filter(!species=="") %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
##### Ordway Swisher ######
###########################

Ord.sp <- read.table("data/single_census_data/Ordway_Swisher/Ordway_TaxonomyReport10-29-2021_1110792265_CDedit_10.31.21.csv", header = TRUE, sep = ",")

Ord.plot <- read.table("data/single_census_data/Ordway_Swisher/Ordway_PlotDataReport10-29-2021_1468311426_CDesit_10.31.21.csv", header = TRUE, sep = ",")

# status - alive, dead, stem_dead
Ord.1 <- Ord.plot %>%          
  left_join(Ord.sp, by = "Mnemonic")  %>%
  rename(sp = Latin, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status, quadrat = Quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Ordway_Swisher") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "alive", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
###### Wytham Woods #######
###########################

Wyth.sp <- read.table("data/single_census_data/Wytham_Woods/Wytham_Woods_Species_2021_CDedit_10.31.21.csv", header = TRUE, sep = ",")

Wyth.plot <- read.table("data/single_census_data/Wytham_Woods/Wytham_Woods_Census_2021_CDedit_10.31.21.csv", header = TRUE, sep = ",") %>%
  mutate(lx = as.numeric(lx), ly = as.numeric(ly)) %>%
  mutate(sp_xm = case_when(
    between(subplot , 0,1) ~ 0,
    between(subplot , 1.5,2) ~ 20,
    between(subplot , 2.5,3) ~ 40,
    between(subplot , 3.5,4) ~ 60,
    between(subplot , 4.5,5) ~ 80,
    between(subplot , 5.5,6) ~ 80,
    between(subplot , 6.5,7) ~ 60,
    between(subplot , 7.5,8) ~ 40,
    between(subplot , 8.5,9) ~ 20,
    between(subplot , 9.5,10) ~ 0,
    between(subplot , 10.5,11) ~ 0,
    between(subplot , 11.5,12) ~ 20,
    between(subplot , 12.5,13) ~ 40,
    between(subplot , 13.5,14) ~ 60,
    between(subplot , 14.5,15) ~ 80,
    between(subplot , 15.5,16) ~ 80,
    between(subplot , 16.5,17) ~ 60,
    between(subplot , 17.5,18) ~ 40,
    between(subplot , 18.5,19) ~ 20,
    between(subplot , 19.5,20) ~ 0,
    between(subplot , 20.5,21) ~ 0,
    between(subplot , 21.5,22) ~ 20,
    between(subplot , 22.5,23) ~ 40,
    between(subplot , 23.5,24) ~ 60,
    between(subplot , 24.5,25) ~ 80)) %>%
  mutate(sp_ym = case_when(
    between(subplot , 0,1) ~ 0,
    between(subplot , 1.5,2) ~ 0,
    between(subplot , 2.5,3) ~ 0,
    between(subplot , 3.5,4) ~ 0,
    between(subplot , 4.5,5) ~ 0,
    between(subplot , 5.5,6) ~ 20,
    between(subplot , 6.5,7) ~ 20,
    between(subplot , 7.5,8) ~ 20,
    between(subplot , 8.5,9) ~ 20,
    between(subplot , 9.5,10) ~ 20,
    between(subplot , 10.5,11) ~ 40,
    between(subplot , 11.5,12) ~ 40,
    between(subplot , 12.5,13) ~ 40,
    between(subplot , 13.5,14) ~ 40,
    between(subplot , 14.5,15) ~ 40,
    between(subplot , 15.5,16) ~ 60,
    between(subplot , 16.5,17) ~ 60,
    between(subplot , 17.5,18) ~ 60,
    between(subplot , 18.5,19) ~ 60,
    between(subplot , 19.5,20) ~ 60,
    between(subplot , 20.5,21) ~ 80,
    between(subplot , 21.5,22) ~ 80,
    between(subplot , 22.5,23) ~ 80,
    between(subplot , 23.5,24) ~ 80,
    between(subplot , 24.5,25) ~ 80)) %>%
  mutate(plot_xm = case_when(
    between(plotnum , 0,1) ~ 0,
    between(plotnum , 1.5,2) ~ 100,
    between(plotnum , 2.5,3) ~ 200,
    between(plotnum , 3.5,4) ~ 200,
    between(plotnum , 4.5,5) ~ 100,
    between(plotnum , 5.5,6) ~ 0,
    between(plotnum , 6.5,7) ~ 0,
    between(plotnum , 7.5,8) ~ 100,
    between(plotnum , 8.5,9) ~ 200,
    between(plotnum , 9.5,10) ~ 200,
    between(plotnum , 10.5,11) ~ 100,
    between(plotnum , 11.5,12) ~ 0,
    between(plotnum , 12.5,13) ~ 0,
    between(plotnum , 13.5,14) ~ 100,
    between(plotnum , 14.5,15) ~ 200,
    between(plotnum , 15.5,16) ~ 200,
    between(plotnum , 16.5,17) ~ 100,
    between(plotnum , 17.5,18) ~ 0)) %>%
  mutate(plot_ym = case_when(
    between(plotnum , 0,1) ~ 500,
    between(plotnum , 1.5,2) ~ 500,
    between(plotnum , 2.5,3) ~ 500,
    between(plotnum , 3.5,4) ~ 400,
    between(plotnum , 4.5,5) ~ 400,
    between(plotnum , 5.5,6) ~ 400,
    between(plotnum , 6.5,7) ~ 300,
    between(plotnum , 7.5,8) ~ 300,
    between(plotnum , 8.5,9) ~ 300,
    between(plotnum , 9.5,10) ~ 200,
    between(plotnum , 10.5,11) ~ 200,
    between(plotnum , 11.5,12) ~ 200,
    between(plotnum , 12.5,13) ~ 100,
    between(plotnum , 13.5,14) ~ 100,
    between(plotnum , 14.5,15) ~ 100,
    between(plotnum , 15.5,16) ~ 0,
    between(plotnum , 16.5,17) ~ 0,
    between(plotnum , 17.5,18) ~ 0)) %>%
  mutate(x_m=lx+sp_xm+plot_xm) %>%
  mutate(y_m=ly+sp_ym+plot_ym)

Wyth.1 <- Wyth.plot %>%          
  left_join(Wyth.sp, by = "spcode")  %>%
  rename(sp = latin, gx = x_m, gy = y_m, treeID = tag, dbh = dbh21_mm, status = status) %>%
  mutate(quadrat=paste(plotnum,subplot,sep = "_")) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Wytham_Woods") %>%
  mutate(dbh = dbh*0.10) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()

###########################
##### UC Santa Cruz #######
###########################

UCSC.plot <- read.table("data/single_census_data/UCSC/UCSCFERP2017_ForCamille_20220304.csv", header = TRUE, sep = ",")

# status - "Living" "LIving" "living"
UCSC.1 <- UCSC.plot %>%          
  rename(sp = fullspecies, gx = gx, gy = gy, treeID = tag, dbh = dbh17mm, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "University_of_California_Santa_Cruz") %>%
  mutate(dbh = dbh*.10) %>%   
  mutate(status = "alive") %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
######## Oregon 31 ########
###########################

load("data/single_census_data/Oregon/HJA_FOREG-31_MainStem_Data_Census1_2019-2021_v20220409.RData")
Oreg.sp <- foreg31.main

# status = alive
Oreg.31 <- Oreg.sp %>%
  select(c("Latin", "PX", "PY", "TreeID", "DBH", "Status", "FGQuadrat")) %>%
  rename(sp = Latin, quadrat = FGQuadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "FOREG-31") %>%
  mutate(dbh = dbh) %>%  
  filter(dbh> 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame()  

###########################
######## Oregon 02 ########
###########################

load("data/single_census_data/Oregon/HJA_FOREG-02_MainStem_Data_Census1_2019_v20220409.RData")
Oreg02.sp <- foreg02.main

# status = alive
Oreg.02 <- Oreg02.sp %>%
  select(c("Latin", "PX", "PY", "TreeID", "DBH", "Status", "FGQuadrat")) %>%
  rename(sp = Latin, quadrat = FGQuadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "FOREG-02") %>%
  mutate(dbh = dbh) %>%  
  filter(dbh> 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
######## Oregon 22 ########
###########################

load("data/single_census_data/Oregon/HJA_FOREG-22_MainStem_Data_Census1_2019_v20220409.RData")
Oreg22.sp <- foreg22.main

# status = alive
Oreg.22 <- Oreg22.sp %>%
  select(c("Latin", "PX", "PY", "TreeID", "DBH", "Status", "FGQuadrat")) %>%
  rename(sp = Latin, quadrat = FGQuadrat, gx = PX, gy = PY, treeID = TreeID, dbh = DBH, status = Status) %>%
  separate(sp, c("genus", "species"), sep = " ", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "FOREG-22") %>%
  mutate(dbh = dbh) %>%  
  filter(dbh> 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
####### Baishanzu #########
###########################

Bai.plot <- read.table("data/single_census_data/Baishanzu/BSZ_Plot_Data_CD12.04.22.txt", header = TRUE)

# status = alive, snag, dead, lean/SW, lean/NE, lean/NW, lean/SE, lean/E, lean/S, lean/N, lean/W lean
Bai.1 <- Bai.plot %>%
  rename(sp = species, gx = gx, gy = gy, treeID = tag, dbh = DBH, status = status, quadrat = quadrat) %>%
  select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species, sep = "_")) %>%
  mutate(census = 1, site = "Baishanzu") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "alive" | status =="lean/SW" | status == "lean/NE" | status =="lean/NW" | status =="lean/SE" | status =="lean/E" | status =="lean/S" | status =="lean/N" | status =="lean/W"| status =="lean", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
###### Tiantongshan #######
###########################

Tian.plot <- read.table("data/single_census_data/Tiantongshan/Tiantong_plot_data_CD04.13.22.txt", header = TRUE)
Tian.sp <- read.table("data/single_census_data/Tiantongshan/Tiantong_Plot_species_list_CD04.15.22.txt", header = TRUE) 

# status = A, D
Tian.1 <- Tian.plot %>%
  left_join(Tian.sp, by = "sp") %>%
  select(-sp) %>%
  rename(sp = LD, gx = gx, gy = gy, treeID = tag, dbh = dbh, status = status) %>%
  select(c("sp","gx","gy","treeID","dbh","status")) %>%
  separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
  mutate(sp = paste(genus, species,sep = "_")   ) %>%
  mutate(census = 1, site = "Tiantongshan") %>%
  mutate(dbh = dbh) %>%   
  mutate(status = ifelse(status == "A", "alive", "dead")) %>%
  filter(dbh > 0) %>%
  drop_na() %>%
  add_column(quadrat = NA) %>%
  relocate(all_of(col_order)) %>%
  as.data.frame() 

###########################
######### Temple ########## 
###########################

Temp.plot <- read.table("data/single_census_data/Temple/TFOdata_prestormcensus_v13Apr22_CD14Apr22.txt", header = TRUE)
  
# status = 
Temp.1 <- Temp.plot %>%
    rename(sp = Scientific_name, gx = QuadX, gy = QuadY, treeID = Tag, dbh = DBH_cm, quadrat = Quadrat) %>%
    mutate(status = "alive") %>%
    select(c("sp", "gx", "gy", "treeID", "dbh", "status", "quadrat")) %>%
    separate(sp, c("genus", "species"), sep = "_", remove = TRUE) %>%
    mutate(sp = paste(genus, species,sep = "_")   ) %>%
    mutate(census = 1, site = "Temple") %>%
    mutate(dbh = dbh) %>%   
    filter(dbh > 0) %>%
    drop_na() %>%
    relocate(all_of(col_order)) %>%
    as.data.frame() 
  
#################################
###### JOIN ALL CENSUS DATA #####
#################################

allcensusdata <- rbind(DV.1, DV.2, LQ.4, LQ.5, LQ.6,
                     SERC.1, SERC.2, SCBI.1, SCBI.2, SCBI.3, 
                     BCI.1, BCI.2, BCI.3, BCI.4, BCI.5, BCI.6, BCI.7, BCI.8,
                     Cocoli.1, Cocoli.2, Cocoli.3, 
                     SanLo.1, SanLo.2, SanLo.3, SanLo.4,
                     SH.1, SH.2, SH.3, MBW.1, MBW.2, MBW.3, WR.1, WR.2, 
                     Yos.1, Yos.2, Yos.3, Utah.1, Utah.2, Wab.1, Wab.2, Wab.3, HSD.1, HSD.2, SC.1, SC.2, 
                     Zof.4, Zof.5, Kor.1, Kor.2, LaPl.1, LaPl.2, MoSing.1, MoSing.2, MoSing.3, MoSing.4,
                     UMary.1, UMary.2, Kent.2, Kent.3,
                     TRC.1, HF.1, LDW.1, IC.1, Nio.1, Fushan.1, 
                     Laup.1, LHC.1, Palam.1, Palan.1, Rabi.1, Speul.1, Wan.1, Ord.1, Wyth.1, UCSC.1, 
                     Oreg.31, Oreg.22, Oreg.02, Bai.1, Tian.1, Temp.1) %>% 
  rename(latin = sp) %>% 
  mutate(gx = as.numeric(as.character(gx)), gy = as.numeric(as.character(gy)),
         dbh = as.numeric(as.character(dbh)), quadrat = as.numeric(as.character(quadrat)),
         census = as.numeric(as.character(census))) 
  
# write table
saveRDS(allcensusdata, "data/allcensusdata_allalive.rds")

# final DBH check
range(DV.1$dbh)
range(DV.2$dbh)
range(LQ.4$dbh)
range(LQ.5$dbh)
range(LQ.6$dbh)
range(SERC.1$dbh)
range(SERC.2$dbh)
range(SCBI.1$dbh)
range(SCBI.2$dbh)
range(SCBI.3$dbh)
range(BCI.1$dbh)
range(BCI.2$dbh)
range(BCI.3$dbh)
range(BCI.4$dbh)
range(BCI.5$dbh)
range(BCI.6$dbh)
range(BCI.7$dbh)
range(BCI.8$dbh)
range(Cocoli.1$dbh)
range(Cocoli.2$dbh)
range(Cocoli.3$dbh)
range(SanLo.1$dbh)
range(SanLo.2$dbh)
range(SanLo.3$dbh)
range(SanLo.4$dbh)
range(SH.1$dbh)
range(SH.2$dbh)
range(SH.3$dbh)
range(MBW.1$dbh)
range(MBW.2$dbh)
range(MBW.3$dbh)
range(WR.1$dbh)
range(WR.2$dbh)
range(Yos.1$dbh)
range(Yos.2$dbh)
range(Yos.3$dbh)
range(Utah.1$dbh)
range(Utah.2$dbh)
range(Wab.1$dbh)
range(Wab.2$dbh)
range(Wab.3$dbh) 
range(HSD.1$dbh)
range(HSD.2$dbh)
range(SC.1$dbh)
range(SC.2$dbh)
range(Zof.4$dbh)
range(Zof.5$dbh)
range(Kor.1$dbh)
range(Kor.2$dbh)
range(LaPl.1$dbh)
range(LaPl.2$dbh)
range(MoSing.1$dbh) 
range(MoSing.2$dbh)
range(MoSing.3$dbh)
range(MoSing.4$dbh)
range(UMary.1$dbh)
range(UMary.2$dbh)
range(Kent.2$dbh)
range(Kent.3$dbh)
range(TRC.1$dbh)
range(HF.1$dbh)
range(LDW.1$dbh)
range(IC.1$dbh)
range(Nio.1$dbh)
range(Fushan.1$dbh)
range(Laup.1$dbh)
range(LHC.1$dbh)
range(Palam.1$dbh)
range(Palan.1$dbh)
range(Rabi.1$dbh)
range(Speul.1$dbh)
range(Wan.1$dbh)
range(Ord.1$dbh)
range(Wyth.1$dbh)
range(UCSC.1$dbh)
range(Oreg.31$dbh)
range(Oreg.22$dbh)
range(Oreg.02$dbh)
range(Bai.1$dbh)
range(Tian.1$dbh)
range(Temp.1$dbh)