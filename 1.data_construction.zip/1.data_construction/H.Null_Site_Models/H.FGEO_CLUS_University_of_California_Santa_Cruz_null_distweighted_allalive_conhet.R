#### CREATE NULL DISTANCE WEIGHTED DATA FOR MODELS #####
################### CONHET VERSION #####################
#################### RUN ON CLUSTER ####################

# set site and null itts
S <- "University_of_California_Santa_Cruz"

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)
library(foreach)
library(doParallel)

###################################################
############### SET UP FUNCTIONS ##################
###################################################

source("functions/dispersal1.R")
source("functions/dispersal2.R")
source("functions/dispersal3.R")
source("functions/DistWeighted.R")

###################################################
################## BRING IN DAT ###################
###################################################

# read in data
dat <- readRDS('data/conhet_allcensusdata_withmyc_allalive.rds')
# subset to site
dat <- dat %>% filter(site==S)
# unique sites in df
site = unique(dat$site)                    

###################################################
###################################################
############# RUN DISTWEIGHTED NULL ###############
###################################################
###################################################
###################################################

# set null reps	
null.itt = 100  

# set.seed
set.seed(609)
# create list for output
null.dist.weighted.list <- list()
# set number of parallel cores
registerDoParallel(68) 

null.dist.weighted.list <- foreach(i = 1:length(site), .combine = c, .inorder = TRUE)%dopar%{  
  # assign site
  k <- site[i] 
  site.list <- list()
  # make loop df
  lp.dat = filter(dat, site == k)                                     
  # print site
  print(k)
  #create df
  itt.list <- list()
  for(z in 1:null.itt){
    # print itt
    print(z)
    # keep only main stems
    lp.dat<- lp.dat %>% group_by(treeID) %>% arrange(dbh) %>% slice(1) %>% ungroup() %>% as.data.frame()
    # record values 
    # sp ID for each step
    sp = lp.dat$latin 				              
    # x-coordinate of each stem
    gx = lp.dat$gx					              
    # y-coordinate of each stem
    gy = lp.dat$gy				         	        
    # DBH of each stem 
    dbh =lp.dat$dbh                       
    # unique species in plot
    species = unique(lp.dat$latin)		     
    # number of species in plot
    SP = length(species)				       
    # east-west width (Lx) and north-south height (Ly) of plot along with number of total ha of plot
    Lx = max(lp.dat$gx) ; Ly = max(lp.dat$gy); Area = (Lx*Ly)/10000	  
    # myc category of each stem
    myc = lp.dat$myc                        
    # genearte model inputs
    lp.dat.ran = DistWeighted(sp, dbh, myc, gx, gy, Lx, Ly, DX, tr, quant, L, adult.mort, type = null.type)
    # save to itt list
    itt.list[[z]]<- lp.dat.ran
  }
  # save itt.list under site list
  site.list[[k]]<- itt.list
  # return itt.list to join with other itts
  return(site.list)
}

#save site list as .rds object.
filenameoutput = paste("data/null_conhet/NULL_", S ,"_conhet_density_dependence.input.data_allalive.rds", sep = "") 
saveRDS(null.dist.weighted.list,filenameoutput)