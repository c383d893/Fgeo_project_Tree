## This script creates distance weighted data for null models

#set site and null itts
S <- "Lienhuachih"

###################################################
###################################################
################# SET UP PACKAGES #################
###################################################
###################################################

library(tidyverse) # tidyverse
library(foreach)
library(doParallel)

###################################################
###################################################
############### SET UP FUNCTIONS ##################
###################################################
###################################################

source("functions/dispersal1.R")
source("functions/dispersal2.R")
source("functions/dispersal3.R")
source("functions/DistWeighted.R")

###################################################
###################################################
################## BRING IN DAT ###################
###################################################
###################################################

dat <- readRDS('data/conhet_allcensusdata_withmyc_allalive.rds')   # load data
dat <- dat %>% filter(site==S)

site = unique(dat$site)                           # unique sites

###################################################
###################################################
############# RUN DISTWEIGHTED NULL ###############
###################################################
###################################################
###################################################

null.itt = 100    # set null reps	

set.seed(609)
null.dist.weighted.list <- list()
registerDoParallel(68) 
null.dist.weighted.list <- foreach(i = 1:length(site), .combine = c, .inorder = TRUE)%dopar%{  
  k <- site[i] 
  site.list <- list()
  lp.dat = filter(dat, site == k)                                       # Make loop dataframe
  print(k)
  itt.list <- list()
  for(z in 1:null.itt){
    print(z)
    # Keep only main stems
    lp.dat<- lp.dat %>% group_by(treeID) %>% arrange(dbh) %>% slice(1) %>% ungroup() %>% as.data.frame()
    # record values    
    sp = lp.dat$latin 				              # Species ID for each stem
    gx = lp.dat$gx					                # X-coordinate of each stem
    gy = lp.dat$gy				         	        # Y-coordinate of each stem
    dbh =lp.dat$dbh                         # DBH
    species = unique(lp.dat$latin)		      # Species in the plot
    SP = length(species)				            # Number of species in the plot
    Lx = max(lp.dat$gx) ; Ly = max(lp.dat$gy); Area = (Lx*Ly)/10000	  # East-west width (Lx) and north-south height (Ly) of plot along with number of total ha of plot
    myc = lp.dat$myc                        # Myc category
    # Make model inputs
    lp.dat.ran = DistWeighted(sp, dbh, myc, gx, gy, Lx, Ly, DX, tr, quant, L, adult.mort, type = null.type)
    itt.list[[z]]<- lp.dat.ran
  }
  site.list[[k]]<- itt.list
  return(site.list)
}

#save site list as .rds object.
filenameoutput = paste("data/null_conhet/NULL_", S ,"_conhet_density_dependence.input.data_allalive.rds", sep = "") 
saveRDS(null.dist.weighted.list,filenameoutput)