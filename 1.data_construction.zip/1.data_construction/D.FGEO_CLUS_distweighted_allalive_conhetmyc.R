#### CREATE DISTANCE WEIGHTED DATA FOR MODELS #####
################ CONHETMYC VERSION ################
################# RUN ON CLUSTER ##################

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)

###################################################
############### SET UP FUNCTIONS ##################
###################################################

source("functions/dispersal1.R")
source("functions/dispersal2.R")
source("functions/dispersal3.R")
source("functions/DistWeighted.R")

###################################################
################## BRING IN DAT ###################
###################################################

# read in data
dat <- readRDS('data/conhetmyc_allcensusdata_withmyc_allalive.rds')  
# unique sites in df
site = unique(dat$site)                       

###################################################
################ RUN DISTWEIGHTED #################
###################################################

# create list for output
dist.weighted.list <- list()
for (k in site) { 
  # make loop df
  lp.dat = filter(dat, site == k)                                       
  # print site
  print(k)                                                               
  # keep only main stems
  lp.dat <- lp.dat %>% group_by(treeID) %>% arrange(dbh) %>% slice(1) %>% ungroup() %>% as.data.frame()
  # record values 
  # sp ID for each step
  sp = lp.dat$latin 				              
  # x-coordinate of each stem
  gx = lp.dat$gx					              
  # y-coordinate of each stem
  gy = lp.dat$gy				         	        
  # DBH of each stem 
  dbh = lp.dat$dbh                       
  # unique species in plot
  species = unique(lp.dat$latin)		     
  # number of species in plot
  SP = length(species)				       
  # east-west width (Lx) and north-south height (Ly) of plot along with number of total ha of plot
  Lx = max(lp.dat$gx); Ly = max(lp.dat$gy); Area = (Lx*Ly)/10000	  
  # myc category of each stem
  myc = lp.dat$myc                        
  # genearte model inputs
  lp.dat = DistWeighted(sp, dbh, myc, gx, gy, Lx, Ly, DX, tr, quant, L, adult.mort, type = 'observed')
  # add to list
  dist.weighted.list[[k]] <- lp.dat
}

# save site list as .rds object
saveRDS(dist.weighted.list, 'data/conhetmyc_density_dependence.input.data_allalive.rds')

###################################################
################# GLOBAL DATA #####################
###################################################

# read in dist weighted list
dist.weighted.list <- readRDS('data/conhetmyc_density_dependence.input.data_allalive.rds')
# unique sites in list
site = unique(names(dist.weighted.list)) 

# create df for output
glob.dat <- data.frame() 
for (k in site) { 
  # print site
  print(k)
  # create list for site
  lp.dat = dist.weighted.list[[k]]
  # create df for site output
  output.site <- data.frame() 
  # unique species in plot
  species = unique(lp.dat$species)		     
  # number of species in plot
  SP = length(species)	
  # extract data for each species at given site
  for(i in 1:SP) {
    if(lp.dat$N[i] > tr & lp.dat$adultquads[i] > 9 & lp.dat$sapquads[i] > 9) {
      tbl = data.frame(A = lp.dat$adultDistWeightedAbund[,i], ln_A =log(lp.dat$adultDistWeightedAbund[,i]),Ha = lp.dat$HadultDistWeightedAbund[,i], Hs = lp.dat$HsapDistWeightedAbund[,i],
                       CMa = lp.dat$CMadultDistWeightedAbund[,i], CMs = lp.dat$CMsapDistWeightedAbund[,i], CMHa = lp.dat$CMHadultDistWeightedAbund[,i],
                       CMHs = lp.dat$CMHsapDistWeightedAbund[,i], HMHa = lp.dat$HMHadultDistWeightedAbund[,i], HMHs = lp.dat$HMHsapDistWeightedAbund[,i], S = lp.dat$saplings[,i], A.orig = lp.dat$adults[,i]) 
      # add output under species
      out.dat <- cbind(k,as.character(species[i]),tbl)
      # add output to site df
      output.site <- rbind(output.site, out.dat)
    }
  }
  # join site outputs
  glob.dat <- rbind(glob.dat, output.site)
}

# add column names
colnames(glob.dat) <- c("site", "species", "A", "ln_A", "Ha", "Hs", "CMa", "CMs", "CMHa", "CMHs", "HMHa", "HMHs", "S", "A.orig") 
# save site df as .rds object
saveRDS(glob.dat, 'data/conhetmyc_distweight_globaldat_allalive.rds')