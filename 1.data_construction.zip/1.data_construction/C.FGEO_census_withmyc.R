#### JOIN CENSUS DATA WITH MYC STATUS & FILTER FOR CDD/ CMDD ANALYSES #### 

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)

###################################################
################## BRING IN DAT ###################
############# MYC SPECIES AND GENUS ###############
###################################################

mycstat <- read.table("data/Funroot_species_08092021.csv", header=TRUE, sep=",")    

mycstat.g <- read.table("data/Funroot_genus_08092021.csv", header=TRUE, sep=",")    

###################################################
############## BRING IN CENSUS DAT ################
###################################################

# read data and extract latest census only and alive only: Yosemite
Yos <- readRDS("data/allcensusdata_allalive.rds") %>%
  filter(site == "Yosemite") %>%
  slice_min(census) %>%             
  filter(status == "alive")           

# read data and extract latest census only and alive only: all except Yosemite and join with Yos above
dat <- readRDS("data/allcensusdata_allalive.rds") %>%
  filter(!site == "Yosemite") %>%
  group_by(site) %>%                 
  slice_max(census) %>%              
  ungroup() %>%                      
  filter(status == "alive") %>%        
  rbind(Yos)                      
 
# get myc species status for all species/obs in dat: join dat with myc stat
dat.myc <- dat %>%                           
  left_join(mycstat, by = "latin")                                               

# get myc genus status for all species in dat (no repeat species): join dat with myc stat genus
dat.myc.g <- dat %>% 
  left_join(mycstat.g, by="genus")%>%                                             
  select(c("latin", "myc")) %>%                                                   
  rename(myc.g = myc) %>%                                                          
  distinct(latin, .keep_all = TRUE)                                                 

# assign species, then genus status for each obs in dat; only keep AM and EM categories
dat2 <- dat.myc %>% left_join(dat.myc.g, by = "latin") %>%                          
  mutate(myc = as.character(myc), myc.g = as.character(myc.g)) %>%                    
  mutate(consensus_myc = ifelse(is.na(myc), myc.g, myc)) %>%                     
  select(-c(myc, myc.g)) %>%
  rename(myc = consensus_myc) %>%
  filter(myc == "AM"| myc == "EM") %>% 
  as.data.frame() %>%
  select(-c("census", "status", "genus", "species"))

# save sites that can run CDD
saveRDS(dat2, 'data/conhet_allcensusdata_withmyc_allalive.rds')

# find sites that don't have both myc types
dat2.myc.freq <- dat2 %>% 
  group_by(site,myc,.drop=FALSE) %>% 
  distinct(latin) %>% 
  summarize(N = n()) %>%    
  mutate(freq = N / sum(N)) %>%
  filter(!freq == 1)

# subset sites that occur in dat2.myc.freq
dat2.conhetmyc <- dat2 %>% filter(site %in% dat2.myc.freq$site)

# save sites that can run CDD and CMDD
saveRDS(dat2.conhetmyc, 'data/conhetmyc_allcensusdata_withmyc_allalive.rds')