##### GENERATE METADATA #####
##### PHYLOGENETIC TREE #####
#### ADDITIONAL METADATA ####

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)   
library(ape)
library(abdiv)
library(doParallel)
library(foreach)
library(pez)

############################################
###### PHYLOGENETIC TREE CONSTRUCTION ######
############################################

###################################################
################## BRING IN DAT ###################
###################################################

# filter to columns and rename site as plot_id
sp <- readRDS("data/conhet_allcensusdata_withmyc_allalive.rds") %>%                                           
  select(c("latin", "site", "myc")) %>%                                                                        
  distinct(latin, site, .keep_all = TRUE) %>%                                                                                                                                            
  rename(plot_id = site) %>%
  as.data.frame()                                                                                             

#####################################
###### BUILD TREES FOR DATASET ######
#####################################

# unique sites in df
plot = unique(sp$plot_id)                                                                                     

# load master plant phy
load("data/GBOTB.extended.rda")                         
# merge with congenerics to assign species without full latin name
GBOTB.extended.congen <- congeneric.merge(GBOTB.extended, unique(sp$latin), split = "_", cite = FALSE) 
# convert phy to dataframe
alltreesp <- c(GBOTB.extended.congen$tip.label) %>% as.data.frame()          
# rename column
colnames(alltreesp) <- "latin"

# extract species in dataset
nodrop <- sp %>% select(latin)           
# extract non overlapping species to drop
todrop <- setdiff(alltreesp, nodrop) %>% as.vector()                 
# set to vector
todrop <- c(t(todrop))                      
# drop tips/prune
p.tree <- drop.tip(GBOTB.extended.congen, unlist(todrop))

# save tree as .nex
write.tree(p.tree,"data/ForestGEO_phylogeny.nex")

# set number of parallel cores
registerDoParallel(3)                                                                                        
system.time({PD <- foreach(i = 1:length(plot), .combine = c, .inorder = FALSE)%dopar%{                                                                  
  # Set current P to i
  P <- plot[i]            
  # Make a temporary loop df 
  currentSP = filter(sp, plot_id == P)                                                                           
  # set file names
  filename = paste("data/phylo_trees/tree.allsp_", P, sep = "")                                                        
  # select latin only
  nodrop <- currentSP %>% select(latin)                                                                  
  # extract non overlapping species to drop
  todrop <- setdiff(alltreesp, nodrop) %>% as.vector()                                                           
  # set to vector
  todrop <- c(t(todrop))                                                                                        
  # drop tips/prune
  p.tree <- drop.tip(GBOTB.extended.congen, unlist(todrop))
  # check if tree is empty
  if (is_empty(p.tree$tip.label)) {    
  # if empty return printed statement
    print(paste("empty tree for", P)) 
  # else, write tree
  } else {           
  # set tree path
    filepath = paste(filename, ".tre", sep = "")    
  # save tree
    write.tree(p.tree, filepath)                                                                                 
  }
  return(NA) 
}
}
)

#####################################
######## PD metrics function ########
#####################################

get_metrics <- function(X){      
  # Do the tree now so you don't have to calculate the distance a second time         
  D <- as.matrix(cophenetic(X))                                                                                                                                    
  # Make abundance matrix of 1 row and as many cols as tips on tree filled with 1s
  abund_mat <- matrix(nrow = 1,ncol = length(my_tree$tip.label)) %>% replace_na(1) %>% as.numeric()              
  # Run faith_pd to get sum of branch lengths
  m1 <- faith_pd(abund_mat, X)                                                                                   
  # output values
  return(data.frame(type = c("faith"), value = c(m1)))            
}

#####################################
####### Calculate PD metrics ########
#####################################

# set tree paths
trees <- list.files(path = "data/phylo_trees") %>%     
  # remove beginning of tree names
  str_replace("tree.allsp_", "") %>%                                                                     
  # remove end of tree names = just plot_id with trees
  str_replace(".tre", "")                                                                                  

# create df for output
PD <- data.frame()
for(T in trees){ 
  # get tree files
  filename <- paste("data/phylo_trees/tree.allsp_", T, ".tre", sep = "")                                              
  # call this file "my_tree"
  my_tree <- read.tree(filename) 
  # check if tree has at least 2 tips
  if (my_tree$Nnode < 2) {  
  # if not just return printed statement
    print(paste("1 node for tree", T))                                                                         
  } else {  
  # else, get metrics and save as df
    mt <- get_metrics(my_tree) 
  # add to growing df of PD result
    PD <- rbind(PD, mt %>% mutate(plot = T))                                                           
  }
}

# save df as .rds object
saveRDS(PD, "data/PDmetrics_FGEO_Allspecies.rds")   

############################################
########## ADDITIONAL METADATA #############
############################################

###################################################
################## BRING IN DAT ###################
###################################################

# read in dat; select cols
dat <- readRDS('data/conhet_allcensusdata_withmyc_allalive.rds') %>%
  select(c("latin", "site", "myc", "dbh"))

# read in lat; remove site; rename fullsite site; get abslat; unique sites
lat <- read.table("data/FGEO_LatLon.txt",header =TRUE) %>%
  select(-site) %>%
  rename(site = full_site) %>%
  mutate(abslat = abs(lat)) %>%
  distinct(site, .keep_all=TRUE)

# read in phylo richness
phyrich <- readRDS("data/PDmetrics_FGEO_Allspecies.rds") %>%
  spread(type, value) %>%
  rename(site = plot)

# read in envdat; take only chelsa data and site; rename fullsite site; unique sites
env <- read.table("data/FGEO_EnvDat.txt", header=TRUE) %>%
  select(c(contains("CHELSA_BIO"), full_site, Resolve_Biome))  %>%
  mutate(biome = case_when(Resolve_Biome == "1" ~ "Tropical",                                                  # Create biome2 and rename 3 major biomes
                           Resolve_Biome == "2" ~ "Tropical", 
                           Resolve_Biome == "3" ~ "Tropical",      
                           Resolve_Biome == "7" ~ "Tropical", 
                           Resolve_Biome == "4" ~ "Temperate",      
                           Resolve_Biome == "5" ~ "Temperate",
                           Resolve_Biome == "8" ~ "Temperate")) %>%
  select(-Resolve_Biome) %>%
  rename(site = full_site) %>%
  distinct(site, .keep_all=TRUE)

###################################################
################## CALCULATE DAT ##################
###################################################

# calc prop EM by site; keep unique latin per site; calc prop EMl; remove cols ; keep only distinct sites; replace na with 0
propEM <- dat %>%
  group_by(site, myc) %>%    
  distinct(latin, .keep_all=TRUE) %>%
  summarize(N = n()) %>%
  mutate(prop = N / sum(N)) %>%
  filter(myc == "EM") %>%
  rename(propEM = prop) %>%
  select(-c(myc, N)) %>%
  distinct(site, .keep_all=TRUE) %>%
  mutate(propEM = replace_na(propEM, 0)) %>%
  ungroup()

# calc prop EM by site density; keep each repeated latin per site; calc prop EMl; remove cols ; keep only distinct sites; replace na with 0
propEM.den <- dat %>%
  group_by(site, myc) %>%    
  summarize(N = n()) %>%
  mutate(prop= N / sum(N)) %>%
  filter(myc=="EM") %>%
  rename(propEM.den = prop) %>%
  select(-c(myc, N)) %>%
  distinct(site, .keep_all=TRUE) %>%
  mutate(propEM.den = replace_na(propEM.den, 0)) %>%
  ungroup()

# calc prop EM ba by site; keep unique latin per site; calc prop EMl; remove cols ; keep only distinct sites; replace na with 0
propEM.ba <- dat %>% 
  mutate(ba = 3.141593*(dbh/2)^2) %>%
  group_by(site, myc) %>%
  summarise(totba = sum(ba)) %>%
  mutate(relba = totba / sum(totba)) %>%
  filter(myc == "EM") %>%
  rename(propEM.ba = relba) %>%
  select(site,propEM.ba) %>%
  ungroup()

# calc species richness; group site; keep unique latin per site; count species; keep only distinct sites
sprich <- dat %>% 
  group_by(site) %>% 
  distinct(latin,.keep_all = TRUE) %>%
  summarize(sprich = length(latin)) %>%
  distinct(site,.keep_all = TRUE) %>%
  ungroup()

# calc sp abundance by species and site; group site latin; calc abund; rel abund; lgabund; 
abund <- dat %>% 
  group_by(site, latin) %>%
  summarise(abund = n()) %>%
  mutate(relabund = abund / sum(abund)) %>%
  mutate(lgabund = log(abund)) %>%
  ungroup()

# calc ba by species and site; group site latin; calc ba; relba
ba <- dat %>% 
  mutate(ba = 3.141593*(dbh/2)^2) %>%
  group_by(site, latin) %>%
  summarise(totba = sum(ba)) %>%
  mutate(relba = totba / sum(totba)) %>%
  ungroup()

# make spdat; keep only latin and myc; keep unique latin; join conif and ndat
spdat <- dat %>%
  select(c("latin", "myc")) %>%
  distinct(latin, .keep_all=TRUE) 

# save df as .rds object
saveRDS(spdat, "data/splevel_meta.rds")

# make sitedat; take sprich; comibne by env lat propEM by site
sitedat <- sprich %>%
  left_join(phyrich, by = "site") %>%
  left_join(env, by = "site") %>% 
  left_join(lat, by = "site") %>%
  left_join(propEM, by = "site") %>%
  left_join(propEM.den, by = "site") %>%
  left_join(propEM.ba, by = "site")

# save df as .rds object
saveRDS(sitedat, "data/sitelevel_meta.rds")

# make sp by site dat; select latin site, group by site, select distinct latin at each site, join abund and ba by site and latin
spsitedat<- dat %>%
  select(c("latin", "site")) %>%
  group_by(site) %>%
  distinct(latin, .keep_all = TRUE) %>%
  left_join(abund, by = c("site", "latin")) %>%
  left_join(ba, by = c("site", "latin")) %>%
  ungroup()

# save df as .rds object
saveRDS(spsitedat, "data/spsitelevel_meta.rds")
