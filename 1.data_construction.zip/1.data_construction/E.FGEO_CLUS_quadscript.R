#### ASSIGN QUADRAT TO EACH OBSERVATION IN DATASET ####
################ CONHET VERSION ONLY ##################
################### RUN ON CLUSTER ####################

# Used for bimodal dist fig K.FGEO_Analyses.R

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)

###################################################
################## BRING IN DAT ###################
###################################################

# read full census dat
dat <- readRDS('data/conhet_allcensusdata_withmyc_allalive.rds')
# determine sites with quad data already
sites.with.quad.dat <- dat %>% filter(!is.na(quadrat)) 
# extract sites form sites.with.quad.dat
sites.with.quad <- unique(sites.with.quad.dat$site)

# keep only main stems
mn.dat <- dat %>% 
  group_by(treeID) %>% 
  arrange(dbh) %>% 
  slice(1) %>% 
  ungroup() %>% 
  as.data.frame() %>% 
  filter(!site %in% sites.with.quad) %>%
  select(-quadrat, -treeID)

###################################################
################ GENERATE QUADS ###################
###################################################

# create df for output
quad.dat <- data.frame()
for (i in unique(mn.dat$site)){
  # print site
  print(i)
  # subset to site data
  lp.dat <- mn.dat %>% filter(site == i) %>% mutate(obs = rownames(.))
  # x-coordinate of each stem
  gx = lp.dat$gx					              
  # y-coordinate of each stem
  gy = lp.dat$gy
  # east-west width (Lx) and north-south height (Ly) of plot along with number of total ha of plot
  Lx = max(lp.dat$gx); Ly = max(lp.dat$gy); Area = (Lx*Ly)/10000	 
  # set quadrat size
  DX = 20  
  # generate quadrat combinations from x and y values
  x = seq(0, Lx, by = DX)                          
  x2 = append(x,"remove")
  x1 = append("remove",x)    
  y = seq(0, Ly, by = DX)                            
  y2 = append(y,"remove")
  y1 = append("remove",y)
  xval <- cbind(x1, x2) %>% as.data.frame() %>% 
    filter(!x1 == "remove") %>% filter(!x2 == "remove") %>%
    mutate(xval = paste(x1, x2, sep = "_")) %>%
    select(xval)
  yval <- cbind(y1,y2) %>% as.data.frame() %>% 
    filter(!y1 == "remove") %>% filter(!y2 == "remove") %>%
    mutate(yval = paste(y1, y2, sep = "_")) %>%
    select(yval)
  grid <- expand.grid(xval = xval$xval, yval = yval$yval) %>%
    mutate(xyval = paste(xval, yval, sep = "_"))
  # for each combination in grid, extract values in lp.dat fit into those
  ex.grid <- expand.grid(xyval = grid$xyval, obs = lp.dat$obs) %>%
    left_join(lp.dat, by = "obs") %>%
    separate(xyval, c("x1", "x2", "y1","y2"), sep = "_", remove = FALSE) %>%
    mutate(quadrat = if_else(gx > x1 & gx < x2 & gy > y1 & gy < y2, TRUE, FALSE))  %>%
    filter(quadrat == "TRUE") %>%
    select(-quadrat) %>%
    mutate(quadrat = as.character(xyval)) 
  # add site level ex.grid output to quad df
  quad.dat <- rbind(quad.dat, ex.grid)
}

# set global column order
col_order <- c("latin", "gx", "gy", "dbh", "quadrat", "site", "myc")
# apply global column order to sites.with.quad.dat (data with quad dat)
sites.with.quad <- sites.with.quad.dat %>% select(-treeID) %>% relocate(all_of(col_order))
# apply global column order to quad.dat (data with assigned quad dat above)
quad.dat <- quad.dat %>% select(-xyval,-x1,-x2,-y1,-y2,-obs) %>% relocate(all_of(col_order))
# join sites.with.quad and quad.dat
all.dat <- rbind(sites.with.quad, quad.dat)

# save site df as .rds object
saveRDS(all.dat,"data/conhet_allcensusdata_withmyc_allquad_allalive.rds")