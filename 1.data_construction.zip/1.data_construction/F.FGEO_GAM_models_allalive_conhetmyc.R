########## RUN SPECIES BY SITE GAM MODELS #########
######## EXTRACT PREDICTIONS FOR ANALYSIS #########
############### CONHETMYC VERSION #################

## This script runs species by site nb GAM recruitment models
## Creates global data across all site data; makes local model predictions along full range for each species
## Uses conhet optimal conspecific adult ('A') range
## Runs predictions on this range for each species
## Predictions test the change in recrtuiment in a stand at med total density (medT: 69.43534) 
## heterspecific ('CMHa' and 'HMHa') assigned proportionally to these groups based on species by site numbers
## CM version: hold medA, sets CMH to optimal min/max and HMH to remaining species

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)  
library(mgcv)  

###################################################
############### SET UP FUNCTIONS ##################
###################################################

source("functions/dispersal1.R")
source("functions/dispersal2.R")
source("functions/dispersal3.R")
source("functions/DistWeighted.R")

###################################################
################## SET UP PARS ####################
###################################################

abundance = 'stem'			            

###################################################
################## BRING IN DAT ###################
###################################################

# read in dist weighted list
dist.weighted.list <- readRDS('data/conhetmyc_density_dependence.input.data_allalive.rds')
# remove sites that can't run 3k
dist.weighted.list["FOREG-22"] <- NULL 
dist.weighted.list["Ordway_Swisher"] <- NULL
# unique sites in list
site = unique(names(dist.weighted.list))                                            

###################################################
###################################################
################# RUN GAM MODELS ##################
###################################################
###################################################

# set.seed
set.seed(609)
# create list for output
mod.list <- list() 
for (k in site) { 
  # create list for site
  site.list <- list()
  # print site
  print(k)
  # create list for site
  lp.dat = dist.weighted.list[[k]]
  # unique species in plot
  species = unique(lp.dat$species)
  # number of species in plot
  SP = length(species)	
  # run model for each species
  for(i in 1:SP) {
    if(lp.dat$N[i] > tr & lp.dat$adultquads[i] > 9 & lp.dat$sapquads[i] > 9) {
      tbl = data.frame(A = lp.dat$adultDistWeightedAbund[,i], ln_A = log(lp.dat$adultDistWeightedAbund[,i]),Ha = lp.dat$HadultDistWeightedAbund[,i], Hs = lp.dat$HsapDistWeightedAbund[,i],
                       CMa = lp.dat$CMadultDistWeightedAbund[,i], CMs = lp.dat$CMsapDistWeightedAbund[,i], CMHa = lp.dat$CMHadultDistWeightedAbund[,i],
                       CMHs = lp.dat$CMHsapDistWeightedAbund[,i], HMHa = lp.dat$HMHadultDistWeightedAbund[,i], HMHs = lp.dat$HMHsapDistWeightedAbund[,i], S = lp.dat$saplings[,i]) 
      mod5 <- gam(S ~ s(A,k=3) + s(CMHa,k=3) + s(HMHa,k=3), offset = (ln_A), family = nb(link = "log"), data = tbl) 
      # save output under species
      site.list[[as.character(species[i])]] <- list(mod5) 
      # name model
      names(site.list[[as.character(species[i])]]) <- c("mod5") 
    }
    # save site under model.list
    mod.list[[k]] <- site.list 
  }
}

# save df as .rds object
saveRDS(mod.list, 'data/conhetmyc_GAMmodeloutputs_allalive.rds')

###################################################
##### DETERMINE RANGES AND MED TOTAL DENSITY ######
###################################################

# read list
mod.list <- readRDS('data/conhetmyc_GAMmodeloutputs_allalive.rds')
# remove null
mod.list <- compact(mod.list) 

# A range
# create dataframe
tree.range.dat.A <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # print site
  print(i)
  # save site.dat
  site.dat <- mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get A.range and save values
    A.range <- species.dat[["mod5"]]$model$A
    min.A <- min(A.range)
    max.A <- max(A.range)
    med.A <- median(A.range)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], min.A, max.A, med.A)
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("min.A","max.A","med.A"), as.character) %>% mutate_at(c("min.A","max.A","med.A"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  tree.range.dat.A <- rbind(output.site, tree.range.dat.A)
} 

# add column names
colnames(tree.range.dat.A) <- c("site", "species", "min.A", "max.A", "med.A")

# CMH range
# create dataframe
tree.range.dat.CMH <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # print site
  print(i)
  # save site.dat
  site.dat <- mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get CMH.range and save values
    CMH.range <- species.dat[["mod5"]]$model$CMHa
    min.CMH <- min(CMH.range)
    max.CMH <- max(CMH.range)
    med.CMH <- median(CMH.range)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], min.CMH, max.CMH, med.CMH)
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("min.CMH", "max.CMH", "med.CMH"), as.character) %>% mutate_at(c("min.CMH", "max.CMH", "med.CMH"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  tree.range.dat.CMH <- rbind(output.site, tree.range.dat.CMH)
} 

# add column names
colnames(tree.range.dat.CMH) <- c("site", "species", "min.CMH", "max.CMH", "med.CMH")

# HMH range
# create dataframe
tree.range.dat.HMH <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # print site
  print(i)
  # save site.dat
  site.dat <- mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get HMH.range and save values
    HMH.range <- species.dat[["mod5"]]$model$HMHa
    min.HMH <- min(HMH.range)
    max.HMH <- max(HMH.range)
    med.HMH <- median(HMH.range)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], min.HMH, max.HMH, med.HMH)
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("min.HMH", "max.HMH", "med.HMH"), as.character) %>% mutate_at(c("min.HMH", "max.HMH", "med.HMH"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  tree.range.dat.HMH <- rbind(output.site, tree.range.dat.HMH)
} 

# add column names
colnames(tree.range.dat.HMH) <- c("site", "species", "min.HMH", "max.HMH", "med.HMH")

#join A, CMH and HMH tree range
tree.range.dat <- tree.range.dat.A %>%
  left_join(tree.range.dat.CMH, by = c("site", "species")) %>%
  left_join(tree.range.dat.HMH, by = c("site", "species"))

# calculate total density for each observation
# create dataframe
total.density.plots.sp <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat <- mod.list[[i]]
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get ranges and save values
    A.range <- species.dat[["mod5"]]$model$A
    CMH.range <- species.dat[["mod5"]]$model$CMHa
    HMH.range <- species.dat[["mod5"]]$model$HMHa
    # join all info at species level and join to site
    out.dat<- cbind(names(mod.list)[i],names(site.dat)[s],A.range,CMH.range,HMH.range) # add site, species, and model to prop
    output.species <- rbind(output.species, out.dat)
    output.species <- output.species %>% mutate_at(c("A.range", "CMH.range", "HMH.range"), as.character) %>% mutate_at(c("A.range", "CMH.range", "HMH.range"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  total.density.plots.sp <- rbind(output.site, total.density.plots.sp)
} 

# add column names
colnames(total.density.plots.sp) <- c("site", "species", "A.range", "CMH.range", "HMH.range")

# mean total density across dataset
total.density.plots <- total.density.plots.sp %>% 
      mutate(T = A.range + CMH.range + HMH.range)
medT <- median(total.density.plots$T)
median(total.density.plots$CMH.range)

###################################################
############## GLOBAL DATA & MOD ##################
######### 'GLOBAL' FOR THIS *MOD DATA* ############
###################################################

# read list
mod.list <- readRDS('data/conhetmyc_GAMmodeloutputs_allalive.rds')
# remove null
mod.list <- compact(mod.list) 

# create dataframe
glob.dat <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # get data and save
    dat <- species.dat[["mod5"]]$model
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], dat) 
    output.species <- rbind(output.species, out.dat)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  glob.dat <- rbind(output.site, glob.dat)
} 

# add column names
colnames(glob.dat) <- c("site", "species", "S", "A", "CMHa", "HMHa", "offset") 
glob.dat <- glob.dat %>% mutate(ln_A = log(A))

# save site df as .rds object
saveRDS(glob.dat, 'data/conhetmyc_spsite_globaldat_allalive.rds')
# read df
glob.dat <- readRDS('data/conhetmyc_spsite_globaldat_allalive.rds')

###################################################
################## LOCAL MODELS ###################
###################################################

# A loc dat
# create dataframe
loc.dat.A <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # create new dat and predict
    new.dat <- with(species.dat[['mod5']]$model, expand.grid(A = seq(min(A), max(A), length = 10))) %>% 
      mutate(CMHa=mean(species.dat[['mod5']]$model$CMHa), HMHa=mean(species.dat[['mod5']]$model$HMHa))
    pred <- predict.gam(species.dat[['mod5']], newdata = new.dat,type = "response", se = TRUE) %>%
      as.data.frame() %>% 
      mutate(A = new.dat$A)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], pred) # add site, species, and model to prop
    output.species <- rbind(output.species, out.dat)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  loc.dat.A <- rbind(output.site, loc.dat.A)
} 

# add column names
colnames(loc.dat.A) <- c("site", "species", "fit", "se.fit", "A") 
loc.dat.A <- loc.dat.A %>% 
  rename(fit.A = fit) %>%
  select(-c('se.fit'))

# CMH loc dat
# create dataframe
loc.dat.CMH <- data.frame()
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    # create output.species
    output.species <- data.frame() 
    # create new dat and predict
    new.dat <- with(species.dat[['mod5']]$model, expand.grid(CMHa = seq(min(CMHa), max(CMHa), length = 10))) %>% 
      mutate(A=mean(species.dat[['mod5']]$model$A), HMHa=mean(species.dat[['mod5']]$model$HMHa))
    pred <- predict.gam(species.dat[['mod5']], newdata = new.dat,type = "response", se = TRUE) %>%
      as.data.frame() %>% 
      mutate(CMHa = new.dat$CMHa)
    # join all info at species level and join to site
    out.dat <- cbind(names(mod.list)[i], names(site.dat)[s], pred) # add site, species, and model to prop
    output.species <- rbind(output.species, out.dat)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  loc.dat.CMH <- rbind(output.site, loc.dat.CMH)
} 

# add column names
colnames(loc.dat.CMH) <- c("site", "species", "fit", "se.fit", "CMHa") 
loc.dat.CMH <- loc.dat.CMH %>% 
  rename(fit.CMH = fit) %>%
  select(-c('se.fit'))

# join A and CMH loc data
loc.dat <- loc.dat.A %>%
  full_join(loc.dat.CMH, by = c("site", "species"))

# save df as .rds object
saveRDS(loc.dat, 'data/conhetmyc_spsite_localdat_allalive.rds')

###################################################
######### DETERMINE SPECIES*SITE CMH:HMH ##########
###################################################

# calculate prop CMH:HMH
prop.CMH.HMH <- glob.dat %>% mutate(hetprop = CMHa/(CMHa + HMHa)) 

# generate species mean hetprop
spmeanprop <- prop.CMH.HMH %>% 
  group_by(site, species) %>%
  summarize(mean.propCMH = mean(hetprop)) %>%
  ungroup()

# set range value; determined conhet
RangeValue <- 1.0

###################################################
################## PREDICT CDD ####################
###################################################

# set minA and max A: from conhet sp*site
minA <- 0.06715268
maxA <- 1.067153

# tree.range.dat with prediction values of 3 cat in data
# medT-maxA = totaldensity-maxA = left over density to be assigned under maxA
# medT-minA = totaldensity-minA = left over density to be assigned under minA
tree.range.dat.prop <- tree.range.dat %>% left_join(spmeanprop, by = c('site', 'species')) %>% 
  mutate(predCMHmin = (medT - maxA)*mean.propCMH) %>%
  mutate(predHMHmin = (medT - maxA)*(1 - mean.propCMH)) %>%
  # sanity check
  mutate(checktotalmin = predCMHmin + predHMHmin + maxA) %>% 
  mutate(predCMHmax = (medT - minA)*mean.propCMH) %>%
  mutate(predHMHmax = (medT - minA)*(1 - mean.propCMH)) %>%
  # sanity check
  mutate(checktotalmax = predCMHmax + predHMHmax + minA) 

# filter dataset based on above
tree.range.dat.filt <- tree.range.dat.prop %>% 
  # filter A value range
  filter(min.A <= minA & max.A >= maxA) %>% 
  # filter CMH value range
  filter(min.CMH < predCMHmin & max.CMH > predCMHmax) %>%
  # filter HMH value range
  filter(min.HMH < predHMHmin & max.HMH > predHMHmax)

# read list
mod.list <- readRDS('data/conhetmyc_GAMmodeloutputs_allalive.rds')
# remove null
mod.list <- compact(mod.list) 

#create dataframe
output.study <- data.frame()  
#for each site in mod.list
for(i in 1:length(mod.list)){
  #save site.dat
  site.dat = mod.list[[i]] 
  #create output.site
  output.site <- data.frame()
  #for each species in site.dat
  for(s in 1:length(site.dat)) {
    #save species.dat
    species.dat = site.dat[[s]]
    species.dat<-species.dat[c("mod5")] 
    #create output.species
    output.species <- data.frame() 
    #for each model in species.dat
    for(m in 1:length(species.dat)) {
      #Generate ranges and set sp*plot level values
      Amin <- minA  
      Amax <- Amin + RangeValue
      spvals <- tree.range.dat.prop %>% filter(species == names(site.dat)[s])
      CMHmin <- spvals$predCMHmin
      CMHmax <- spvals$predCMHmax
      HMHmin <- spvals$predHMHmin
      HMHmax <- spvals$predHMHmax
      Asim <- c(Amax, Amin)
      CMHsim <- c(CMHmin, CMHmax)
      HMHsim <- c(HMHmin, HMHmax)	
      pred.dat <- data.frame(A = Asim, CMHa = CMHsim, HMHa = HMHsim)
      #predict and backcalculate per capita recruitment
      pred<-predict.gam(species.dat[[m]],newdata = pred.dat,type = "link", se=TRUE)
      prop.change <- (exp(pred[[1]][1])/ exp(pred[[1]][2])) - 1
      logit.change <- log(exp(pred[[1]][1]) / exp(pred[[1]][2]))
      r2<-summary(species.dat[[m]])$dev.expl
      #join all info at species level and join to site
      out.dat<- cbind(names(mod.list)[i], names(site.dat)[s], names(species.dat)[m], prop.change, logit.change, r2) # add site, species, and model to prop
      output.species <- rbind(output.species, out.dat)
    }
    output.species <- output.species %>% mutate_at(c("prop.change", "logit.change", "r2"), as.character) %>%
      mutate_at(c("prop.change", "logit.change", "r2"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  #add all sites together
  output.study <- rbind(output.site, output.study)
}  

# add column names
colnames(output.study) <- c("site", "species", "model", "prop.change", "logit.change", "r2")

# only keep output that is in real range of data from filt df
output.study.A <- tree.range.dat.filt %>%
  left_join(output.study, by= c("site", "species")) %>% 
  rename(latin=species, prop.change.A = prop.change, logit.change.A = logit.change)%>%
  drop_na() %>%
  select(c(site, latin, prop.change.A, logit.change.A, r2))

###################################################
################## PREDICT CMDD ###################
###################################################

# set med A
medA <- median(glob.dat$A)

# determine cmh values that are possible across entire dataset in 1.0 range (min-max)
values.cmh <- with(glob.dat, expand.grid(cmh = seq(min(CMHa), max(CMHa), length = 10000))) %>%
  rename(maxV = cmh) %>%      
  mutate(minV = maxV - 1.0) %>% 
  # make sure all ranges are greater than 0
  filter(minV >= 0) 

# determine subset and count for each possible range
out.dat <- data.frame()
for(i in 1:nrow(values.cmh)) {
  row <- values.cmh[i,]
  # filter CMH value range
  tree.range.dat.filt <- tree.range.dat %>% filter(min.CMH < row$minV & max.CMH > row$maxV) %>% 
  # filter A value range
  filter(min.A <= medA & max.A >= medA) %>% 
  # filter HMH value range
  filter(min.HMH < medT - row$maxV - medA & max.HMH > medT - row$minV - medA)
  # sprich
  sprich <- nrow(tree.range.dat.filt)
  # propsp
  propsp <- sprich/nrow(tree.range.dat)
  sp.out.dat <- cbind(sprich, propsp) 
  # join to other sp outputs
  out.dat<-rbind(out.dat, sp.out.dat) 
}

out.dat.full <- cbind(out.dat,values.cmh)
out.dat.full.maxsp <- out.dat.full %>% arrange(desc(sprich)) %>% slice(1)
out.dat.full.maxsp

# sprich    propsp     maxV     minV
# 1387 0.5731405 68.27516 67.27516

# filter dataset
tree.range.dat.filt.CMH <- tree.range.dat.prop %>% 
  # filter A value range
  filter(min.A <= medA & max.A >= medA) %>%  
  # filter CMH value range
  filter(min.CMH < out.dat.full.maxsp$minV & max.CMH > out.dat.full.maxsp$maxV) %>% 
  # filter HMH value range
  filter(min.HMH < medT - out.dat.full.maxsp$maxV - medA & max.HMH > medT - out.dat.full.maxsp$maxV - medA)

# create dataframe
output.study <- data.frame()  
# for each site in mod.list
for(i in 1:length(mod.list)){
  # save site.dat
  site.dat = mod.list[[i]] 
  # create output.site
  output.site <- data.frame()
  # for each species in site.dat
  for(s in 1:length(site.dat)) {
    # save species.dat
    species.dat = site.dat[[s]]
    species.dat<-species.dat[c("mod5")] 
    # create output.species
    output.species <- data.frame() 
    # for each model in species.dat
    for(m in 1:length(species.dat)) {
      # generate ranges and set values
      Amin <- medA
      Amax <- medA
      CMHmin <- out.dat.full.maxsp$minV 
      CMHmax <- CMHmin + RangeValue
      HMHmin <- medT - CMHmax - medA
      HMHmax <- medT - CMHmin - medA
      Asim <- c(Amin, Amax)
      CMHsim <- c(CMHmax, CMHmin)	
      HMHsim <- c(HMHmin, HMHmax)		
      pred.dat <- data.frame(A = Asim, CMHa =CMHsim, HMHa = HMHsim)
      # predict and backcalculate per capita recruitment
      pred<-predict.gam(species.dat[[m]],newdata = pred.dat,type = "link", se=TRUE)
      prop.change <- (exp(pred[[1]][1])/ exp(pred[[1]][2])) - 1
      logit.change <- log(exp(pred[[1]][1]) / exp(pred[[1]][2]))
      r2 <- summary(species.dat[[m]])$dev.expl
      # join all info at species level and join to site
       out.dat<- cbind(names(mod.list)[i], names(site.dat)[s], names(species.dat)[m], prop.change, logit.change, r2) # add site, species, and model to prop
      output.species <- rbind(output.species, out.dat)
    }
    output.species <- output.species %>% mutate_at(c("prop.change", "logit.change", "r2"), as.character) %>%
      mutate_at(c("prop.change", "logit.change", "r2"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  # add all sites together
  output.study <- rbind(output.site, output.study)
}  

# add column names
colnames(output.study) <- c("site", "species", "model", "prop.change", "logit.change", "r2")

# only keep output that is in real range of data from filt df
output.study.CMH <- tree.range.dat.filt.CMH %>%
  left_join(output.study, by= c("site", "species")) %>% 
  rename(latin=species,prop.change.CMH = prop.change, logit.change.CMH = logit.change)%>%
  drop_na() %>%
  select(c(site, latin, prop.change.CMH, logit.change.CMH))

# join A and CMH output
output.study <- output.study.A %>%
  full_join(output.study.CMH, by = c("site", "latin"))

# save df as .rds object
saveRDS(output.study,"data/conhetmyc_GAM.output_allalive.rds")
