#### EXTRACT DATA FROM NULL ITTERATION DISTWEIGHTED ####
################ CONHET VERSION ONLY ###################
################### RUN ON CLUSTER #####################

## Group 1B1

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)  
library(mgcv)     
library(doParallel)
library(foreach)

###################################################
############### SET UP FUNCTIONS ##################
###################################################

source("functions/dispersal1.R")
source("functions/dispersal2.R")
source("functions/dispersal3.R")
source("functions/DistWeighted.R")

###################################################
################## SET UP PARS ####################
###################################################

abundance = 'stem'			            

###################################################
################## BRING IN DAT ###################
###################################################

# Load null lists from cluster
N4.1 <- readRDS('data/null_conhet/NULL_Danum_Valley1_conhet_density_dependence.input.data_allalive.rds')

# print length (should be null itt # = 50)
lengths(c(N4.1))

# join data
dist.weighted.list <- do.call(c, list(N4.1))
site <- unique(names(dist.weighted.list))  

###################################################
############## GLOBAL DATA & MOD ##################
###################################################

# create df for output
glob.dat <- data.frame()
# set number of parallel cores
registerDoParallel(40)  
glob.dat <- foreach(s = 1:length(site), .combine = rbind, .inorder = FALSE)%dopar%{                           # Set for each for each plot                                            
  # assign site
  k <- site[s]
  # print site
  print(k)
  # create output site
  output.site <- data.frame()
  # create subset site
  site.dat = dist.weighted.list[[k]]
  #create output itt & subset itt
  output.itt <- data.frame()
  for(z in 1:length(site.dat)){
    # print itt
    print(z)
    # subset to itt df
    itt.dat = site.dat[[z]] 
    # unique species in plot
    species = unique(itt.dat$species)	
    # number of species in plot
    SP = length(species)	
    # run model for each species
    for(i in 1:SP) {
      if(itt.dat$N[i] > tr & itt.dat$adultquads[i] > 9 & itt.dat$sapquads[i] > 9) {
        tbl = data.frame(A = itt.dat$adultDistWeightedAbund[,i], ln_A =log(itt.dat$adultDistWeightedAbund[,i]),Ha = itt.dat$HadultDistWeightedAbund[,i], Hs = itt.dat$HsapDistWeightedAbund[,i],
                         CMa = itt.dat$CMadultDistWeightedAbund[,i], CMs = itt.dat$CMsapDistWeightedAbund[,i], CMHa = itt.dat$CMHadultDistWeightedAbund[,i],
                         CMHs = itt.dat$CMHsapDistWeightedAbund[,i], HMHa = itt.dat$HMHadultDistWeightedAbund[,i], HMHs = itt.dat$HMHsapDistWeightedAbund[,i], S = itt.dat$saplings[,i]) 
        # add output under species
        output.species <- cbind(k,z,as.character(species[i]),tbl)
        # add column names
        colnames(output.species) <- c("site","itt","species", "A","ln_A","Ha","Hs","CMa","CMs","CMHa","CMHs","HMHa","HMHs","S") 
        # add output to site itt df
        output.itt <- rbind(output.itt, output.species)
      }
    }
  }
  # save itts under site
  output.site <- rbind(output.site, output.itt)
  # return entire site df to join with others
  return(output.site)
}

# save df as .rds object
saveRDS(glob.dat, 'data/null_conhet/1B1_null_conhet_globaldat_allalive.rds')
print('Null Global data complete')