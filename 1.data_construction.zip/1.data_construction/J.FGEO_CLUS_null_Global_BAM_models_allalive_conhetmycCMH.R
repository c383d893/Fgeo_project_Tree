############# RUN GLOBAL NULL BAM MODELS ##########
################ CONHETMYC VERSION ################
################# RUN ON CLUSTER ##################

## This script generates a global model with species*site intercept/slope to predict species*site estimates
## Then predicts conspecific density dependence for each species*site

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)  
library(mgcv)     

###################################################
################## BRING IN DAT ###################
###################################################

# get myc status
spdat <- readRDS("data/splevel_meta.rds") %>% rename(species=latin) %>% select(c('species', 'myc'))
# read extracted data sets
glob.dat1A <- readRDS('data/null_conhet/1A_null_conhet_globaldat_allalive.rds')
glob.dat1B1 <- readRDS('data/null_conhet/1B1_null_conhet_globaldat_allalive.rds')
glob.dat1B2 <- readRDS('data/null_conhet/1B2_null_conhet_globaldat_allalive.rds') %>%  
  mutate(itt = case_when(itt == 1 ~ 51, itt == 2 ~ 52, itt == 3 ~ 53, itt == 4 ~ 54, itt == 5 ~ 55,
                         itt == 6 ~ 56, itt == 7 ~ 57, itt == 8 ~ 58, itt == 9 ~ 59, itt == 10 ~ 60,
                         itt == 11 ~ 61, itt == 12 ~ 62, itt == 13 ~ 63, itt == 14 ~ 64, itt == 15 ~ 65,
                         itt == 16 ~ 66, itt == 17 ~ 67, itt == 18 ~ 68, itt == 19 ~ 69, itt == 20 ~ 70,
                         itt == 21 ~ 71, itt == 22 ~ 72, itt == 23 ~ 73, itt == 24 ~ 74, itt == 25 ~ 75,
                         itt == 26 ~ 76, itt == 27 ~ 77, itt == 28 ~ 78, itt == 29 ~ 79, itt == 30 ~ 80,
                         itt == 31 ~ 81, itt == 32 ~ 82, itt == 33 ~ 83, itt == 34 ~ 84, itt == 35 ~ 85,
                         itt == 36 ~ 86, itt == 37 ~ 87, itt == 38 ~ 88, itt == 39 ~ 89, itt == 40 ~ 90,
                         itt == 41 ~ 91, itt == 42 ~ 92, itt == 43 ~ 93, itt == 44 ~ 94, itt == 45 ~ 95,
                         itt == 46 ~ 96, itt == 47 ~ 97, itt == 48 ~ 98, itt == 49 ~ 99, itt == 50 ~ 100))
glob.dat1C <- readRDS('data/null_conhet/1C_null_conhet_globaldat_allalive.rds')
glob.dat2 <- readRDS('data/null_conhet/2_null_conhet_globaldat_allalive.rds')
glob.dat3 <- readRDS('data/null_conhet/3_null_conhet_globaldat_allalive.rds')
glob.dat4 <- readRDS('data/null_conhet/4_null_conhet_globaldat_allalive.rds')
glob.dat5 <- readRDS('data/null_conhet/5_null_conhet_globaldat_allalive.rds')

# read conhetmyc global dat; get all site by species combinations
glob.dat.chm <- readRDS('data/conhetmyc_distweight_globaldat_allalive.rds') %>%
  mutate(species = as.factor(species), sitespecies = as.factor(paste(site,species, sep = "_"))) %>%
  select(sitespecies) %>%
  group_by(sitespecies) %>%
  distinct()

# join global data and with spdat; generate sitespecies
# extract sitespecies that exist in CHM models
glob.dat <- rbind(glob.dat1A,glob.dat1B1,glob.dat1B2,glob.dat1C,glob.dat2,glob.dat3, glob.dat4,glob.dat5) %>%
  left_join(spdat, by = "species") %>%
  mutate(myc = as.factor(myc), species = as.factor(species), sitespecies = as.factor(paste(site,species, sep = "_"))) %>%
  inner_join(glob.dat.chm, by = "sitespecies") 

spmeanprop <- readRDS("data/spmeanprop_globalBAM_conmychet.rds")

###################################################
################# RUN BAM MODELS ##################
###################################################

###################################################
################## CMDD MODELS ####################
###################################################

# set itt
itt <- unique(glob.dat$itt)

# create df for output
null.glob.mods <- data.frame()
for(z in itt){
  # print itt
  print(z)
  # create df for itt
  itt.dat <- data.frame()
  # subset to itt z
  glob.dat.itt<- glob.dat %>% filter(itt == z)
  # run BAM model  
  factor_interact.ranint.slope <- bam(S ~ myc + s(A, k = 3, by = myc)+ s(CMHa, k = 3, by = myc)+ s(HMHa, k = 3)+ 
                                        s(sitespecies, bs = "re") + s(A, sitespecies, bs = "re") + s(CMHa, sitespecies, bs = "re"), 
                                      offset = (ln_A), family = nb(link = "log"), discrete = TRUE, data = glob.dat.itt)
  
  
###################################################
############### PREDICT DD CM GLOBAL ##############  
###################################################
  
# set medT, medA, medCMH (based on G conhetmyc)
medT <- 68.74758
medA <- 0.008775159
medCMH <- 65.60774
  
# for each site in mod.list
for(i in unique(spmeanprop$site)){
  # subset glob.dat to site
  glob.dat.site <- glob.dat %>% filter(site == i)
  # create df for site output
  output.site <- data.frame()
  # for each species in site.dat
  for(s in unique(glob.dat.site$species)) {
    # save species.dat, set myc cat
    species.dat = glob.dat.site %>% filter(species == s)
    myc_cat = unique(species.dat$myc)
    # create df for species output
    output.species <- data.frame() 
    # create new dat and predict
    Amin <- medA
    Amax <- medA
    CMHmin <- medCMH
    CMHmax <- medCMH + 1
    HMHmin <- medT - medA - CMHmax
    HMHmax <- medT - medA - CMHmin
    Asim <- c(Amin, Amax)
    CMHsim <- c(CMHmax, CMHmin)	
    HMHsim <- c(HMHmin, HMHmax)		
    pred.dat <- data.frame(A = Asim, CMHa = CMHsim, HMHa = HMHsim, myc = myc_cat, sitespecies = paste(i, s, sep = "_"))
    # predict and backcalculate per capita recruitment
    pred <- predict.gam(factor_interact.ranint.slope, newdata = pred.dat, type = "link", se = TRUE)
    prop.change <- (exp(pred[[1]][1])/ exp(pred[[1]][2])) - 1
    logit.change <- log(exp(pred[[1]][1]) / exp(pred[[1]][2]))
    # join all info at species level and join to site
    output.species <- cbind(i, s, prop.change, logit.change) %>% as.data.frame() # add site, species, and pred
    output.species <- output.species %>% mutate_at(c("prop.change", "logit.change"), as.character) %>%
      mutate_at(c("prop.change", "logit.change"), as.numeric)
    output.site <- rbind(output.site, output.species)
  }
  itt.dat <- rbind(itt.dat, output.site%>% mutate(itt = z))
}
null.glob.mods <- rbind(null.glob.mods, itt.dat)
}

# add column names
colnames(null.glob.mods) <- c("site", "species", "prop.change", "logit.change", "itt")
# rename and simplify data
null.glob.mods.CMH <- null.glob.mods %>%
  rename(latin=species,prop.change.CMH = prop.change, logit.change.CMH = logit.change) %>%
  drop_na() %>%
  select(c(site, latin, prop.change.CMH, logit.change.CMH, itt))

# save df as .rds object
saveRDS(null.glob.mods.CMH, 'data/null_conhetmyc/null_conhetmyc_CMH_spallfromglobal_GAMmodeloutput_allalive.rds')
print('Null Global BAMs complete')