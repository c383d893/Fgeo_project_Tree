############# CREATE PHYLO TREE PLOT ##############

###################################################
################# SET UP PACKAGES #################
###################################################

library(tidyverse)
library(spatstat)
library(ape)

###################################################
################## BRING IN DAT ###################
###################################################

# read project tree
tree <- read.tree("data/ForestGEO_phylogeny.nex")

# read data: keep distinct species and assign color, keep only species in tree
sp <- readRDS("data/conhet_allcensusdata_withmyc_allalive.rds") %>%                                             
  select(c("latin", "myc")) %>%                                                                      
  distinct(latin, .keep_all = TRUE) %>%                                                                                                                                            
  as.data.frame() %>%
  mutate(color = ifelse(myc == "AM","darkorchid3","mediumseagreen")) %>%
  filter(latin %in% tree$tip.label)

# make rownum col
sp$rownum <- rownames(sp)
# make mycols
mycols <- sp$color

spAM <- sp %>% filter(myc=="AM")
spEM <- sp %>% filter(myc=="EM")

# drop tips/prune
treeEM <- drop.tip(tree, unlist(spAM))
treeEM$tip.label[] <- ""
treeAM <- drop.tip(tree, unlist(spEM)) 


# save plot
png("figures/AMEM_phylo.jpg", width = 15, height = 15, units = 'in', res = 600)
#plot(tree, "fan", edge.color = mycols, show.tip.label = FALSE, cex = 0.15) 
dev.off()

png("figures/AM_phlyo.jpg", width = 15, height = 15, units = 'in', res = 600)
plot(treeAM, "fan", edge.color = "darkorchid3", show.tip.label = FALSE, cex = 0.15)
dev.off()

png("figures/EM_phlyo.jpg", width = 15, height = 15, units = 'in', res = 600)
plot(treeEM, "fan", edge.color = "mediumseagreen", show.tip.label = FALSE, cex = 0.15)
dev.off()
