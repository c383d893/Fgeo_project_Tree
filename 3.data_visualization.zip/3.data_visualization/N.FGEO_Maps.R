############## CREATE MAPS OF SITES ###############

###################################################
################# SET UP PACKAGES #################
###################################################

library(maps)
library(sf)
library(tidyverse)
library(ggrepel)
library(viridis)   

###################################################
################## BRING IN DAT ###################
###################################################

# read world data
world <- map_data("world")
# read study data
dat <- readRDS('data/conhet_allcensusdata_withmyc_allalive.rds') %>%
  select(c("latin", "site", "myc", "dbh"))
# read lat dat
lat <- read.table("data/FGEO_LatLon.txt",header =TRUE) %>%
  select(-site) %>%
  rename(site = full_site) %>%
  mutate(abslat = abs(lat)) %>%
  distinct(site, .keep_all=TRUE) %>%
  mutate(sitenum = row.names(.))

# filter lat dat to where we have data
lat.dat <- lat %>% filter(site %in% dat$site)
# filter lat dat to where we do not have data
lat.nodat <- lat %>% filter(!site %in% dat$site)

# remove _ from names
lat <- lat %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "-", " "))
lat.dat <- lat.dat %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "_", " ")) %>% mutate(site = str_replace(site, "-", " "))
lat.dat <- lat.dat %>% 
           mutate(site = case_when(site == "BCI" ~ "Barro Colorado Island",
                                               site == "Temple" ~ "Temple University",
                                               site == "University of Maryland" ~ "University of Maryland Baltimore County",
                                               site == "SCBI" ~ "Smithsonian Conservation Biology Institute",
                                               site == "SERC" ~ "Smithsonian Environmental Research Center",
                                               site == "FOREG 22" ~ "Low Elevation Andrews Satellite Plot",
                                               site == "FOREG 02" ~ "High Elevation Andrews Satellite Plot",
                                               site == "FOREG 31" ~ "Andrews",
                                               site == "Little Dickie Woods" ~ "Lilly Dickey Woods",
                                               TRUE ~ as.character(site))) 

lat.dat <- lat.dat %>% mutate(mapnum = rownames(.))
write.csv(lat.dat, "figures/sitenames.fig1.csv")
# save map plot
png("figures/FGEOdatmap.jpg", width = 35, height = 15, units = 'in', res = 300)
png("figures/FGEOdatmap_labels.jpg", width = 25, height = 10, units = 'in', res = 300)
ggplot(data = world) +
  geom_polygon(data = world, aes(x = long, y = lat, group = group), fill = "gray88") +
  #all plots grey
  #geom_point(data = lat.dat, aes(x = lon, y = lat), colour = "grey40", 
  #           fill = "grey40", pch = 21, size = 10, alpha = I(0.8)) +
  #color plots
  geom_point(data = lat.dat, aes(x = lon, y = lat, color = site, fill = site),
             pch = 21, size = 10, alpha = I(0.8)) +
  scale_fill_viridis(discrete = TRUE) +
  scale_color_viridis(discrete = TRUE) +
  #geom_text_repel(data = lat.dat, aes(x = lon, y = lat, label = site), 
  #                 nudge_x = c(3, -6, 12, 12, -3), nudge_y = c(1.5, -1.50, 3, 3, -3)) +
  xlab("") + ylab ("") +
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5,size = 20)) +
  coord_sf(ylim = c(-60, 100), expand = FALSE)+
  theme(axis.line = element_blank(), axis.ticks = element_blank(), 
        legend.position="right", legend.title = element_blank(),
        axis.text.x = element_blank(), axis.title.x = element_blank(),
        axis.text.y = element_blank(), axis.title.y = element_blank(), 
        panel.background = element_blank(), panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), plot.background = element_blank())

dev.off()

# version with numbered sites.
png("figures/figure1.numbered.png", width = 25, height = 10, units = 'in', res = 300)
pdf("figures/figure1.numbered.pdf")
ggplot(data = world) +
  geom_polygon(data = world, aes(x = long, y = lat, group = group), fill = "gray88") +
  geom_point(data = lat.dat, aes(x = lon, y = lat), colour = "grey40", 
             fill = "grey70", pch = 21, size = 1, alpha = I(0.9)) +
  geom_text(data = lat.dat, aes(x = lon, y = lat, label = mapnum), size = 0.5) +
  xlab("") + ylab ("") +
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5,size = 2)) +
  coord_sf(ylim = c(-60, 100), expand = FALSE) +
  theme(axis.line = element_blank(), axis.ticks = element_blank(), 
        legend.position = "right", legend.title = element_blank(),
        axis.text.x = element_blank(), axis.title.x = element_blank(),
        axis.text.y = element_blank(), axis.title.y = element_blank(), 
        panel.background = element_blank(), panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), plot.background = element_blank())

dev.off()
